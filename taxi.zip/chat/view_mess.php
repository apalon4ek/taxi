<?
define('_IN_JOHNCMS', 1);
/*
 by Str@nnik
 http://johncms.com/users/profile.php?user=21326
 ICQ: 609745227
*/
$headmod ="chat";
$textl = 'Мини-чат';
$rootpath = '../';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

$view_mess = mysql_fetch_assoc(mysql_query('select * from `m_chat` where `id` = '.$id.';'));
$view_user = mysql_fetch_assoc(mysql_query('select * from `users` where `id` = '.$view_mess['user_id'].';'));
echo '<div class="phdr">Сообщение <b>'.$view_user['name'].'\'a</b> c мини-чата</div><div class="menu">';
if (file_exists((ROOTPATH . 'files/users/avatar/' . $view_user['id'] . '.png')))
        echo '<img src="' . $home . '/files/users/avatar/' . $view_user['id'] . '.png" width="32" height="32" alt="" />&#160;';
    else
        echo '<img src="' . $home . '/images/empty.png" width="32" height="32" alt="" />&#160;';
    if ($view_user['sex'])
        echo functions::image(($view_user['sex'] == 'm' ? 'm' : 'w') . ($view_user['datereg'] > time() - 86400 ? '_new' : '') . '.png', array('class' => 'icon-inline'));
    else
        echo functions::image('del.png');
    echo !$user_id || $user_id == $view_user['id'] ? '<b>' . $view_user['name'] . '</b>&#160;' : '<a href="' . $home . '/users/profile.php?user=' . $view_user['id'] . '"><b>' . $view_user['name'] . '</b></a>&#160;';
                $rank = array(
                0 => '',
                1 => '(GMod)',
                2 => '(CMod)',
                3 => '(FMod)',
                4 => '(DMod)',
                5 => '(LMod)',
                6 => '(Smd)',
                7 => '(Adm)',
                9 => '(SV!)'
                );
        $Rights = isset($view_user['rights']) ? $view_user['rights'] : 0;
	    echo $rank[$Rights];
	echo (time() > $view_user['lastdate'] + 300 ? '<span class="red"> [Off]</span>' : '<span class="green"> [ON]</span>');
	echo '&#160;<span class="gray">(' . functions::display_date($view_mess['time']) . ')</span><br />';	
	if ($view_mess['cid']) {
		$view = mysql_fetch_assoc(mysql_query('select * from `m_chat` join `users` on `m_chat`.`user_id` = `users`.`id` and `m_chat`.`id` = '.$view_mess['cid'].';'));
		$view_post = functions::checkout($view['message'], 1, 1);
		if ($set_user['smileys'])
			$view_post = functions::smileys($view_post, $user['rights'] >= 1 ? 1 : 0);
		echo '<div class="quote"><b>' . $view['name'] . '</b>&nbsp;(' . functions::display_date($view['time']) . ')<br />' . $view_post . '</div>';
	}
	$post = functions::checkout($view_mess['message'], 1, 1);
	if ($set_user['smileys'])
		$post = functions::smileys($post, $user['rights'] >= 1 ? 1 : 0);
	echo $post;
	if ($user_id != $view_mess['user_id']) {
		echo '<br /><hr />[<a href="index.php?act=otv&amp;id='.$view_mess['user_id'].'">Отв</a>]&#160;[<a href="index.php?act=cyt&amp;id='.$view_mess['id'].'">Цит</a>]';
	}
	if ($view_mess['user_id'] == $user_id || $rights >= 7) {
		echo '<hr /><small><a href="index.php?act=del&amp;id=' . $view_mess['id'] . '">Удалить</a> | <a href="index.php?act=edit&amp;id=' . $view_mess['id'] . '">Изменить</a></small>';
	}
	echo '</div>';			
	echo '<div class="menu"><a href="index.php">В мини-чат</a></div>';

require_once ("../incfiles/end.php");