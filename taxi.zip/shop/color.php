<?php
define('_IN_JOHNCMS', 1);
/***********
 МаГазин для сайта
 Аффтар - ValekS
 http://john-help.ru
***********/
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
$headmod = 'shop';
$textl = 'Sayt xizmatlari do\'koni';
echo '<div class="phdr"><a href="/shop/">Magazin '.str_replace('http://', '',$set['homeurl']).'</a> | Ranglar jadvali</div>';
echo '<div class="list1">';
echo '<table border="0" cellpadding="0" cellspadding="5"><tbody>
<tr><td align="center"><table border="2" cellpadding="2" cellspacing="1"><tbody>
<tr><th align="left"><b><span style="font-size: x-small;"> Color\'s name </span></b></th><th align="left"><b><span style="font-size: x-small;"> Hex </span></b></th><th><b><span style="font-size: x-small;"> Color </span></b></th></tr>
<tr><td><span style="font-size: x-small;">alicemblue</span></td><td><span style="font-size: x-small;">#F0F8FF</span></td><td align="center" bgcolor="#F0F8FF"><br />
</td></tr>
<tr><td><span style="font-size: x-small;">antiquewhite</span></td><td><span style="font-size: x-small;">#FAEBD7</span></td><td align="center" bgcolor="#FAEBD7">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;">aqua</span></td><td><span style="font-size: x-small;">#00FFFF</span></td><td align="center" bgcolor="#00FFFF">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;">aquamarine</span></td><td><span style="font-size: x-small;">#7FFFD4</span></td><td align="center" bgcolor="#7FFFD4">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;"> azure </span></td><td><span style="font-size: x-small;">#F0FFFF</span></td><td align="center" bgcolor="#F0FFFF ">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;"> beige </span></td><td><span style="font-size: x-small;">#F5F5DC</span></td><td align="center" bgcolor="#F5F5DC">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;"> bisque </span></td><td><span style="font-size: x-small;">#FFE4C4</span></td><td align="center" bgcolor="#FFE4C4">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;">black  </span></td><td><span style="font-size: x-small;">#000000</span></td><td align="center" bgcolor="#000000">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;">blanchedalmond  </span></td><td><span style="font-size: x-small;">#FFEBCD</span></td><td align="center" bgcolor="#FFEBCD">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;">blue  </span></td><td><span style="font-size: x-small;">#0000FF</span></td><td align="center" bgcolor="#0000FF">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;">blueviolet  </span></td><td><span style="font-size: x-small;">#8A2BE2</span></td><td align="center" bgcolor="#8A2BE2">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;">brown  </span></td><td><span style="font-size: x-small;">#A52A2A</span></td><td align="center" bgcolor="#A52A2A">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;">burlywood  </span></td><td><span style="font-size: x-small;">#DEB887</span></td><td align="center" bgcolor="#DEB887">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;">cadetblue  </span></td><td><span style="font-size: x-small;">#5F9EA0</span></td><td align="center" bgcolor="#5F9EA0">&nbsp; </td></tr>
<tr><td><span style="font-size: x-small;"> chartreuse </span></td><td><span style="font-size: x-small;">#7FFF00</span></td><td align="center" bgcolor="#7FFF00">&nbsp;   </td></tr>
<tr><td><span style="font-size: x-small;">chocolate  </span></td><td><span style="font-size: x-small;">#D2691E</span></td><td align="center" bgcolor="#D2691E">&nbsp;   </td></tr>
<tr><td><span style="font-size: x-small;"> coral </span></td><td><span style="font-size: x-small;">#FF7F50</span></td><td align="center" bgcolor="#FF7F50">&nbsp;   </td></tr>
<tr><td><span style="font-size: x-small;"> cornflowerblue </span></td><td><span style="font-size: x-small;">#6495ED</span></td><td align="center" bgcolor="#6495ED">&nbsp;   </td></tr>
<tr><td><span style="font-size: x-small;">cornsilk </span></td><td><span style="font-size: x-small;">#FFF8DC</span></td><td align="center" bgcolor="#FFF8DC">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> crimson</span></td><td><span style="font-size: x-small;">#DC143C</span></td><td align="center" bgcolor="#DC143C">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">cyan </span></td><td><span style="font-size: x-small;">#00FFFF</span></td><td align="center" bgcolor="#00FFFF">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkblue</span></td><td><span style="font-size: x-small;">#00008B</span></td><td align="center" bgcolor="#00008B">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkcyan</span></td><td><span style="font-size: x-small;">#008B8B</span></td><td align="center" bgcolor="#008B8B">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkgoldenrod</span></td><td><span style="font-size: x-small;">#B8860B</span></td><td align="center" bgcolor="#B8860B">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkgray</span></td><td><span style="font-size: x-small;">#A9A9A9</span></td><td align="center" bgcolor="#A9A9A9">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkgreen</span></td><td><span style="font-size: x-small;">#006400</span></td><td align="center" bgcolor="#006400">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkkhaki</span></td><td><span style="font-size: x-small;">#BDB76B </span></td><td align="center" bgcolor="#BDB76B">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">darkmagenta </span></td><td><span style="font-size: x-small;">#8B008b</span></td><td align="center" bgcolor="#8B008B">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">darkolivegreen</span></td><td><span style="font-size: x-small;">#556B2F</span></td><td align="center" bgcolor="#556B2F">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkorange</span></td><td><span style="font-size: x-small;">#FF8C00</span></td><td align="center" bgcolor="#FF8C00">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkochid</span></td><td><span style="font-size: x-small;">#9932CC</span></td><td align="center" bgcolor="#9932CC">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">darkred </span></td><td><span style="font-size: x-small;">#8B0000</span></td><td align="center" bgcolor="#8B0000">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">darksalmon </span></td><td><span style="font-size: x-small;">#E9967A</span></td><td align="center" bgcolor="#E9967A">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkseagreen</span></td><td><span style="font-size: x-small;">#8FBC8F</span></td><td align="center" bgcolor="#8FBC8F">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkslateblue</span></td><td><span style="font-size: x-small;">#483D8B</span></td><td align="center" bgcolor="#483D8B">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> darkslategray</span></td><td><span style="font-size: x-small;">#2F4F4F</span></td><td align="center" bgcolor="#2F4F4F">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">darkturquoise </span></td><td><span style="font-size: x-small;">#00CED1</span></td><td align="center" bgcolor="#00CED1">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">darkviolet </span></td><td><span style="font-size: x-small;">#9400D3</span></td><td align="center" bgcolor="#9400D3">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">deeppink </span></td><td><span style="font-size: x-small;">#FF1493 </span></td><td align="center" bgcolor="#FF1493">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">deepskyblue </span></td><td><span style="font-size: x-small;">#00BFFF</span></td><td align="center" bgcolor="#00BFFF">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">dimgray </span></td><td><span style="font-size: x-small;">#696969</span></td><td align="center" bgcolor="#696969">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> dodgerblue</span></td><td><span style="font-size: x-small;">#1E90FF</span></td><td align="center" bgcolor="#1E90FF">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">firebrick </span></td><td><span style="font-size: x-small;">#B22222</span></td><td align="center" bgcolor="#B22222">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">floralwhite </span></td><td><span style="font-size: x-small;">#FFFAF0</span></td><td align="center" bgcolor="#FFFAF0">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> forestgreen</span></td><td><span style="font-size: x-small;">#228B22</span></td><td align="center" bgcolor="#228B22">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> fushsia</span></td><td><span style="font-size: x-small;">#FF00FF </span></td><td align="center" bgcolor="#FF00FF">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> gainsboro</span></td><td><span style="font-size: x-small;">#DCDCDC</span></td><td align="center" bgcolor="#DCDCDC">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> ghostwhite</span></td><td><span style="font-size: x-small;">#F8F8FF</span></td><td align="center" bgcolor="#F8F8FF">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">gold </span></td><td><span style="font-size: x-small;">#FFD700</span></td><td align="center" bgcolor="#FFD700">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> goldenrod</span></td><td><span style="font-size: x-small;">#DAA520</span></td><td align="center" bgcolor="#DAA520">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> gray</span></td><td><span style="font-size: x-small;">#808080</span></td><td align="center" bgcolor="#808080">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">green</span></td><td><span style="font-size: x-small;">#008000</span></td><td align="center" bgcolor="#008000">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> greenyellow</span></td><td><span style="font-size: x-small;">#ADFF2F</span></td><td align="center" bgcolor="#ADFF2F">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> honeydew</span></td><td><span style="font-size: x-small;">#F0FFF0</span></td><td align="center" bgcolor="#F0FFF0">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> hotpink</span></td><td><span style="font-size: x-small;">#FF69B4</span></td><td align="center" bgcolor="#FF69B4">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">indiandred </span></td><td><span style="font-size: x-small;">#CD5C5C</span></td><td align="center" bgcolor="#CD5C5C">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> indigo</span></td><td><span style="font-size: x-small;">#4B0082</span></td><td align="center" bgcolor="#4B0082">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> ivory</span></td><td><span style="font-size: x-small;">#FFFFF0</span></td><td align="center" bgcolor="#FFFFF0">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">khaki </span></td><td><span style="font-size: x-small;">#F0E68C</span></td><td align="center" bgcolor="#F0E68C">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> lavender</span></td><td><span style="font-size: x-small;">#E6E6FA</span></td><td align="center" bgcolor="#E6E6FA">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lavenderblush </span></td><td><span style="font-size: x-small;">#FFF0F5</span></td><td align="center" bgcolor="#FFF0F5">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lawngreen </span></td><td><span style="font-size: x-small;">#7CFC00 </span></td><td align="center" bgcolor="#7CFC00">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> lemonchiffon</span></td><td><span style="font-size: x-small;">#FFFACD</span></td><td align="center" bgcolor="#FFFACD">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">ligtblue </span></td><td><span style="font-size: x-small;">#ADD8E6</span></td><td align="center" bgcolor="#ADD8E6">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> lightcoral</span></td><td><span style="font-size: x-small;">#F08080 </span></td><td align="center" bgcolor="#F08080">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lightcyan </span></td><td><span style="font-size: x-small;">#E0FFFF</span></td><td align="center" bgcolor="#E0FFFF">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lightgoldenrodyellow</span></td><td><span style="font-size: x-small;">#FAFAD2</span></td><td align="center" bgcolor="#FAFAD2">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> lightgreen</span></td><td><span style="font-size: x-small;">#90EE90 </span></td><td align="center" bgcolor="#90EE90">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lightgrey </span></td><td><span style="font-size: x-small;">#D3D3D3</span></td><td align="center" bgcolor="#D3D3D3">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lightpink </span></td><td><span style="font-size: x-small;">#FFB6C1</span></td><td align="center" bgcolor="#FFB6C1">&nbsp;  </td></tr>
</tbody></table></td><td align="center">
<table border="2" cellpadding="2" cellspacing="1"><tbody>
<tr><th align="left"><b><span style="font-size: x-small;"> Color\'s name </span></b></th><th align="left"><b><span style="font-size: x-small;"> Hex </span></b></th><th><b><span style="font-size: x-small;"> Color </span></b></th></tr>
<tr><td><span style="font-size: x-small;">lightsalmon </span></td><td><span style="font-size: x-small;">#FFA07A</span></td><td align="center" bgcolor="#FFA07A">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lightseagreen </span></td><td><span style="font-size: x-small;">#20B2AA</span></td><td align="center" bgcolor="#20B2AA">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lightscyblue </span></td><td><span style="font-size: x-small;">#87CEFA</span></td><td align="center" bgcolor="#87CEFA">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> lightslategray</span></td><td><span style="font-size: x-small;">#778899</span></td><td align="center" bgcolor="#778899">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lightsteelblue</span></td><td><span style="font-size: x-small;">#B0C4DE</span></td><td align="center" bgcolor="#B0C4DE">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">lightyellow </span></td><td><span style="font-size: x-small;">#FFFFE0</span></td><td align="center" bgcolor="#FFFFE0">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> lime</span></td><td><span style="font-size: x-small;">#00FF00</span></td><td align="center" bgcolor="#00FF00">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">limegreen </span></td><td><span style="font-size: x-small;">#32CD32</span></td><td align="center" bgcolor="#32CD32">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> linen</span></td><td><span style="font-size: x-small;">#FAF0E6</span></td><td align="center" bgcolor="#FAF0E6">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> magenta</span></td><td><span style="font-size: x-small;">#FF00FF</span></td><td align="center" bgcolor="#FF00FF">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">maroon </span></td><td><span style="font-size: x-small;">#800000</span></td><td align="center" bgcolor="#800000">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> mediumaquamarine</span></td><td><span style="font-size: x-small;">#66CDAA</span></td><td align="center" bgcolor="#66CDAA">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">mediumblue </span></td><td><span style="font-size: x-small;">#0000CD</span></td><td align="center" bgcolor="#0000CD">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">mediumorchid </span></td><td><span style="font-size: x-small;">#BA55D3</span></td><td align="center" bgcolor="#BA55D3">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> mediumpurple</span></td><td><span style="font-size: x-small;">#9370DB </span></td><td align="center" bgcolor="#9370DB">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">mediumseagreen </span></td><td><span style="font-size: x-small;">#3CB371</span></td><td align="center" bgcolor="#3CB371">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> mediumslateblue</span></td><td><span style="font-size: x-small;">#7B68EE</span></td><td align="center" bgcolor="#7B68EE">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> mediumspringgreen</span></td><td><span style="font-size: x-small;">#00FA9A</span></td><td align="center" bgcolor="#00FA9A">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">mediumturquoise </span></td><td><span style="font-size: x-small;">#48D1CC</span></td><td align="center" bgcolor="#48D1CC">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">medium violetred</span></td><td><span style="font-size: x-small;">#C71585</span></td><td align="center" bgcolor="#C71585">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">midnightblue </span></td><td><span style="font-size: x-small;">#191970</span></td><td align="center" bgcolor="#191970">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> mintcream</span></td><td><span style="font-size: x-small;">#F5FFFA</span></td><td align="center" bgcolor="#F5FFFA">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> mistyrose</span></td><td><span style="font-size: x-small;">#FFE4E1</span></td><td align="center" bgcolor="#FFE4E1">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">moccasin </span></td><td><span style="font-size: x-small;">#FFE4B5</span></td><td align="center" bgcolor="#FFE4B5">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> navajowhite</span></td><td><span style="font-size: x-small;">#FFDEAD</span></td><td align="center" bgcolor="#FFDEAD">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> navy</span></td><td><span style="font-size: x-small;">#000080</span></td><td align="center" bgcolor="#000080">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">oldlace </span></td><td><span style="font-size: x-small;">#FDF5E6</span></td><td align="center" bgcolor="#FDF5E6">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> olive</span></td><td><span style="font-size: x-small;">#808000</span></td><td align="center" bgcolor="#808000">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">olivedrab </span></td><td><span style="font-size: x-small;">#6B8E23</span></td><td align="center" bgcolor="#6B8E23">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> orange</span></td><td><span style="font-size: x-small;">#FFA500</span></td><td align="center" bgcolor="#FFA500">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> orengered</span></td><td><span style="font-size: x-small;">#FF4500</span></td><td align="center" bgcolor="#FF4500">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> orchid</span></td><td><span style="font-size: x-small;">#DA70D6</span></td><td align="center" bgcolor="#DA70D6">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> palegoldenrod</span></td><td><span style="font-size: x-small;">#EEE8AA</span></td><td align="center" bgcolor="#EEE8AA">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> palegreen</span></td><td><span style="font-size: x-small;">#98FB98</span></td><td align="center" bgcolor="#98FB98">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> paleturquose</span></td><td><span style="font-size: x-small;">#AFEEEE</span></td><td align="center" bgcolor="#AFEEEE">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">palevioletred </span></td><td><span style="font-size: x-small;">#DB7093</span></td><td align="center" bgcolor="#DB7093">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> papayawhop</span></td><td><span style="font-size: x-small;">#FFEFD5</span></td><td align="center" bgcolor="#FFEFD5">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">peachpuff </span></td><td><span style="font-size: x-small;">#FFDAB9</span></td><td align="center" bgcolor="#FFDAB9">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">peru </span></td><td><span style="font-size: x-small;">#CD853F</span></td><td align="center" bgcolor="#CD853F">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> pink</span></td><td><span style="font-size: x-small;">#FFC0CB </span></td><td align="center" bgcolor="#FFC0CB">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> plum</span></td><td><span style="font-size: x-small;">#DDA0DD</span></td><td align="center" bgcolor="#DDA0DD">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">powderblue </span></td><td><span style="font-size: x-small;">#B0E0E6</span></td><td align="center" bgcolor="#B0E0E6">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">purple </span></td><td><span style="font-size: x-small;">#800080</span></td><td align="center" bgcolor="#800080">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> red</span></td><td><span style="font-size: x-small;">#FF0000</span></td><td align="center" bgcolor="#FF0000">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">rosybrown </span></td><td><span style="font-size: x-small;">#BC8F8F</span></td><td align="center" bgcolor="#BC8F8F">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">royalblue </span></td><td><span style="font-size: x-small;">#4169E1</span></td><td align="center" bgcolor="#4169E1">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">saddlebrown </span></td><td><span style="font-size: x-small;">#8B4513</span></td><td align="center" bgcolor="#8B4513">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> salmon</span></td><td><span style="font-size: x-small;">#FA8072 </span></td><td align="center" bgcolor="#FA8072">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">sandybrown </span></td><td><span style="font-size: x-small;">#F4A460</span></td><td align="center" bgcolor="#F4A460">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">seagreen </span></td><td><span style="font-size: x-small;">#2E8B57</span></td><td align="center" bgcolor="#2E8B57">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">seashell </span></td><td><span style="font-size: x-small;">#FFF5EE</span></td><td align="center" bgcolor="#FFF5EE">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">sienna </span></td><td><span style="font-size: x-small;">#A0522D</span></td><td align="center" bgcolor="#A0522D">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> silver</span></td><td><span style="font-size: x-small;">#C0C0C0</span></td><td align="center" bgcolor="#C0C0C0">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">skyblue </span></td><td><span style="font-size: x-small;">#87CEEB</span></td><td align="center" bgcolor="#87CEEB">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> slateblue</span></td><td><span style="font-size: x-small;">#6A5ACD</span></td><td align="center" bgcolor="#6A5ACD">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">slategray </span></td><td><span style="font-size: x-small;">#708080</span></td><td align="center" bgcolor="#708090">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">snow </span></td><td><span style="font-size: x-small;">#FFFAFA</span></td><td align="center" bgcolor="#FFFAFA">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> springgreen</span></td><td><span style="font-size: x-small;">#00FF7F</span></td><td align="center" bgcolor="#00FF7F">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">steelblue </span></td><td><span style="font-size: x-small;">#4682B4</span></td><td align="center" bgcolor="#4682B4">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">tan </span></td><td><span style="font-size: x-small;">#D2B48C</span></td><td align="center" bgcolor="#D2B48C">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">teal </span></td><td><span style="font-size: x-small;">#008080</span></td><td align="center" bgcolor="#008080">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> thistle</span></td><td><span style="font-size: x-small;">#D8BFD8</span></td><td align="center" bgcolor="#D8BFD8">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">tomato </span></td><td><span style="font-size: x-small;">#FF6347</span></td><td align="center" bgcolor="#FF6347">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">turquose </span></td><td><span style="font-size: x-small;">#40E0D0</span></td><td align="center" bgcolor="#40E0D0">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> violet</span></td><td><span style="font-size: x-small;">#EE82EE</span></td><td align="center" bgcolor="#EE82EE">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> wheat</span></td><td><span style="font-size: x-small;">#F5DEB3</span></td><td align="center" bgcolor="#F5DEB3">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> white</span></td><td><span style="font-size: x-small;">#FFFFFF</span></td><td align="center" bgcolor="#FFFFFF">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> whitesmoke</span></td><td><span style="font-size: x-small;">#F5F5F5</span></td><td align="center" bgcolor="#F5F5F5">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;"> yellow</span></td><td><span style="font-size: x-small;">#FFFF00</span></td><td align="center" bgcolor="#FFFF00">&nbsp;  </td></tr>
<tr><td><span style="font-size: x-small;">yellowgreen </span></td><td><span style="font-size: x-small;">#9ACD32</span></td><td align="center" bgcolor="#9ACD32">&nbsp;  </td></tr>
</tbody></table></td></tr>
</tbody></table>';
echo '</div>';
require_once ('../incfiles/end.php');


?>