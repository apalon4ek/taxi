<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
/***********
 МаГазин для сайта
 Аффтар - ValekS & соАффтар ЭТОГО файла Hall_life
 http://john-help.ru
***********/
echo '<div class="phdr"><a href="/shop/">Magazin '.str_replace('http://', '',$set['homeurl']).'</a> | Anonim xabar yuborish</div>';

// Узнаём цену
$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 10"));
$a = $price['price'];

// Проверка на спам
$flood = functions::antiflood();
if ($flood) {
echo functions::display_error($lng['error_flood'] . ' ' . $flood . '&#160;' . $lng['seconds'], '<a href="/shop/index.php">' . $lng['back'] . '</a>');
require_once('../incfiles/end.php');
exit;
}

if (isset($_POST['submit'])) {
    if (isset($ban['1']) || isset($ban['3'])) {
    require_once('../incfiles/end.php');
    exit;
    }

    // Принимаем дынные
    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
	$name = isset($_POST['usr']) ? functions::check($_POST['usr']) : '';
    $text = isset($_POST['msg']) ? functions::check($_POST['msg']) : '';
	$tema = isset($_POST['tema']) ? functions::check(mb_substr($_POST['tema'], 0, 50)) : '';
    $error = false;

    // Проверка кода CAPTCHA
    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'Tekshiruv kodi kiritilmadi!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Noto\'g\'ri kod kiritilmadi!<br />';
    unset($_SESSION['code']);

    if (empty($name))
        $error = $error . 'Xabar yuboriladigan user niki yoki ID raqami kiritilmadi!<br />';
	if (empty($tema))
        $error = $error . 'Xabar mavzusi kiritilmadi!<br />';
    if (empty($text))
        $error = $error . 'Anonim xabar matni kiritilmadi!<br />';

    if (empty($error)) {
        // Проверка монет
        if ($datauser['balans'] < $a) {
        $error = 'Yetarli tanga mavjud emas!<br/>';
        }
    }
        // Проверка на кривые данные Ник или АйДи
        if (is_numeric($name) != false) {
        $req = mysql_query("select * from `users` where `id`='$name'");
        if (mysql_num_rows($req) == 0) {
        $error = 'Bunday user mavjud emas!<br/>';
        }
        $fusr = $name;
        } else {
        $req = mysql_query("select * from `users` where `name`='$name'");
        if (mysql_num_rows($req) == 0) {
        $error = 'Bunday user mavjud emas!<br/>';
        }
        $uid = mysql_fetch_assoc(mysql_query("SELECT `id` FROM `users` WHERE `name`='$name'"));
        $fusr = $uid['id'];
        }

    if (empty($error)) {
        // Заносим данные в Базу
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
        mysql_query("INSERT INTO `cms_mail` SET `user_id` = '0',`from_id` = '" . $fusr . "',`text` = '" . $text . "

[b]Xabar xizmatlar do\'koni orqali yuborildi!
Bunga javob yozmang!!![/b]',`time` = '" . time() . "',`sys` = '1',`them` = '" . $tema . "'");
        echo '<div class="gmenu">Anonim xabar yuborildi!';
        echo '<br/><a href="/shop/">Do\'konga</a>';
        echo '</div>';
    } else {
        echo '<div class="rmenu"><p><b>XATOLIK!</b><br />' . $error . '</p></div>';
    }

} else {
    // Форма ввода
    echo '<div class="list2"><b>'.$login.'</b>, Buyerda ISTALGAN userga anonim xabar yuborishingiz mumkin!<br/>Narxi: '.$a.' ta tanga</div>';
    echo '<form action="/shop/index.php?act=amail" method="post"><div class="list1">';
    echo '<p><b>Nik:</b><br/><input type="text" name="usr" maxlength="30" value="" /><br/><small>Xabar yuboriladigan user nikini yoki ID raqamini kiriting.</small></p>';
	echo '<p><b>Mavzu:</b><br/><input type="text" name="tema" maxlength="50" value="" /><br/><small>Anonim xabar mavzusini tanlang.</small></p>';
    echo '<p><b>Matn:</b><br/><textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea><br/><small>Anonim xabar matnini kiriting. Smayl va bb kodlardan foydalanishingiz mumkin.</small></p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="Проверочный код" border="1"/><br />';
    echo 'Tekshiruv kodi:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="list2"><input type="submit" name="submit" value="Yuborish"/></div></form>';
    }

?>