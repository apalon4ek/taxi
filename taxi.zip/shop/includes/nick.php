<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
/***********
 МаГазин для сайта
 Аффтар - ValekS
 http://john-help.ru
***********/
echo '<div class="phdr"><a href="/shop/">Magazin '.str_replace('http://', '',$set['homeurl']).'</a> | Nikni o\'zgartirish</div>';
// Узнаём цену
$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 2"));
$a = $price['price'];

if (isset($_POST['submit'])) {
    // Принимаем дынные
    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
    $name = isset($_POST['name']) ? functions::check(mb_substr($_POST['name'], 0, 15)) : $datauser['name'];
    $error = false;

    // Проверка кода CAPTCHA
    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'Tekshiruv kodi kiritilmadi!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Noto\'g\'ri kod kiritildi!<br />';
    unset($_SESSION['code']);

    if (empty($error)) {
        // Проверка монет
        if ($datauser['balans'] < $a) {
        $error = 'Yetarli tangalar mavjud emas!<br/>';
        }

        // Проверка ника
        if (mb_strlen($name) < 2 || mb_strlen($name) > 15)
            $error = 'Ruxsat etilmagan uzunlik';
        $lat_nick = functions::rus_lat(mb_strtolower($name));
        if (preg_match("/[^0-9a-z\-\@\*\(\)\?\!\~\_\=\[\]]+/", $lat_nick))
            $error = 'Ruxsat etilmagan belgi!';
    }

    // Заносим данные в Базу
    if (empty($error)) {
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `name` = '" . mysql_real_escape_string($name) . "' WHERE `id` = '$user_id'");
        echo '<div class="gmenu">Nik o\'zgartirildi!';
        echo '<br/><a href="/shop/">Do\'konga</a>';
        echo '</div>';
    } else {
        echo '<div class="rmenu"><p><b>XATOLIK!</b><br />' . $error . '</p></div>';
    }

} else {
    // Форма ввода
    echo '<div class="list2"><b>'.$login.'</b>, Buyerda o\'z nikingizni o\'zgartirishingiz mumkin.<br/><span style="color:red">DIQQAT! NIKINGIZ BUTUN SAYT BO\'YLAB O\'ZGARADI!<br/>Forum/mexmonxonadagi avvalgi postlarda nik o\'zgarmaydi.<br/>O\'zgartirishdan keyingi postlarda yangi nik ishlatiladi.<br/><b>Profilga kirishda eski nikdan foydalaniladi!!!</b></span><br/>Narxi: '.$a.' ta tanga</div>';
    echo '<form action="/shop/index.php?act=nick" method="post"><div class="list1">';
    echo '<p><b>Nik:</b><br/><input type="text" name="name" maxlength="50" value="'.$datauser['name'].'" /><br/><small>Yangi nikingizni kiriting<br/>Minimal uzunlik: 2ta belgi, maksimal uzunlik: 20ta belgi</small></p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="nazorat kodi" border="1"/><br />';
    echo 'Rasmdagi kod:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="list2"><input type="submit" name="submit" value="O\'zgartirish"/></div></form>';
    }
?>