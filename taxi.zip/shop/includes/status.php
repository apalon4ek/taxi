<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
/***********
 МаГазин для сайта
 Аффтар - ValekS
 http://john-help.ru
***********/
echo '<div class="phdr"><a href="/shop/">Magazin '.str_replace('http://', '',$set['homeurl']).'</a> | Status o\'rnatish</div>';

// Узнаём цену
$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 1"));
$a = $price['price'];

if (isset($_POST['submit'])) {
    // Принимаем дынные
    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
    $text = isset($_POST['status']) ? functions::check(mb_substr($_POST['status'], 0, 50)) : '';
    $error = false;

    // Проверка кода CAPTCHA
    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'Tekshiruv kodi kiritilmadi!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Noto\'g\'ri kod kiritildi!<br />';
    unset($_SESSION['code']);

    if (empty($error)) {
        // Проверка монет
        if ($datauser['balans'] < $a) {
        $error = 'Yetarli tanga mavjud emas!<br/>';
        }
    }

    // Заносим данные в Базу
    if (empty($error)) {
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `status` = '" . mysql_real_escape_string($text) . "' WHERE `id` = '$user_id'");
        echo '<div class="gmenu">Status o\'rnatildi!';
        echo '<br/><a href="/shop/">Do\'konga</a>';
        echo '</div>';
    } else {
        echo '<div class="rmenu"><p><b>XATOLIK!</b><br />' . $error . '</p></div>';
    }

} else {
    // Форма ввода
    echo '<div class="list2"><b>'.$login.'</b>, Buyerda o\'zingizga status sotib olishingiz mumkin.<br/>Narxi: '.$a.' ta tanga</div>';
    echo '<form action="/shop/index.php?act=status" method="post"><div class="list1">';
    echo '<p><b>Status:</b><br/><input type="text" name="status" maxlength="50" value="'.$datauser['status'].'" /><br/><small>O\'zingizga olmoqchi bo\'lgan status matnini kiriting<br/>Maksimal uzunlik: 50ta belgi</small></p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="nazorat kodi" border="1"/><br />';
    echo 'Rasmdagi kod:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="list2"><input type="submit" name="submit" value="O\'rnatish"/></div></form>';
    }

?>