<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
/***********
 МаГазин для сайта
 Аффтар - ValekS
 http://john-help.ru
***********/
echo '<div class="phdr"><a href="/shop/">Magazin '.str_replace('http://', '',$set['homeurl']).'</a> | Karma +</div>';
// Узнаём цену
$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 3"));
$a = $price['price'];

if (isset($_POST['submit'])) {
    // Принимаем дынные
    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
    $error = false;

    // Проверка кода CAPTCHA
    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'Tekshiruv kodi kiritilmadi!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Noto\'g\'ri kod kiritildi!<br />';
    unset($_SESSION['code']);

    if (empty($error)) {
        // Проверка монет
        if ($datauser['balans'] < $a) {
        $error = 'Yetarli tanga mavjud emas!<br/>';
        }
    }

    // Заносим данные в Базу
    if (empty($error)) {
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `karma_plus` = '" . ($datauser['karma_plus'] + 5) . "' WHERE `id` = '$user_id'");
        mysql_query("INSERT INTO `karma_users` SET
                            `user_id` = '0',
                            `name` = 'Продавец',
                            `karma_user` = '" . $user_id . "',
                            `points` = '5',
                            `type` = '1',
                            `time` = '" . time() . "',
                            `text` = 'Karma sayt do\'konidan yuborildi!'
                        ");
        header('Location: index.php?act=karmap');
    } else {
        echo '<div class="rmenu"><p><b>XATOLIK!</b><br />' . $error . '</p></div>';
    }

} else {
    // Форма ввода
    echo '<div class="list2"><b>'.$login.'</b>, buyerda o\'z karmanga +5 ball sotib olishing mumkin.<br/>Narxi: '.$a.' ta tanga</div>';
    echo '<form action="/shop/index.php?act=karmap" method="post"><div class="list1">';
    echo '<p><b>Karma:</b><br/>'.($datauser['karma_plus'] - $datauser['karma_minus']).' (<span style="color:green">'.$datauser['karma_plus'].'</span> / <span style="color:red">'.$datauser['karma_minus'].'</span>)</p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="Проверочный код" border="1"/><br />';
    echo 'Rasmdagi kod:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="list2"><input type="submit" name="submit" value="+5 Qo\'shish"/></div></form>';
    }

?>