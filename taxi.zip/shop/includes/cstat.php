<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
/***********
 МаГазин для сайта
 Аффтар - ValekS
 http://john-help.ru
***********/
echo '<div class="phdr"><a href="/shop/">Magazin '.str_replace('http://', '',$set['homeurl']).'</a> | Rangli status</div>';

// Узнаём цену
$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 12"));
$a = $price['price'];

if (isset($_POST['submit'])) {
    // Принимаем дынные
    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
    $clr = isset($_POST['color']) ? functions::check(mb_substr($_POST['color'], 0, 25)) : '';
    $error = false;

    // Проверка кода CAPTCHA
    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'Tekshiruv kodi kiritilmadi!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Noto\'g\'ri kod kiritildi!<br />';
    unset($_SESSION['code']);

    // Проверка цвета
    if (empty($clr) || mb_strlen($clr) < 3)
        $error = $error . 'Status rangi kiritilmadi!<br />';
    if (preg_match("/[^0-9a-zA-Z]+/", $clr))
            $error = 'Ruxsat etilmagan belgilar!<br/>';

    if (empty($error)) {
        // Проверка монет
        if ($datauser['balans'] < $a) {
        $error = 'Yetarli tanga mavjud emas!<br/>';
        }
    }

    // Заносим данные в Базу
    if (empty($error)) {
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `cstat` = '" . mysql_real_escape_string($clr) . "' WHERE `id` = '$user_id'");
        echo '<div class="gmenu">Statusingiz rangi!<br/>';
        echo 'Masalan: <font color="'.$clr.'">'.$datauser['status'].'</font>';
        echo '<br/><a href="/shop/">Do\'konga</a>';
        echo '</div>';
    } else {
        echo '<div class="rmenu"><p><b>XATOLIK!</b><br />' . $error . '</p></div>';
    }

} else {
    // Форма ввода
    echo '<div class="list2"><b>'.$login.'</b>, Buyerda statusingiz rangini o\'zgartirishingiz mumkin. Diqqat! Statur rangi Mobil Chat uchun amal qilmaymdi!<br/>Narxi: '.$a.' ta tanga</div>';
    echo '<form action="/shop/index.php?act=cstat" method="post"><div class="list1">';
    echo '<p>'.(strlen($datauser['cstat']) == 1 ? '<b>Rangi:</b>' : '<font color="'.$datauser['cstat'].'"><b>Rangi:</b></font>').'<br/><input type="text" name="color" maxlength="25" value="'.$datauser['cstat'].'" /><br/><small>Rang nomini(black) yoki kodini(000000) kiriting<br/><font color="red">Kod uchun RGB emas, html kod yozing, #(panjara) belgisisiz!!!</font></small><br/><a href="/shop/color.php"><font color="0000ff">Ranglar ro\'yxati</font></a></p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="Проверочный код" border="1"/><br />';
    echo 'Rasmdagi kod:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="list2"><input type="submit" name="submit" value="O\'rnatish"/></div></form>';
    }

?>