<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
$headmod = 'shop';
require_once('../incfiles/core.php');
require_once('../incfiles/head.php');
$textl = 'Sayt mgazini';
/***********
 МаГазин для сайта
 Аффтар - ValekS
 http://john-help.ru
***********/
if (!$user_id) {
echo '<div class="rmenu">Faqat foydalanuvchilarga!!</div>';
} else {
$array = array(
    'status',
    'karmap',
    'karmam',
    'nick',
    'amail',
    'cnick',
    'cstat'
);
if ($act && ($key = array_search($act, $array)) !== false && file_exists('includes/' . $array[$key] . '.php')) {
    require('includes/' . $array[$key] . '.php');
} else {
echo '<div class="phdr">Sayt Magazini</div>';

// меню магазина
echo '<div class="phdr">Sizdagi ballar: '.$datauser['balans'].'</div>';
echo '<div class="list1"><a href="money.php">Ball o\'tkazish</a></div>';
echo '<div class="list2"><a href="index.php?act=status">Status o\'rnatish</a></div>';
echo '<div class="list1"><a href="index.php?act=nick">Nikni o\'zgartirish</a></div>';
echo '<div class="list2"><a href="index.php?act=karmap">Karma +</a></div>';
echo '<div class="list1"><a href="index.php?act=karmam">Karma -</a></div>';
echo '<div class="list2"><a href="index.php?act=amail">Anonim xabar yo\'llash</a></div>';
echo '<div class="list1"><a href="col.php">Rangli nik</a></div>';
echo '<div class="list2"><a href="index.php?act=cstat">Rangli status</a></div>';
  }
    }
require_once('../incfiles/end.php');

?>
