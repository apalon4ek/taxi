<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
require_once('../incfiles/head.php');
$headmod = 'shop';
$textl = 'Sayt magazini';
/***********
 МаГазин для сайта
 Аффтар - ValekS
 http://john-help.ru
***********/
if (!$user_id) {
echo '<div class="rmenu">Faqat foydalanuvchilar uchun!</div>';
} else {
echo '<div class="phdr"><a href="/shop/">Ball o\'tkazish</div>';

switch ($act) {
case 'ok':

    // Принимаем данные
    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
    $logid = isset($_POST['logid']) ? trim($_POST['logid']) : '';
    $sum = isset($_POST['sum']) ? abs(intval($_POST['sum'])) : '';
    $error = false;

    // Проверяем данные Ник или АйДи
    if (empty($logid))
        $error = $error . 'Nik/ID kiritilmadi!<br />';
    elseif (mb_strlen($logid) > 15)
        $error = $error . 'Ruxsat etilmagan uzunlikdagi Nik/ID!<br />';
    if (preg_match('/[^\da-zA-Z\-\@\*\(\)\?\!\~\_\=\[\]]+/', $logid))
        $error = $error . 'Nik/ID tarkibida ruhsat etilmagan belgilar!<br />';
    // Провереряем данные сумма
    if (empty($sum))
        $error = $error . 'Ball miqdori kiritilmadi!<br />';
    if (preg_match('/[^\d]+/', $sum))
        $error = $error . 'Summada ruxsat etilmagan belgilar!<br />';
    // Проверка кода CAPTCHA
    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'Tekshiruv kodi kiritilmadi!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Noto\'g\'ri kod kiritildi!<br />';
    unset($_SESSION['code']);

    if (empty($error)) {
        // Проверка на кривые данные Ник или АйДи
        if (is_numeric($logid) != false) {
        $req = mysql_query("select * from `users` where `id`='$logid'");
        if (mysql_num_rows($req) == 0) $error = 'Bunday user mavjud emas!<br/>';
        } else {
        $uid = mysql_fetch_assoc(mysql_query("SELECT `id` FROM `users` WHERE `name`='$logid'"));
        $req = mysql_query("select * from `users` where `id`='".$uid['id']."'");
        $logid = $uid['id'];
        if (mysql_num_rows($req) == 0) $error = 'Bunday user mavjud emas!<br/>';
        }

        // Проверка на кривые данные сумма
        if ($datauser['balans'] < $sum || $datauser['balans'] == 0) {
        $error = 'Sizda buncha ball yo\'q!<br/>';
        }
    }

    // Заносим данные в БД
    if (empty($error)) {
        $mon = mysql_fetch_assoc(mysql_query("SELECT `balans` FROM `users` WHERE `id`='$logid'"));
        mysql_query("UPDATE `users` SET `balans` = '" . ($mon['balans'] + $sum) . "' WHERE `id` = '$logid'");
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $sum) . "' WHERE `id` = '$user_id'");
        mysql_query("INSERT INTO `cms_mail` SET `user_id` = '0',`from_id` = '" . $logid . "',`text` = '[b]".$login."[/b] nomli foydalanuvchi sizga [b]".$sum."[/b] ta tanga yubordi!',`time` = '" . time() . "',`sys` = '1',`them` = 'Tangani yuborish'");
        $polz = mysql_fetch_assoc(mysql_query("SELECT `name` FROM `users` WHERE `id`='$logid'"));
        mysql_query("INSERT INTO `cms_mail` SET `user_id` = '0',`from_id` = '" . $user_id . "',`text` = 'Siz [b]".$sum."[/b] miqdordagi tangani [b]".$polz['name']."[/b]ga yubormoqdasiz!',`time` = '" . time() . "',`sys` = '1',`them` = 'Tanga yuborish'");
        echo '<div class="gmenu">Yuborildi!';
        echo '<br/><a href="/shop/">Magazinga</a>';
        echo '</div>';
    } else {
        echo '<div class="rmenu"><p><b>XATOLIK!</b><br />' . $error . '</p></div>';
    }

break;

default:
    // форма ввода данных
        echo '<form action="money.php?act=ok" method="post"><div class="list1">';
    if ($user) {
    $usr = mysql_fetch_assoc(mysql_query("SELECT `name` FROM `users` WHERE `id`=".$user.""));
    }
    echo '<p><b>ID yoki Nik:</b><br/><input type="text" name="logid" maxlength="15" '.($user ? 'value="' . $usr['name'] . '"' : '').' /><br/><small>Tanga yuboriladigan userning Nik yoki ID raqamini kiriting:</small></p>';
    echo '<p><b>Summa:</b><br/><input type="text" name="sum" maxlength="15" /><br/><small>Yuboriladigan ball miqdori:</small></p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="nazorad kodi" border="1"/><br />';
    echo 'Rasmdagi kod:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="list2"><input type="submit" name="submit" value="Yuborish"/></div></form>';
break;
    }
       }
require_once('../incfiles/end.php');
?>