<?php
define('_IN_JOHNCMS', 1);
$headmod = 'shop';
$textl = 'Nik rangi sotib olish';
require ("../incfiles/core.php");
require ("../incfiles/head.php");
$user = functions::get_user($user);
$user = $datauser;
$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 14"));
$a = $price['price'];
$price2 = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 15"));
$b = $price2['price'];
if (!$user_id) {
   echo functions::display_error('Faqat foydalanuvchilar uchun');
    require_once ('../incfiles/end.php');
    exit;
}

switch($act){
case 'gradient' :

echo '<div class="phdr">Boshlang\'ich rang:</div>';
if($user['balans']>=$b){
echo '<div><form action="col.php?act=gradientbuy" name="color" method="post"> 
<input type="radio" name="color" value="006400"/><font color="#006400"> Темно-зеленый</font><br />
<input type="radio" name="color" value="0000FF"/><font color="#0000FF"> Синий</font><br />
<input type="radio" name="color" value="000080"/><font color="#000080"> Темно-синий</font><br />
<input type="radio" name="color" value="00FFFF"/><font color="#00FFFF"> Голубой</font><br />
<input type="radio" name="color" value="FFFF00"/><font color="#FFFF00"> Желтый</font><br />
<input type="radio" name="color" value="808080"/><font color="#808080"> Серый</font><br />
<input type="radio" name="color" value="C0C0C0"/><font color="#C0C0C0"> Светло-серый</font><br />
<input type="radio" name="color" value="9ACD32"/><font color="#9ACD32"> Желто-зеленый</font><br />
<input type="radio" name="color" value="7FFF00"/><font color="#7FFF00"> Салатовый</font><br />
<input type="radio" name="color" value="90EE90"/><font color="#90EE90"> Светло-зеленый</font><br />
<input type="radio" name="color" value="D1E231"/><font color="#D1E231"> Грушевый</font><br/>
<input type="radio" name="color" value="4B0082"/><font color="#4B0082"> Индиго</font><br />
<input type="radio" name="color" value="8A2BE2"/><font color="#8A2BE2"> Фиолетовый</font><br />
<input type="radio" name="color" value="991199"/><font color="#991199"> Фиолетово-баклажанный</font><br />
<input type="radio" name="color" value="008B8B"/><font color="#008B8B"> Темно-голубой</font><br />
<input type="radio" name="color" value="4682B4"/><font color="#4682B4"> Голубая сталь</font><br />
<input type="radio" name="color" value="87CEEB"/><font color="#87CEEB"> Светло-голубой</font><br />
<input type="radio" name="color" value="FF7F50"/><font color="#FF7F50"> Кораловый</font><br />
<input type="radio" name="color" value="8B4513"/><font color="#8B4513"> Коричневый</font><br />
<input type="radio" name="color" value="FF2400"/><font color="#FF2400"> Алый</font><br />
<input type="radio" name="color" value="DC143C"/><font color="#DC143C"> Малиновый</font><br />
<input type="radio" name="color" value="FF1493"/><font color="#FF1493"> Ярко-розовый</font><br />
<input type="radio" name="color" value="FF69B4"/><font color="#FF69B4"> Розовый</font><br />
<input type="radio" name="color" value="FF8C00"/><font color="#FF8C00"> Оранжевый</font><br />
<input type="radio" name="color" value="FFD700"/><font color="#FFD700"> Золото</font><br />
<input type="radio" name="color" value="BDB76B"/><font color="#BDB76B"> Хаки</font><br />
<input type="radio" name="color" value="FFA07A"/><font color="#FFA07A"> Оранжево-розовый</font><br />
<input type="radio" name="color" value="008080"/><font color="#008080"> Мурена</font><br />
<input type="radio" name="color" value="FFDB58"/><font color="#FFDB58"> Горчичный</font><br />
<input type="radio" name="color" value="40826D"/><font color="#40826D"> Ядовито-зелёный</font><br />
<input type="radio" name="color" value="1E90FF"/><font color="#1E90FF"> Защитно-синий</font><br />
<input type="radio" name="color" value="808000"/><font color="#808000"> Оливковый</font><br />
<input type="radio" name="color" value="660000"/><font color="#660000"> Коричнево-малиновый</font><br />
<input type="radio" name="color" value="D2B48C"/><font color="#D2B48C"> Желто-коричневый</font><br />


<div class="phdr">Tugallanuvchi rang:</div>
<input type="radio" name="color2" value="006400"/><font color="#006400"> Темно-зеленый</font><br />
<input type="radio" name="color2" value="0000FF"/><font color="#0000FF"> Синий</font><br />
<input type="radio" name="color2" value="000080"/><font color="#000080"> Темно-синий</font><br />
<input type="radio" name="color2" value="00FFFF"/><font color="#00FFFF"> Голубой</font><br />
<input type="radio" name="color2" value="FFFF00"/><font color="#FFFF00"> Желтый</font><br />
<input type="radio" name="color2" value="808080"/><font color="#808080"> Серый</font><br />
<input type="radio" name="color2" value="C0C0C0"/><font color="#C0C0C0"> Светло-серый</font><br />
<input type="radio" name="color2" value="9ACD32"/><font color="#9ACD32"> Желто-зеленый</font><br />
<input type="radio" name="color2" value="7FFF00"/><font color="#7FFF00"> Салатовый</font><br />
<input type="radio" name="color2" value="90EE90"/><font color="#90EE90"> Светло-зеленый</font><br />
<input type="radio" name="color2" value="D1E231"/><font color="#D1E231"> Грушевый</font><br/>
<input type="radio" name="color2" value="4B0082"/><font color="#4B0082"> Индиго</font><br />
<input type="radio" name="color2" value="8A2BE2"/><font color="#8A2BE2"> Фиолетовый</font><br />
<input type="radio" name="color2" value="991199"/><font color="#991199"> Фиолетово-баклажанный</font><br />
<input type="radio" name="color2" value="008B8B"/><font color="#008B8B"> Темно-голубой</font><br />
<input type="radio" name="color2" value="4682B4"/><font color="#4682B4"> Голубая сталь</font><br />
<input type="radio" name="color2" value="87CEEB"/><font color="#87CEEB"> Светло-голубой</font><br />
<input type="radio" name="color2" value="FF7F50"/><font color="#FF7F50"> Кораловый</font><br />
<input type="radio" name="color2" value="8B4513"/><font color="#8B4513"> Коричневый</font><br />
<input type="radio" name="color2" value="FF2400"/><font color="#FF2400"> Алый</font><br />
<input type="radio" name="color2" value="DC143C"/><font color="#DC143C"> Малиновый</font><br />
<input type="radio" name="color2" value="FF1493"/><font color="#FF1493"> Ярко-розовый</font><br />
<input type="radio" name="color2" value="FF69B4"/><font color="#FF69B4"> Розовый</font><br />
<input type="radio" name="color2" value="FF8C00"/><font color="#FF8C00"> Оранжевый</font><br />
<input type="radio" name="color2" value="FFD700"/><font color="#FFD700"> Золото</font><br />
<input type="radio" name="color2" value="BDB76B"/><font color="#BDB76B"> Хаки</font><br />
<input type="radio" name="color2" value="FFA07A"/><font color="#FFA07A"> Оранжево-розовый</font><br />
<input type="radio" name="color2" value="008080"/><font color="#008080"> Мурена</font><br />
<input type="radio" name="color2" value="FFDB58"/><font color="#FFDB58"> Горчичный</font><br />
<input type="radio" name="color2" value="40826D"/><font color="#40826D"> Ядовито-зелёный</font><br />
<input type="radio" name="color2" value="1E90FF"/><font color="#1E90FF"> Защитно-синий</font><br />
<input type="radio" name="color2" value="808000"/><font color="#808000"> Оливковый</font><br />
<input type="radio" name="color2" value="660000"/><font color="#660000"> Коричнево-малиновый</font><br />
<input type="radio" name="color2" value="D2B48C"/><font color="#D2B48C"> Желто-коричневый</font><br/>


<input type="submit" name="submit" value="Sotib olish"/></form></div>';
echo '<div class="menu"><a href="col.php?act=entergradient">Kod kiritish</a></div>';
}else{
echo '<div class="menu">Sizda'.$user['balans'].' ball, xizmat uchun '.$b.' kerak</div>';
}
break;
case 'gradientbuy' :

if($user['balans']>=$b){
$color = ($_POST['color']); 
$color2 = ($_POST['color2']); 
mysql_query("UPDATE `users` SET `colornick` = '$color', `colornick2` = '$color2' ,`balans`=`balans`-$b  WHERE `id` = '$user_id' LIMIT 1");
echo '<div class="menu">Поздравлем с покупкой цветного ника, теперь он стал таким: '.functions::gradient(''.$login.'', '' .$color. '',''.$color2.'').'. С вашего баланса снято 1000 баллов</div>';
}else{
echo '<div class="menu">Sizda '.$user['balans'].' ball, xizmat uchun '.$b.'. kerak</div>';
}
break;




case 'color' :

if($user['balans']>=$a){
echo '<div><form action="col.php?act=colorbuy" name="color" method="post"> 
<input type="radio" name="color" value="006400"/><font color="#006400"> Темно-зеленый</font><br />
<input type="radio" name="color" value="0000FF"/><font color="#0000FF"> Синий</font><br />
<input type="radio" name="color" value="000080"/><font color="#000080"> Темно-синий</font><br />
<input type="radio" name="color" value="00FFFF"/><font color="#00FFFF"> Голубой</font><br />
<input type="radio" name="color" value="FFFF00"/><font color="#FFFF00"> Желтый</font><br />
<input type="radio" name="color" value="808080"/><font color="#808080"> Серый</font><br />
<input type="radio" name="color" value="C0C0C0"/><font color="#C0C0C0"> Светло-серый</font><br />
<input type="radio" name="color" value="9ACD32"/><font color="#9ACD32"> Желто-зеленый</font><br />
<input type="radio" name="color" value="7FFF00"/><font color="#7FFF00"> Салатовый</font><br />
<input type="radio" name="color" value="90EE90"/><font color="#90EE90"> Светло-зеленый</font><br />
<input type="radio" name="color" value="D1E231"/><font color="#D1E231"> Грушевый</font><br/>
<input type="radio" name="color" value="4B0082"/><font color="#4B0082"> Индиго</font><br />
<input type="radio" name="color" value="8A2BE2"/><font color="#8A2BE2"> Фиолетовый</font><br />
<input type="radio" name="color" value="991199"/><font color="#991199"> Фиолетово-баклажанный</font><br />
<input type="radio" name="color" value="008B8B"/><font color="#008B8B"> Темно-голубой</font><br />
<input type="radio" name="color" value="4682B4"/><font color="#4682B4"> Голубая сталь</font><br />
<input type="radio" name="color" value="87CEEB"/><font color="#87CEEB"> Светло-голубой</font><br />
<input type="radio" name="color" value="FF7F50"/><font color="#FF7F50"> Кораловый</font><br />
<input type="radio" name="color" value="8B4513"/><font color="#8B4513"> Коричневый</font><br />
<input type="radio" name="color" value="FF2400"/><font color="#FF2400"> Алый</font><br />
<input type="radio" name="color" value="DC143C"/><font color="#DC143C"> Малиновый</font><br />
<input type="radio" name="color" value="FF1493"/><font color="#FF1493"> Ярко-розовый</font><br />
<input type="radio" name="color" value="FF69B4"/><font color="#FF69B4"> Розовый</font><br />
<input type="radio" name="color" value="FF8C00"/><font color="#FF8C00"> Оранжевый</font><br />
<input type="radio" name="color" value="FFD700"/><font color="#FFD700"> Золото</font><br />
<input type="radio" name="color" value="BDB76B"/><font color="#BDB76B"> Хаки</font><br />
<input type="radio" name="color" value="FFA07A"/><font color="#FFA07A"> Оранжево-розовый</font><br />
<input type="radio" name="color" value="008080"/><font color="#008080"> Мурена</font><br />
<input type="radio" name="color" value="FFDB58"/><font color="#FFDB58"> Горчичный</font><br />
<input type="radio" name="color" value="40826D"/><font color="#40826D"> Ядовито-зелёный</font><br />
<input type="radio" name="color" value="1E90FF"/><font color="#1E90FF"> Защитно-синий</font><br />
<input type="radio" name="color" value="808000"/><font color="#808000"> Оливковый</font><br />
<input type="radio" name="color" value="660000"/><font color="#660000"> Коричнево-малиновый</font><br />
<input type="radio" name="color" value="D2B48C"/><font color="#D2B48C"> Желто-коричневый</font><br />

<input type="submit" name="submit" value="Sotib olish"/></form></div>';
echo '<div class="menu"><a href="col.php?act=entercolor">Kodni kiritish</a></div>';
}else{
echo '<div class="menu">Sizda '.$user['balans'].' ball, xizmat uchun '.$a.' kerak</div>';

}
break;
case 'colorbuy' :

if($user['balans']>=$a){
$color = ($_POST['color']); 
mysql_query("UPDATE `users` SET `colornick` = '$color', `colornick2` = '$color' ,`balans`=`balans`-$a  WHERE `id` = '$user_id' LIMIT 1");

echo '<div class="menu">Endi sizni nikiz: '.functions::gradient(''.$login.'', '' .$color. '',''.$color.'').'.</div>';
}else{
echo '<div class="menu">Sizda '.$user['balans'].' ball, xizmat uchun '.$a.' kerak</div>';
}
break;



case 'entercolor' :
if($user['balans']>=$a){
echo'<div class="phdr">Выбор в ручную</div>';
echo'<span style="color:red"><b>Цвет вводить ЗАГЛАВНЫМИ буквами!  Без # <br/>Например: FF0000</b></span><br/>';
echo'<a href="?act=tablcolors">Таблица цветов</a>';
echo'<div><form action="col.php?act=entercolorbuy" name="color" method="post">
Цвет: # <textarea name="color" cols="6" rows="1"></textarea><br/>
<input type="submit" name="submit" value="Купить"/></form></div>';
echo '<div class="menu"><a href="col.php?act=color">Выбрать из списка</a></div>';
}else{
echo '<div class="menu">У тебя '.$user['balans'].' баллов, а нужно $a. Приходи когда накопишь</div>';
}
break;

case 'entercolorbuy' :

if($user['balans']>=$a){
$color = ($_POST['color']); 
mysql_query("UPDATE `users` SET `colornick` = '$color', `colornick2` = '$color' ,`balans`=`balans`-$a  WHERE `id` = '$user_id' LIMIT 1");

echo '<div class="menu">Поздравлем с покупкой цветного ника, теперь он стал таким: '.functions::gradient(''.$login.'', '' .$color. '',''.$color.'').'. С вашего баланса снято 500 баллов</div>';

}else{
echo '<div class="menu">У тебя '.$user['balans'].', а нужно '.$a.'. Приходи когда накопишь</div>';
}
break;


case 'entergradient' :

if($user['balans']>=$b){
echo'<div class="phdr">Выбор в ручную</div>';
echo'<span style="color:red"><b>Цвет вводить ЗАГЛАВНЫМИ буквами!  Без # <br/>Например: FF0000</b></span><br/>';
echo'<a href="?act=tablcolors">Таблица цветов</a>';
echo'<div><form action="col.php?act=entergradientbuy" name="color" method="post">
Начальный цвет: # <textarea name="color" cols="6" rows="1"></textarea><br/>
Конечный цвет: # <textarea name="color2" cols="6" rows="1"></textarea><br/>
<input type="submit" name="submit" value="Купить"/></form></div>';
echo '<div class="menu"><a href="col.php?act=gradient">Выбрать из списка</a></div>';
}else{
echo '<div class="menu">У тебя '.$user['balans'].', а нужно '.$b.'. Приходи когда накопишь</div>';
}
break;

case 'entergradientbuy' :

if($user['balans']>=$b){
$color = ($_POST['color']); 
$color2 = ($_POST['color2']); 
mysql_query("UPDATE `users` SET `colornick` = '$color', `colornick2` = '$color2' ,`balans`=`balans`-$b  WHERE `id` = '$user_id' LIMIT 1");

echo '<div class="menu">Поздравлем с покупкой цветного ника, теперь он стал таким: '.functions::gradient(''.$login.'', '' .$color. '',''.$color2.'').'. С вашего баланса снято 1000 баллов</div>';

}else{
echo '<div class="menu">У тебя '.$user['balans'].', а нужно '.$b.'. Приходи когда накопишь</div>';
}
break;




case 'tablcolors' :
            include ('../css/colors.inc');
           
            break;  
            

default :

echo '<div class="menu">';
    
echo '<li><a href="col.php?act=color"><span style="color:#' . $colornick['colornick'] . '">Bittalik rang</span></a> '.$a.' ball</li>';
echo'<li><a href="col.php?act=gradient">'.functions::gradient('Gradient', ''.$colornick['colornick'].'',''.$colornick['colornick2'].'').'</a> '.$b.' ball</li>';
echo'</div>';
}
 echo'<div class="menu"><a href="col.php">К выбору</a></div>';
require ("../incfiles/end.php");
?>