<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);

require_once('../incfiles/core.php');
$textl = 'Narxlarni belgilash';
require_once('../incfiles/head.php');

/***********
 МаГазин для сайта
 Аффтар - ValekS
 http://john-help.ru
***********/
if ($rights > 6 and $user_id){
echo '<div class="phdr"><a href="/shop/">Magazin '.str_replace('http://', '',$set['homeurl']).'</a> | Narxlarni belgilash</div>';

switch ($act) {
case 'price':
if (isset($_POST['submit'])) {
    // Принимаем данные
    $pr1 = isset($_POST['status']) ? abs(intval($_POST['status'])) : '';
    $pr2 = isset($_POST['login']) ? abs(intval($_POST['login'])) : '';
    $pr3 = isset($_POST['karmap']) ? abs(intval($_POST['karmap'])) : '';
    $pr4 = isset($_POST['karmam']) ? abs(intval($_POST['karmam'])) : '';
    $pr5 = isset($_POST['amail']) ? abs(intval($_POST['amail'])) : '';
    $pr6 = isset($_POST['cnick']) ? abs(intval($_POST['cnick'])) : '';
    $pr7 = isset($_POST['cstat']) ? abs(intval($_POST['cstat'])) : '';
	$pr8 = isset($_POST['col1']) ? abs(intval($_POST['col1'])) : '';
	$pr9 = isset($_POST['col2']) ? abs(intval($_POST['col2'])) : '';
    $error = false;

    // Провереряем данные цена
    if (empty($pr1) || empty($pr2) || empty($pr3) || empty($pr4) || empty($pr5) || empty($pr6) || empty($pr7) || empty($pr8) || empty($pr9))
        $error = $error . 'Narx kiritilmadi!<br />';

    if (preg_match('/[^\d]+/', $pr1) || preg_match('/[^\d]+/', $pr2) || preg_match('/[^\d]+/', $pr3) || preg_match('/[^\d]+/', $pr4) || preg_match('/[^\d]+/', $pr5) || preg_match('/[^\d]+/', $pr6) || preg_match('/[^\d]+/', $pr7))
        $error = $error . 'Narx o\'rnida noma\'lum belgilar!<br />';

    // Заносим данные в БД
    if (empty($error)) {

    mysql_query("UPDATE `shop` SET `price` = CASE WHEN `id` = 1 THEN '$pr1' WHEN `id` = 2 THEN '$pr2' WHEN `id` = 3 THEN '$pr3' WHEN `id` = 4 THEN '$pr4' WHEN `id` = 10 THEN '$pr5' WHEN `id` = 11 THEN '$pr6' WHEN `id` = 12 THEN '$pr7' WHEN `id` = 14 THEN '$pr8' WHEN `id` = 15 THEN '$pr9' END WHERE `id` IN('1', '2', '3', '4', '10', '11', '12', '14', '15')");

        echo '<div class="gmenu">Narxlar o\'rnatildi!</div>';
    } else {
        echo '<div class="rmenu"><p><b>XATOLIK!</b><br />' . $error . '</p></div>';
    }
       }
     // запросы на цены
    $price_sql = mysql_query("SELECT `price` FROM `shop` WHERE `id` IN('1', '2', '3', '4', '10', '11', '12', '14', '15')");
    $i = 1;
    $arr = array(1 => "Status o\'rnatish:","Nikni o\'zgartirish:","Карма +:","Карма -:","Anonim xabar:","Rangli NIK:","Rangli status:","Bittalik rang","Gradient rang");
    $arr2 = array(1 => "status","login","karmap","karmam","amail","cnick","cstat","col1","col2");
    $arr3 = array(1 =>
    "Status o'rnatish uchun userdan olinadigan tangalar miqdorini ko'rsating",
    "Nikni o'zgartirish uchun userdan olinadigan tangalar miqdorini ko'rsating",
    "Karmaga + ovoz olish uchun userdan olinadigan tangalar miqdorini ko'rsating",
    "Karmadan - ovozni o'chirish uchun userdan olinadigan tangalar miqdorini ko'rsating",
    "Anonim xabar yo'llash uchun userdan olinadigan tangalar miqdorini ko'rsating",
    "Nik rangini o\'zgartirish uchun userdan olinadigan tangalar miqdorini ko'rsating",
    "Status rangini o\'zgartirish uchun userdan olinadigan tangalar miqdorini ko'rsating",
	"Nikni bitta rangga bo'yash narxi",
	"Nikni gradientli boyash narxi");

    echo '<div class="list2">Xizmat narxlarini belgilaymiz</div>';
    echo '<form action="adm.php?act=price" method="post">';

    while ($price = mysql_fetch_assoc($price_sql)) {
    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';

    echo '<p><b>'.$arr[''.$i.''].'</b><br/><input type="text" name="'.$arr2[''.$i.''].'" maxlength="15" value="' . $price['price'] . '" /><br/><small>'.$arr3[''.$i.''].'</small></p>';

    echo '</div>';
    ++$i;
    }

    echo '<div class="list2"><input type="submit" name="submit" value="Narxlarni o\'rnatish"/></div></form>';
    break;

case 'balans':
    if (isset($_POST['submit'])) {
    // Принимаем данные
    $mn1 = isset($_POST['bonus']) ? abs(intval($_POST['bonus'])) : '';
    $mn2 = isset($_POST['fpost']) ? abs(intval($_POST['fpost'])) : '';
    $mn3 = isset($_POST['nt']) ? abs(intval($_POST['nt'])) : '';
    $mn4 = isset($_POST['gpost']) ? abs(intval($_POST['gpost'])) : '';
    $mn5 = isset($_POST['komm']) ? abs(intval($_POST['komm'])) : '';
    $mn6 = isset($_POST['reg']) ? abs(intval($_POST['reg'])) : '';
    $error = false;


    // Провереряем данные
    if (empty($mn1) || empty($mn2) || empty($mn3) || empty($mn4) || empty($mn5) || empty($mn6))
    $error = $error . 'Tangalar miqdori ko\'rsatilmadi!<br />';

    if (preg_match('/[^\d]+/', $mn1) || preg_match('/[^\d]+/', $mn2) || preg_match('/[^\d]+/', $mn3) || preg_match('/[^\d]+/', $mn4) || preg_match('/[^\d]+/', $mn5) || preg_match('/[^\d]+/', $mn6))
    $error = $error . 'Недопустимые символы!<br />';

    // Заносим данные в БД
    if (empty($error)) {
        mysql_query("UPDATE `shop` SET `price` = CASE WHEN `id` = 5 THEN '$mn1' WHEN `id` = 6 THEN '$mn2' WHEN `id` = 7 THEN '$mn3' WHEN `id` = 8 THEN '$mn4' WHEN `id` = 9 THEN '$mn5' WHEN `id` = 13 THEN '$mn6' END WHERE `id` IN('5', '6', '7', '8', '9', '13')");
        echo '<div class="gmenu">Tanga ayirboshlash o\'rnatildi!</div>';
    } else {
        echo '<div class="rmenu"><p><b>XATOLIK!</b><br />' . $error . '</p></div>';
    }
       }

    // запрос на цены
    $price_sql = mysql_query("SELECT `price` FROM `shop` WHERE `id` IN('5', '6', '7', '8', '9', '13')");

    $i = 1;

    $arr = array(1 => "Kunlik bonus:","Forumdagi post uchun:","Yangi mavzu uchun:","Mexmonxonadagi post uchun:","Komment uchun:","Registratsiya uchun:");
    $arr2 = array(1 => "bonus","fpost","nt","gpost","komm","reg");
    $arr3 = array(1 =>
    "Userga kunlik beriladigan bonus tangalar miqdorini ko'rsating",
    "Forumdagi post uchun userga beriladigan tangalar miqdorini ko'rsating",
    "Yangi mavzu uchun userga beriladigan tangalar miqdorini ko'rsating",
    "Mexmonxonadagi post uchun userga beriladigan tangalar miqdorini ko'rsating",
    "Komment uchun userga beriladigan tangalar miqdorini ko\'rsating",
    "Ro\'yxatdan o\'tgani uchun userga beriladigan tangalar miqdorini ko'rsating");

    echo '<div class="list2">Admin, bu yerda postlar uchun userga beriladigan tangalar miqdorini belgilaysiz.<br/>Shuningdek kunlik bonus tangalar miqdorini ham.</div>';
    echo '<form action="adm.php?act=balans" method="post">';

    while ($price = mysql_fetch_assoc($price_sql)) {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';

        echo '<p><b>'.$arr[''.$i.''].'</b><br/><input type="text" name="'.$arr2[''.$i.''].'" maxlength="15" value="' . $price['price'] . '" /><br/><small>'.$arr3[''.$i.''].'</small></p>';

        echo '</div>';
        ++$i;
    }

    echo '<div class="list2"><input type="submit" name="submit" value="Narxni o\rnatish"/></div></form>';
    break;

default:
echo '<div class="gmenu">Admin, buyerda siz sayt xizmatlari uchun narxlarni belgilaysiz.<br/>Va tanga ayirboshlashni ham.<br/>Shuningdek, kunlik bonus tangalar miqdorini ham.</div>';
echo '<div class="list1"><a href="adm.php?act=price">Xizmat narxlari</a></div>';
echo '<div class="list2"><a href="adm.php?act=balans">Bonus / post uchun beriladigan tangalar</a></div>';
      }
}

require_once('../incfiles/end.php');
?>