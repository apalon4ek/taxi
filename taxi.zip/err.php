<?php

define('_IN_JOHNCMS', 1);

$rootpath = '';
require('incfiles/core.php');
require('incfiles/head.php');

echo '<div class="menu" align="center">Kechirasiz ushbu sahifada tamirlash ishlari olib borilmoqda <br/> Keyinroq urunib ko\'ring!</div>';
require_once ("incfiles/end.php");

?>