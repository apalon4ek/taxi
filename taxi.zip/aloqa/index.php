<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$textl = 'Biz haqimizda';
$headmod = 'haqimizda';
require('../incfiles/head.php');


echo'<div class="phdr"><b>Biz bilan aloqa</b></div>';

echo '<div class="menu"><img src="/images/yosh/tab_contacts.png" alt="+"/>  <b><span style="border-style: double; color:blue; padding:3px;"><span style="color:red;">Haydaraliyev Abbosjon</span></span></b></div>';

echo'<div class="menu"><img src="/images/yosh/tel.gif" alt="+"/>Uyali aloqa: <b>+998-90-292-88-55</b></div>';

echo'<div class="menu">Telegram: <a href="https://t.me/@"><b>@HAQ</b></a></div>';
echo'<div class="menu">E-mail: <a href="https://"><b>e mail</b></a></div>';





require('../incfiles/end.php');
?>
