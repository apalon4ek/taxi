<?php

define('_IN_JOHNCMS', 1);

if (preg_match('/windows|linux|macintosh|unix|macos|bsd/i', $_SERVER['HTTP_USER_AGENT']))
{
if ($_GET['mode'] == 'web')
{ 
SetCookie("theme", "web", time() + 3600 * 24 * 365);
header('Location: /index.php');
} else {
SetCookie("theme", "wap", time() + 3600 * 24 * 365);
header('Location: /index.php');
} 
} else {
header ('Location: /index.php');
}
?>