<?php
define('_IN_JOHNCMS', 1);
$headmod = 'alimail';
$textl = 'Xabar yuborish';
require('../incfiles/core.php');
require('../incfiles/head.php');
 if ($rights != 9) {
            echo '<div class="rmeni">Error! Error! Error!</div>';
require('../incfiles/end.php');
exit;
 }
 switch ($act) {
 default:
 echo '<div class="phdr" align="center">Xabar yuborish | <a href="alimail.php?act=faq">F.A.Q.</a></div>';
 echo '<div class="list1">';
 echo'<form action="alimail.php?act=send" method="POST">Kimdan: <select name="sysadm"> <option value="0">Tizim</option> <option value="1">ID:1</option></select>  Kimga: <select name="whom"><option value="1">hamma</option><option value="2">yigitlar</option><option value="3">qizlar</option><option value="4">administratsiya</option></select><br /> <textarea name="message" cols="30" rows="5"></textarea> <br /> <input type="submit" name="submit" value="Yuborish" /> </form></div>';
 break;

 case 'send':
        $message = isset($_POST['message']) ? functions::checkin(mb_substr(trim($_POST['message']), 0, 500)) : '';
        $sysadm = isset($_POST['sysadm']) ? functions::checkin(mb_substr(trim($_POST['sysadm']), 0, 1)) : '';
        $whom = isset($_POST['whom']) ? functions::checkin(mb_substr(trim($_POST['whom']), 0, 1)) : '';
  if (empty($message)) {
 echo '<div class="rmenu">Siz bo\'sh xabar yubora olmaysiz!</div>';
 require('../incfiles/end.php');
exit;
 }
 if ($whom == 1) {
    $userid = mysql_query("SELECT `id` FROM `users` WHERE `lastdate` > '" . (time() - 1209600) . "'");
 } elseif ($whom == 2) {
    $userid = mysql_query("SELECT `id` FROM `users` WHERE `sex` = 'm' AND `lastdate` > '" . (time() - 2592000) . "'");
 } elseif ($whom == 3) {
     $userid = mysql_query("SELECT `id` FROM `users` WHERE `sex` = 'zh' AND `lastdate` > '" . (time() - 2592000) . "'");
 } elseif ($whom == 4) {
    $userid = mysql_query("SELECT `id` FROM `users` WHERE `rights` != '0'");
 }
 $i = 0;
while ($who = mysql_fetch_array($userid)) {
 if ($sysadm == 0) {
 $sys = 1;
 } else {
 $sys = 0;
 }
 mysql_query("INSERT INTO `cms_mail` SET `user_id` = '".$sysadm."', `from_id` = '".$who['id']."', `text` = '".mysql_real_escape_string($message)."', `time` = '".time()."', `sys` = '".$sys."', them = 'Message'");
$i++;
 }
 echo '<div class="phdr align="center">Natijalar:</div><div class="list2">Xabaringiz '.$i.' nafar foydalanuvchiga yetkazildi.</div>';
 break;

 case 'faq';
  echo '<div class="phdr" align="center"><a href="alimail.php">Xabar yuborish</a> | F.A.Q.</div>'; 
 echo '<div class="list1">Hamma - oxirgi tashrifi ikki haftadan uzoq bo\'lmagan userlarga xabar yuboriladi.</div><div class="list2"> Yigitlar - oxirgi tashrifi bir oydan uzoq bo\'lmagan yigitlarga xabar yuboriladi.</div><div class="list1"> Qizlarga - oxirgi tashrifi bir oydan uzoq bo\'lmagan qizlarga xabar yuboriladi.. </div><div class="list2">Administratsiya - barcha administratsiya a\'zolariga xabar yuboradi.</div>';
break;
}
 require('../incfiles/end.php');
?>