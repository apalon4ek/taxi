<?php
define('_IN_JOHNCMS', 1);
$textl = 'Bosh sahifa boshqaruvi';
require('../incfiles/core.php');
require('../incfiles/head.php');
 if ($rights != 9) {
	 echo '<div class="menu">Siz sekin surib qoling buyerdan, admin bo\'ganizda kelas!!!</div>';
	 require('../incfiles/end.php');
	 exit;
	}
	switch ($act) {
	default:
	$forum = mysql_result(mysql_query("SELECT `value` FROM `sitesets` WHERE `id` = '1'"), 0);
	$yuklama = mysql_result(mysql_query("SELECT `value` FROM `sitesets` WHERE `id` = '2'"), 0);
	$choyxor = mysql_result(mysql_query("SELECT `value` FROM `sitesets` WHERE `id` = '3'"), 0);
	$hikoya = mysql_result(mysql_query("SELECT `value` FROM `sitesets` WHERE `id` = '5'"), 0);
	echo '<div class="list2"><form action="homeset.php?act=save" method="POST">
	<div class="menu">Forumdagi nechta so\'nggi mavzu chiqsin '.$forum['value'].' (nol - o\'chr):<br />
	<select name="forum"><option value="0">Ochr</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="5">5</option><option value="7">7</option><option value="10">10</option></select></div>
	<div class="menu">Nechta oxirgi yuklama chiqsin (nol - o\'chr):<br />
	<input type="text" name="yuklama" value="'.$yuklama['value'].'" length="2" size="2" /></div>
	<div class="menu">Nechta faol user (module choyxor) chiqsin (nol - o\'chr):<br />
	<input type="text" name="choyxor" value="'.$choyxor['value'].'" length="2" size="2" /></div>
	<div class="menu">Kutubxona bo\'limlari chiqsinmi<br /> <select name="kbolim"><option value="1">Ha</option><option value="0">Yo\'q</option></select> </div>
	<div class="menu">Kutubxonaning nechta oxirgi maqolasi chiqsin (nol - o\'chr):<br />
	<input type="text" name="hikoya" value="'.$hikoya['value'].'" length="2" size="2" /></div>
	<input type="submit" value="Saqlash" /></form></div>';	
	break;
	
	case 'save':
	$forum = isset($_POST['forum']) ? functions::check(mb_substr($_POST['forum'], 0, 2)) : '';
	$yuklama = isset($_POST['yuklama']) ? functions::check(mb_substr($_POST['yuklama'], 0, 2)) : '';
	$choyxor = isset($_POST['choyxor']) ? functions::check(mb_substr($_POST['choyxor'], 0, 2)) : '';
	$kbolim = isset($_POST['kbolim']) ? functions::check(mb_substr($_POST['kbolim'], 0, 2)) : '';
	$hikoya = isset($_POST['hikoya']) ? functions::check(mb_substr($_POST['hikoya'], 0, 2)) : '';
	mysql_query("UPDATE `sitesets` SET `value` = '".mysql_real_escape_string($forum)."' WHERE `id` = '1'");
	mysql_query("UPDATE `sitesets` SET `value` = '".mysql_real_escape_string($yuklama)."' WHERE `id` = '2'");
	mysql_query("UPDATE `sitesets` SET `value` = '".mysql_real_escape_string($choyxor)."' WHERE `id` = '3'");
	mysql_query("UPDATE `sitesets` SET `value` = '".mysql_real_escape_string($kbolim)."' WHERE `id` = '4'");
	mysql_query("UPDATE `sitesets` SET `value` = '".mysql_real_escape_string($hikoya)."' WHERE `id` = '5'");
	echo '<div class="gmenu">SAQLANDI!</div><div class="list2"><a href="index.php">Admin Panelga</a></div>';
	break;
	}

require('../incfiles/end.php');
?>