<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

/*
-----------------------------------------------------------------
Закрываем доступ для определенных ситуаций
-----------------------------------------------------------------
*/
if (!$id || !$user_id || isset($ban['1']) || isset($ban['11']) || (!core::$user_rights && $set['mod_forum'] == 3)) {
    require('../incfiles/head.php');
    echo functions::display_error($lng['access_forbidden']);
    require('../incfiles/end.php');
    exit;
}

/*
-----------------------------------------------------------------
Вспомогательная Функция обработки ссылок форума
-----------------------------------------------------------------
*/
function forum_link($m)
{
    global $set;
    if (!isset($m[3])) {
        return '[url=' . $m[1] . ']' . $m[2] . '[/url]';
    } else {
        $p = parse_url($m[3]);
        if ('http://' . $p['host'] . (isset($p['path']) ? $p['path'] : '') . '?id=' == $set['homeurl'] . '/forum/index.php?id=') {
            $thid = abs(intval(preg_replace('/(.*?)id=/si', '', $m[3])));
            $req = mysql_query("SELECT `text` FROM `forum` WHERE `id`= '$thid' AND `type` = 't' AND `close` != '1'");
            if (mysql_num_rows($req) > 0) {
                $res = mysql_fetch_array($req);
                $name = strtr($res['text'], array(
                    '&quot;' => '',
                    '&amp;'  => '',
                    '&lt;'   => '',
                    '&gt;'   => '',
                    '&#039;' => '',
                    '['      => '',
                    ']'      => ''
                ));
                if (mb_strlen($name) > 40)
                    $name = mb_substr($name, 0, 40) . '...';

                return '[url=' . $m[3] . ']' . $name . '[/url]';
            } else {
                return $m[3];
            }
        } else
            return $m[3];
    }
}

// Проверка на флуд
$flood = functions::antiflood();
if ($flood) {
    require('../incfiles/head.php');
    echo functions::display_error($lng['error_flood'] . ' ' . $flood . $lng['sec'] . ', <a href="index.php?id=' . $id . '&amp;start=' . $start . '">' . $lng['back'] . '</a>');
    require('../incfiles/end.php');
    exit;
}

$req_r = mysql_query("SELECT * FROM `forum` WHERE `id` = '$id' AND `type` = 'r' LIMIT 1");
if (!mysql_num_rows($req_r)) {
    require('../incfiles/head.php');
    echo functions::display_error($lng['error_wrong_data']);
    require('../incfiles/end.php');
    exit;
}
$res_r = mysql_fetch_assoc($req_r);

$th = isset($_POST['th']) ? functions::check(mb_substr(trim($_POST['th']), 0, 100)) : '';
$msg = isset($_POST['msg']) ? functions::checkin(trim($_POST['msg'])) : '';
if (isset($_POST['msgtrans'])) {
    $th = functions::trans($th);
    $msg = functions::trans($msg);
}
$msg = preg_replace_callback('~\\[url=(http://.+?)\\](.+?)\\[/url\\]|(http://(www.)?[0-9a-zA-Z\.-]+\.[0-9a-zA-Z]{2,6}[0-9a-zA-Z/\?\.\~&amp;_=/%-:#]*)~', 'forum_link', $msg);
if (isset($_POST['submit'])
    && isset($_POST['token'])
    && isset($_SESSION['token'])
    && $_POST['token'] == $_SESSION['token']
) {
    $error = array();
    if (empty($th))
        $error[] = $lng_forum['error_topic_name'];
    if (mb_strlen($th) < 2)
        $error[] = $lng_forum['error_topic_name_lenght'];
    if (empty($msg))
        $error[] = $lng['error_empty_message'];
    if (mb_strlen($msg) < 4)
        $error[] = $lng['error_message_short'];
    if (!$error) {
        $msg = preg_replace_callback('~\\[url=(http://.+?)\\](.+?)\\[/url\\]|(http://(www.)?[0-9a-zA-Z\.-]+\.[0-9a-zA-Z]{2,6}[0-9a-zA-Z/\?\.\~&amp;_=/%-:#]*)~', 'forum_link', $msg);
        // Прверяем, есть ли уже такая тема в текущем разделе?
        if (mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `refid` = '$id' AND `text` = '$th'"), 0) > 0)
            $error[] = $lng_forum['error_topic_exists'];
        // Проверяем, не повторяется ли сообщение?
        $req = mysql_query("SELECT * FROM `forum` WHERE `user_id` = '$user_id' AND `type` = 'm' ORDER BY `time` DESC");
        if (mysql_num_rows($req) > 0) {
            $res = mysql_fetch_array($req);
            if ($msg == $res['text'])
                $error[] = $lng['error_message_exists'];
        }
    }
    if (!$error) {
        unset($_SESSION['token']);

        // Если задано в настройках, то назначаем топикстартера куратором
        $curator = $res_r['edit'] == 1 ? serialize(array($user_id => $login)) : '';

        // Добавляем тему
        mysql_query("INSERT INTO `forum` SET
            `refid` = '$id',
            `type` = 't',
            `time` = '" . time() . "',
            `user_id` = '$user_id',
            `from` = '$login',
            `text` = '$th',
            `soft` = '',
            `edit` = '',
            `curators` = '$curator'
        ");
        $rid = mysql_insert_id();

        // Добавляем текст поста
        mysql_query("INSERT INTO `forum` SET
            `refid` = '$rid',
            `type` = 'm',
            `time` = '" . time() . "',
            `user_id` = '$user_id',
            `from` = '$login',
            `ip` = '" . core::$ip . "',
            `ip_via_proxy` = '" . core::$ip_via_proxy . "',
            `soft` = '" . mysql_real_escape_string($agn) . "',
            `text` = '" . mysql_real_escape_string($msg) . "',
            `edit` = '',
            `curators` = ''
        ");

        $postid = mysql_insert_id();

        // Записываем счетчик постов юзера
        $fpst = $datauser['postforum'] + 1;
        mysql_query("UPDATE `users` SET
            `postforum` = '$fpst',
            `lastpost` = '" . time() . "'
            WHERE `id` = '$user_id'
        ");

        // Ставим метку о прочтении
        mysql_query("INSERT INTO `cms_forum_rdm` SET
            `topic_id`='$rid',
            `user_id`='$user_id',
            `time`='" . time() . "'
        ");

        if ($_POST['addfiles'] == 1) {
            header("Location: index.php?id=$postid&act=addfile");
        } else {
            header("Location: index.php?id=$rid");
        }
    } else {
        // Выводим сообщение об ошибке
        require('../incfiles/head.php');
        echo functions::display_error($error, '<a href="index.php?act=nt&amp;id=' . $id . '">' . $lng['repeat'] . '</a>');
        require('../incfiles/end.php');
        exit;
    }
} else {
    $req_c = mysql_query("SELECT * FROM `forum` WHERE `id` = '" . $res_r['refid'] . "'");
    $res_c = mysql_fetch_assoc($req_c);
    require('../incfiles/head.php');
    if ($datauser['postforum'] == 0) {
        if (!isset($_GET['yes'])) {
		    echo '<div class="phdr"><a href="faq.php"><b>Ma\'lumot FAQ</b></a> | Forum qoidalari</div>
<div class="menu"><h3>Mavzu ochish</h3></div>
<div class="menu"><b>1.1 Bir xil o\'xshash mavzu</b><br/>
Bir xil o\'xshash mavzular ochish taqiqlanadi. Agarda shunday mavzu bor bo\'lsa (agar yopilgan bo\'lsa Moderatorlarga murojat qiling) o\'sha mavzuda davom ettiring.</div>
<div class="menu"><b>1.2 Flud mavzu</b><br/>
Bir vaqtning o\'zida podforumlarda bir xil mavzular yaratish taqiqlanadi.</div>
<div class="menu"><b>1.3 Yopilgan mavzularni davom ettirish</b><br/>
Ma\'muriyat tomonidan yopilgan mavzularni davom ettirish taqiqlanadi.</div>
<div class="menu"><b>1.4 Hech qanday ma\'lumotga ega bo\'lmagan mavzu nomlari</b><br/>
Mavzu nomi uni tarkibini (qisman bo\'lsada) aks ettirishi lozim. &quot;Yordam kerak&quot;, &quot;Muammo bor&quot; kabi ko\'rinishdagi mavzular ogohlantirishsiz o\'chiriladi yoki o\'zgartiriladi.</div>
<div class="menu"><b>1.5 Aniq bir foydalanuvchiga murojat</b><br/>
Forumda ma\'lum bir foydalanuvchiga qaratilgan mavzu ochish taqiqlanadi. Bunday vaziyatlarda shaxsiy xabarlardan foydalanishingiz mumkin.</div>
<div class="menu"><b>1.6 Ajratib ko\'rsatilgan mavzular</b><br/>
Mavzularni nomlash faqat katta harflarda (bunga extiyoj bo\'lmasa ham) foydalanish va har xil belgilar bilan bezak berish taqiqlanadi.</div>
<div class="menu"><b>1.7 Tematika</b><br/>
Millatchilik, davlat siyosatiga aralashish, diniy mavzulardagi mavzular qat\'iyan taqiqlanadi.</div>
<div class="menu"><b>1.8 Podforumlar uchun alohida mavzular</b><br/>
Bazi podforumlarda shu bo\'lim uchun mavzu qoidalar mavjud, ular bilan tanishib chiqib amal qilishingiz lozim.</div>

<div class="menu"><h3>Xabar qoldirish</h3></div>
<div class="menu"><b>2.1 Flud</b><br/>
Mavzularda takroriy xabarlar qoldirish taqiqlanadi.</div>
<div class="menu"><b>2.2 Offtop (mavzudan chetlashish)</b><br/>
Belgilangan mavzudan chetlashish, mavzuga aloqador bo\'lmagan xabar qoldirish taqiqlanadi.</div>
<div class="menu"><b>2.3 Fleym</b><br/>
Shaxsiy adovat sababli qo\'pol ohangda (tekkizib) gapirish, masxaralash taqiqlanadi.</div>
<div class="menu"><b>2.4 Reklama</b><br/>
To\'g\'ridan to\'g\'ri ssilka o\'rnatib, ruhsat etilmagan joylarda saytga taklif qilish taqiqlanadi. Shu jumladan referal ssilka qo\'yish ham ta\'qiqlanadi. Reklama uchun alohida bo\'limimiz mavjud.</div>
<div class="menu"><b>2.5 So\'kinish</b><br/>
Senzuraga to\'g\'ri kelmaydigan so\'zlardan foydalanib xabar qoldirish taqiqlanadi.</div>
<div class="menu"><b>2.6 Noto\'g\'ri ma\'lumot</b><br/>
Xabar matni noto\'g\'ri, yolg\'on ma\'lumotlardan iborat bo\'lmasligi shart.</div>
<div class="menu"><b>2.7 Xabarlarni bezatish</b><br/>
Xabar matnini quyidagi yo\'llar bilan bezatish taqiqlanadi: 1) haddan ortiq smayllar 2) jargon so\'zlar 3) grammatik xatolar 4) har-xil rang berish, shriftlarni o\'zgartirish</div>
<div class="menu"><b>2.8 Qoidabuzarlikga undash</b><br/>
O\'zb. Res. qonunlarini yoki forum qoidalarini buzishga undovchi xabarlar qoldirish taqiqlanadi.</div>
<div class="menu"><b>2.9 Targ\'ibot</b><br/>
Zo\'ravonlik, fashizm, terarizm, irqchilik, millatchilik, din va boshqa O\'zb. Res. qonunlarida taqiqlangan holatlarni targ\'ib qilish taqiqlanadi.</div>
<div class="menu"><b>2.10 Buzg\'unchi dasturlar</b><br/>
Buzg\'unchi dasturlar ya\'ni virus, spamer, shell va hokozolarni kabi dasturlarni forumga yuklash yoki yuklash uchun ssilka qo\'yish taqiqlanadi.</div>
<div class="menu"><b>2.11 Mualliflik huquqi</b><br/>
Mualliflik huquqiga ega bo\'lgan maqola, dastur va hakozolarni muallif ruhsatisiz tarqatish, so\'rash taqiqlanadi.</div>
<div class="menu"><b>2.12 Ma\'muriyat ishlarni tahlil qilish</b><br/>
Ma\'muriyat ishlarni ochiqdan ochiq tahlil qilish taqiqlanadi. Savollar, muammolar kelib chiqqan holda shaxsiy xabar orqali ma\'muriyat bilan bog\'lanishingiz mumkin.</div>
<div class="menu"><b>2.13 Qarz so\'rash</b><br/>
Pul vositalari(forum tangasi)ni o\'zingiz yoki biron kim uchun qarzga so\'rash taqiqlanadi.</div>
<div class="menu"><b>2.13 Xizmatlar</b><br/>
Spam, hisoblagichlarni suniy oshirish, buzg\'unchilik xizmatlarini taklif qilish yoki sotish taqiqlanadi.</div>
<div class="menu"><b>2.14 Ruhsatsiz moderatorlik qilish</b><br/>
Ruhsatsiz moderatorlik bilan shug\'ullanish, boshqa foydalanuvchilarga tanbex berish taqiqlanadi. Qoidabuzarlik haqida xabar berish uchun &quot;Arz&quot; ssilkasini bosishingiz kerak.</div>
<div class="menu"><b>2.15 To\'g\'ri yozish</b><br/>
Iltimos, o\'zbek tili grammatikasini buzmagan holda xatosiz yozishga harakat qiling. Bu sizni bilim saviyangizni bildirib turadi.<br/>
Harflarni turli belgilar bilan qisqartirib yozish (ch-4, o\'-6, sh-w) taqiqlanadi. <br/>
Adabiychaga yaqin bo\'lgan shevalarda yozishga qisman ruhsat etiladi.</div>
<div class="menu"><b>2.16 Reytingni oshirish</b><br/>
Har qanday holatda reytingni oshirishni so\'rash taqiqlandi.</div>
<div class="menu"><b>2.17 Qo\'shimcha qoidalar</b><br/>
Ba\'zibir podforumlarda shu podforumga tegishli qo\'shimcha qoidalar mavjud. Xabar qoldirishda shu qoidalarga amal qilinishi shart.</div>
<div class="menu"><b>2.18  Manba ko\'rsatish</b><br/>
Boshqa saytlardan forumga yoki aksincha ma\'lumot ko\'chirganda o\'sha saytning manzili (manba) ko\'rsatilishi shart.<br/>
Masalan:<br/> &quot;Manba: shaddod.uz&quot;<br/>
Manba ko\'rsatishdan oldin, ma\'lumot haqiqatdan ham shu saytga tegishli ekanligini tekshirib ko\'ring. &quot;Qaroqchi&quot; saytlarga qo\'yilgan manba haqiqiy hisoblanmaydi.</div>
<div class="menu"><b>* 5.19 Iqtibos qilish</b><br/>
Sizdan oldin yozilgan xabar (post) ni zarurat bo\'lmasada to\'liqligicha iqtibos qilish ya\'ni katta hajmli postlarni sitata qilish (overquoting) taqiqlanadi.</div>

<div class="menu"><h3>Tavsiyalar</h3></div>
<div class="menu"><b>3.1</b><br/>
Suhbatdoshingizga hurmat bilan munosabatda bo\'ling, fikrlaringizni tushunarli va aniq faktlar yordamida bayon eting.</div>
<div class="menu"><b>3.2</b><br/>
O\'zingizni haqorat qilindi deb hisoblasangiz ham unga haqorat bilan javob qaytarmang. Biroz kuting yoki ma\'muriyat a\'zolariga shaxsiy xabar orqali xabar bering. Qolganini ma\'muriyat a\'zolari hal qilishadi.</div>
<div class="menu"><b>3.3</b><br/>
Agar qoidabuzarlikni ko\'rsangiz, bu haqida forumga jar solishni keragi yo\'q. &quot;Arz&quot; ssilkani bosing va sababini yozib qoldiring, ma\'muriyat a\'zolari ko\'rib chiqib chora ko\'rishadi.</div>
<div class="menu"><b>3.4</b><br/>
Savol berish yoki mavzu ochishdan oldin, forumdan izlab ko\'ring. Balki, sizni qiziqtirayotgan narsa allaqachon bor bo\'lishi mumkin.</div>

<div class="phdr"><b>Qoidabuzarlik atamalari</b></div>
<div class="menu"><h3>Flud yoki oftop nima degani?</h3></div><div class="menu">
<b>Flud</b> (inglizcha "flood" so\'zini noto\'g\'ri talaffuz qilish - "suv to\'lish, "suv bosish") - kerak bo\'lmagan ma\'lumotni bir necha bora qaytarilishi, bir hil ma\'lumotlarni joylash, qaytariladigon frazalar, belgilar, harflar, bir hil grafik fayllar yoki forum, chat, bloglardagi oddiygina qisqa ma\'nosiz xabarlar. Internet-slengda "Flud" tarqatuvchi odam "Fluder" deyiladi. Forumlarda dablpost(doublepost) yoki overpost, 2ta yoki ko\'proq xabarlar ketma ketligini bildiradi.<br/>
<b>Offtop</b> (inglizcha off topic) - avvaldan belgilangan mavzudan chiquvchi tarmoqdagi xar qanday xabar offtopic (qisqa varianti offtop) deyiladi. Masalan: Forumning umumiy yo\'nalishi yoki forum mavzusining yo\'nalishiga mos kelmagan xabarlar.</div>
<div class="menu"><h3>Fleym va spam nima?</h3></div><div class="menu">
<b>Fleym</b> ( inglizcha flame - o\'t, olov, alanga) - internet forum va chatlarda so\'z bilan urushib muloqot qilish jarayoni. Fleym xabarlari shaxsiy kamsitish, janjalni davom ettirishga qaratiladi. Ba\'zida trolling konteksida ishlatiladi, lekin ko\'proq fleym biror kishini boshqa kishidan hafa bo\'lganida yuzaga keladi.<br/>
<b>Spam</b> (inglizcha spam) qa\'bul qilishni xohlamagan shaxslarga xar xil turdagi reklamalarni keng qamrovda tarqatish. Ba\'zi turdagi davlat qonunchiligida ruhsat etilgan ba\'zi ma\'lumotlarni keng qamrovda tarqatish xollarixam kuzatilishi mumkun, lekin bu qonunni buzishga kirmaydi. Masalan ob-xavo ma\'lumotlarini operatorlar tomonidan abonentlarga yuborish. ICQ, Mail Agent, QIP va shu turdagi serverlardagi spam SPIM (ingl. Spam over IM) nomi bilan ataladi.</div>
<div class="menu"><h3>Overkvoting, trolling, xolivar nima?</h3></div><div class="menu">
<b>Overkvoting</b> (inglizcha overquoting) forumdagi xabarlarni katta hajmdagi sitata qilish. Bu ko\'pincha noqulaylik keltirib chiqaradi.<br/>
<b>Trolling</b> (inglizcha trolling) - internetda (forumlarda, Usenet yangilik guruhlarida, wiki-proyektlarda va h.k) provokatsiyali xabarlarni fleym, kelishmovchilik, haqorat va boshqa maqsadlarda ma\'lumot joylash. "Trolling" bilan shug\'ullanuvchi odam "Troll" deb ataladi, bu mifologik jonzot bilan nomdosh.<br/>
<b>Xolivar</b> (inglizcha holy war) - internet-forum va chatlarda foydalanuvchilarning o\'zlarini nuqtai nazarini singdirish maqsadidagi ma\'nosiz disskusiyasi(munozarasi). Masalan bir biriga bir necha alternativ narsalarni(kompyuter dasturlari, texnologiyalar, aktyorlar, musiqiy guruhlar va h.k) qay biri ustunligini ko\'rsatib berish.</div>

<div class="rmenu"><b>DIQQAT !!!</b><br/>Agar foydalanuvchi qoidalarga qarshilik qilsa, uning akkounti ma\'lum muddatga bloklanadi yoki umuman o\'chirib tashlanadi.</div>';
echo '<div class="menu"><h3><a href="index.php?act=nt&amp;id=' . $id . '&amp;yes">' . $lng_forum['agree'] . '</a> | <a href="index.php?id=' . $id . '">' . $lng_forum['not_agree'] . '</a></h3></div>';
            require('../incfiles/end.php');
            exit;
        }
    }
    $msg_pre = functions::checkout($msg, 1, 1);
    if ($set_user['smileys'])
        $msg_pre = functions::smileys($msg_pre, $datauser['rights'] ? 1 : 0);
    $msg_pre = preg_replace('#\[c\](.*?)\[/c\]#si', '<div class="quote">\1</div>', $msg_pre);
    echo '<div class="phdr"><a href="index.php?id=' . $id . '"><b>' . $lng['forum'] . '</b></a> | ' . $lng_forum['new_topic'] . '</div>';
    if ($msg && $th && !isset($_POST['submit']))
        echo '<div class="list1">' . functions::image('op.gif') . '<span style="font-weight: bold">' . $th . '</span></div>' .
            '<div class="list2">' . functions::display_user($datauser, array('iphide' => 1, 'header' => '<span class="gray">(' . functions::display_date(time()) . ')</span>', 'body' => $msg_pre)) . '</div>';
    echo '<form name="form" action="index.php?act=nt&amp;id=' . $id . '" method="post">' .
        '<div class="gmenu">' .
        '<p><h3>' . $lng['section'] . '</h3>' .
        '<a href="index.php?id=' . $res_c['id'] . '">' . $res_c['text'] . '</a> | <a href="index.php?id=' . $res_r['id'] . '">' . $res_r['text'] . '</a></p>' .
        '<p><h3>' . $lng_forum['new_topic_name'] . '</h3>' .
        '<input type="text" size="20" maxlength="100" name="th" value="' . $th . '"/></p>' .
        '<p><h3>' . $lng_forum['post'] . '</h3>';
    echo '</p><p>' . bbcode::auto_smileys('form', 'msg');
    echo '<textarea rows="' . $set_user['field_h'] . '" name="msg">' . (isset($_POST['msg']) ? functions::checkout($_POST['msg']) : '') . '</textarea></p>' .
        '<p><input type="checkbox" name="addfiles" value="1" ' . (isset($_POST['addfiles']) ? 'checked="checked" ' : '') . '/> ' . $lng_forum['add_file'];
    $token = mt_rand(1000, 100000);
    $_SESSION['token'] = $token;
    echo '</p><p><input type="submit" name="submit" value="' . $lng['save'] . '" style="width: 107px; cursor: pointer;"/> ' .
        ($set_forum['preview'] ? '<input type="submit" value="' . $lng['preview'] . '" style="width: 107px; cursor: pointer;"/>' : '') .
        '<input type="hidden" name="token" value="' . $token . '"/>' .
        '</p></div></form>' .
        '<div class="phdr"><a href="index.php?id=' . $id . '">' . $lng['back'] . '</a></div>';
}