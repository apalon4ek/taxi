<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
if($ban[1])
{
  echo functions::display_error('Siz banan yegansiz!');
  require_once ('../incfiles/end.php');
  exit;  
}
$req = mysql_query("SELECT * FROM `dnevniki` WHERE `id` = '".$id."' AND `dnid` = 'com' LIMIT 1");
if(mysql_num_rows($req))
{
  $res = mysql_fetch_assoc($req);  
  $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res['userid']."' LIMIT 1");
  $uz = mysql_fetch_assoc($req_user);
  if (($user_id==$res['userid'] or (($rights >= 7) and $rights >= $uz['rights'])))  
  {
    $save = $_GET['save'];
    if($save)
    {
      $text = trim($_POST['text']);
      if(!$text)
        $err .= 'Xabar kiritilmadi!<br/>';
      else
      {
        if(mb_strlen($text) > 2000)
          $err .= '2000 belgidan oshib ketdi!<br/>';  
      }
    }
    if($save and !$err)
    {
       mysql_query("UPDATE `dnevniki` SET
       `text` = '" . mysql_real_escape_string($text) . "',
       `mod_who` = '".$login."',
       `last_mod` = '".time()."'
       WHERE `id` = '".$id."'");
        echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrni taxrirlash</div>';   
        echo '<div class="menu">Fikr taxrirlandi!<br />';
        echo '<a href="?act=com&amp;id='.$res['com_id'].'">Davom etish</a></div>';
        echo '<div class="phdr">&nbsp;</div>';
        echo '<a href="?act=com&amp;id='.$res['com_id'].'"><img src="./img/folder_user.png" /> Fikrlar</a><br />';
        echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
        require_once ('../incfiles/end.php');
        exit;
    }  
    echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlarni taxrirlash</div>';
    if($err)
      echo '<div class="rmenu">'.$err.'</div>';
    echo '<form name="mess" action="?act=editcom&amp;save=save&amp;id='.$id.'" method="post">';
    echo '<div class="menu">Matn (bb-kod va smayllarga ruxsat):<br />'.bbcode::auto_bb('mess', 'text').'<textarea rows="' . $set_user['field_h'] . '" cols="30" name="text">'.($text ? htmlentities($text, ENT_QUOTES, 'UTF-8') : htmlentities($res['text'], ENT_QUOTES, 'UTF-8')).'</textarea><br />';
    echo '<input type="submit" name="submit" value="Saqlash"/></div>';
    echo '<div class="phdr">&nbsp;</div>';
    echo '</form>';
    echo '<a href="?act=com&amp;id='.$res['com_id'].'"><img src="./img/folder_user.png" /> Fikrlar</a><br />';
    echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
  }  
  else
  {
    echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrni taxrirlash</div>';
    echo '<div class="menu">';
    echo 'Sizga mumkinmas!<br/>';
    echo '<a href="./">Ortga</a>';
    echo '</div>';
    echo '<div class="phdr">&nbsp;</div>';  
  }
}
else
{
  echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrni taxrirlash</div>';
  echo '<div class="menu">';
  echo 'Sizga mumkinmas!<br/>';
  echo '<a href="./">Ortga</a>';
  echo '</div>';
  echo '<div class="phdr">&nbsp;</div>';  
}
?>
