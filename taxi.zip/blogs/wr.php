<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');

  if ($user_id != $id)
  {
      echo functions::display_error('Birovni blogiga sahifa qo\'shib bo\'midi!','<a href="./">Ortga</a>');
      require_once ('../incfiles/end.php');
      exit;
  }
  if($ban[1] or $ban['16'])
  {
      echo '<div class="phdr"><a href="./">Bloglar</a></div>';
      echo functions::display_error('Siz banan yegansiz va sahifa qo\'sha olmaysiz', '<a href="./">Ortga</a>');
      require_once ('../incfiles/end.php');
      exit; 
  }
$old = ($rights > 0) ? 10 : 60;
if ($datauser['lastpost'] > (time() - $old))
{
  echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlar</div>';
  echo '<div class="menu">Bunchali tez-tez yozolmis. ' . $old . ' sekun chidang.<br/><a href="?act=showdn&amp;id='.$id.'">Ortga</a></div>';
  echo '<div class="phdr">&nbsp;</div>';
  require_once ("../incfiles/end.php");
  exit;
}
  $save = $_GET['save'];
  if($save)
  {
    $name22 = trim($_POST['name']);
    $text = trim($_POST['text']);
    if(!$name22)
      $err .= 'Sahifa nomini kiritmadingiz!<br/>';
    else
    {
      if(mb_strlen($name22) > 30)
        $err .= 'Sahifa nomi 30 belgidan oshmasligi kerak!<br/>';  
    }
    if(!$text)
      $err .= 'Sahifa matnini kiritmadingiz!<br/>';
    else
    {
      if(mb_strlen($text) > 10000)
        $err .= 'Matn hajmi 10000 belgidan oshmasligi kerak!<br/>';
    }  
      
  }
  if($save and !$err)
  {
     $req = mysql_query("SELECT * FROM `dnevniki` WHERE `userid` = '".$user_id."' AND `dnid` = 'dir' LIMIT 1");
     if (mysql_num_rows($req))
       mysql_query("UPDATE `dnevniki` SET `vr` = '".time()."' WHERE `userid` = '".$user_id."' AND `dnid` = 'dir' LIMIT 1");
     else
       mysql_query("INSERT INTO `dnevniki` SET `vr` = '".time()."',`username` = '".$datauser['name']."', `dnid` = 'dir', `userid` = '".$user_id."'");
     
     mysql_query("INSERT INTO `dnevniki` SET
      `userid` = '" . $user_id . "',
      `username` = '" . $datauser['name'] . "',
      `text` = '" . mysql_real_escape_string($text) . "',
      `zag` = '" . mysql_real_escape_string($name22) . "',
      `dnid` = 'txt',
      `vr` = '".time()."'");
     $usid = mysql_insert_id();
       
      if (empty($datauser['komm']))
        $fpst = 1;
      else
       $fpst = $datauser['komm'] + 1;
       mysql_query("UPDATE `users` SET
       `komm` = '" . $fpst . "',
       `lastpost` = '" . time() . "'
       WHERE `id` = '" . $user_id . "';");  
     mysql_query("INSERT INTO `dnevniki_com_rdm` SET `comid` = '0', `recordid` = '".$usid."', `userid` = '0', `time` = '0';");
      
     echo '<div class="phdr"><a href="./">Bloglar</a> | Sahifa qo\'shish</div>';
     echo '<div class="menu">';
     echo 'Sahifa qo\'shildi!<br/>';
     echo '<a href="?act=view&amp;id='.$usid.'">Davom etish</a>';
     echo '</div>';
     echo '<div class="phdr">&nbsp;</div>';
     echo '<a href="?act=showdn&amp;id='.$id.'"><img src="./img/folder_user.png" /> Mening blogim</a><br />';
     echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
     require_once ('../incfiles/end.php');
     exit;
  }
  echo '<div class="phdr"><a href="./">Bloglar</a> | Sahifa qo\'shish</div>';
  if($err)
    echo '<div class="rmenu">'.$err.'</div>';
  $req = mysql_query("SELECT * FROM `dnevniki` WHERE `userid` = '".$user_id."' AND `dnid` = 'dir' LIMIT 1");
  if (!mysql_num_rows($req))
    echo '<div class="topmenu">Yangi sahifa qo\'shishingiz bilan blogingiz ham yaratiladi!</div>';
  echo '<form name="mess" action="?act=wr&amp;save=save&amp;id='.$id.'" method="post">';
  echo '<div class="gmenu">Sarlavha (Max 30 belgi):<br /><input type="text" name="name" value="'.htmlentities($name22, ENT_QUOTES, 'UTF-8').'"/></div>';
  echo '<div class="menu">Matn (max 10 000 belgi, bb-kod va smayllarga ruhsat):<br />'.bbcode::auto_bb('mess', 'text').'<textarea rows="' . $set_user['field_h'] . '" name="text">'.htmlentities($text, ENT_QUOTES, 'UTF-8').'</textarea><br/>';
  echo '<input type="submit" name="submit" value="Yuborish"/></div></form>';
  echo '<div class="phdr">&nbsp;</div>';
  echo '<a href="?act=showdn&amp;id='.$id.'"><img src="./img/folder_user.png" /> Mening blogim</a><br />';
  echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
?>
