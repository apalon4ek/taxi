<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');

    $req = mysql_query("SELECT * FROM `dnevniki` WHERE `id` = '".$id."' AND `dnid` = 'txt' LIMIT 1"); 
    if (mysql_num_rows($req))
    {
      //метка о прочтении
      if (mysql_result(mysql_query("SELECT COUNT(*) FROM `dn_rdm` WHERE `dnid` = '".$id."' AND `user_id` = '".$user_id."'"), 0)==0)
        mysql_query("INSERT INTO `dn_rdm` SET `dnid` = '".$id."', `user_id` = '".$user_id."', `time` = '".time()."'");
        
      $res = mysql_fetch_assoc($req);
      $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res['userid']."' LIMIT 1");
      $datauser = mysql_fetch_assoc($req_user);
      echo '<div class="phdr"><a href="./">Bloglar</a> | '.($datauser['id'] ? '<a href="./?act=showdn&amp;id='.$res['userid'].'">'.$res['username'].'</a>' : $res['username']).'</div>';
      echo '<div class="topmenu">';
      $dn_new = blogs::dn_new();
      $dn_com = blogs::dnevniki_com_new();
      if($dn_new or $dn_com)
        echo 'Yangilar: '.($dn_new !=0 ? '<a href="?act=new">ta sahifa</a> <span class="red">('.$dn_new.')</span>' : '').(($dn_new and $dn_com) ? ' | ' : '').($dn_com !=0 ? '<a href="?act=newcm">fikrlar</a> <span class="red">('.$dn_com.')</span>' : '').'';
      else
        echo 'TOP: <a href="./?act=top">ovozlar</a> | <a href="./?act=topview">o\'qilganlar </a><br/>';
      echo '</div>';
      echo '<div class="phdr"><img src="img/dn.png" width="16" height="16" /> <b>'.htmlentities($res['zag'], ENT_QUOTES, 'UTF-8').'</b></div>';
      $text=$res['text'];
      $text=functions::checkout($text, 1, 1);
      $text = functions::smileys($text, $datauser['rights'] ? 1 : 0);
      echo '<div class="menu">'.$text.'';
      if ($res['last_mod']) echo '<br /><span class="gray"><small>O\'zg. <b>'.$res['mod_who'].'</b> ('.date("d.m.y | H:i", $res['last_mod']).')</small></span>';
      echo '</div><div class="gmenu">';
      
      $total_plus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "1" AND `content`= "'.$id.'" ;'), 0);
      $total_minus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "0" AND `content`= "'.$id.'" ;'), 0);
      $total_vote=$total_plus-$total_minus;
        echo 'Reyting: <b><span style="color: rgb(0, 0, 0); background-color: ';
      if ($total_vote > 0)
        echo 'rgb(192, 255, 192)';
      elseif($total_vote < 0)
        echo 'rgb(241, 150, 168)';
      else
        echo 'rgb(204, 204, 204)';
      echo ';">&nbsp;'.$total_vote.'&nbsp;</span></b> (Minus : '.$total_minus.' | Plyus: '.$total_plus.')<br/>';
        
      $rat_p=mysql_result(mysql_query('SELECT max(`raiting`+0) FROM `dnevniki`;'), 0);
      $rat_m=mysql_result(mysql_query('SELECT min(`raiting`+0) FROM `dnevniki`;'), 0);
      $ttl2 = $rat_p - $rat_m;
      if(!$ttl2) $ttl2 = 1;
      $rat= ceil(($total_vote-$rat_m)/($ttl2)*100);
      echo '<a href="./?act=vote&amp;do=adminus&amp;id='.$id.'"><img src="img/m.png"/></a><img src="raiting.php?show='.$rat.'"/><a href="./?act=vote&amp;do=adplus&amp;id='.$id.'"><img src="img/p.png"/></a><br/>';
      
      echo '<hr/>Sahifa qo\'shilgan: '.date("d.m.y / H:i", $res['vr'] + 5 * 60 * 60).' <br /> O\'qilgan: '.$res['views'].' marta</div>';
      $cont = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$res['id']."'"), 0); 
      echo '<div class="phdr"><a href="?act=com&amp;id='.$res['id'].'">Fikrlar</a> ('.$cont.dnevniki_com_new_local($res['id']).')</div>';
      if ($user_id==$res['userid'] or (($rights >= 7) and $rights > $datauser['rights']))
      {
          echo '<img src="./img/edit.png" /> <a href="?act=edit&amp;id='.$id.'">Taxrirlash</a> | ';
          echo '<a href="?act=delrec&amp;id='.$id.'">O\'chirish</a><br/>';
      }
      echo '<a href="?act=showdn&amp;id='.$res['userid'].'"><img src="./img/folder_user.png" />'.$res['username'].' blogi</a><br />';
      echo '<a href="./"><img src="./img/folder.png" /> Bloglar </a><br />';
      //счетчик +1
      mysql_query("UPDATE `dnevniki` SET `views` = '".($res['views']+1)."' WHERE `id` = '".$id."'");

    }
    else
    {
        echo functions::display_error('Bunday sahifa mavjud emas!', '<a href="./">Ortga</a>');
      require_once ('../incfiles/end.php');
      exit;
    }
?>
