<?php

define('_IN_JOHNCMS', 1);

$textl = 'Bloglar';
$headmod = 'dnevniki';


require_once ("../incfiles/core.php");
require_once ('inc.php');

// Ограничиваем доступ к дневникам
// Внимание!!! Не удалять!!! Приводит к нестабильной работе!!!!!!!!!
if (!$user_id) {
    require_once ("../incfiles/head.php");
    echo '<div class="rmenu"><p>Bloglarni faqat <a href="../login.php">ro\'yxatdan o\'tganlar</a> o\'qiy oladi</p></div>';
    require_once ("../incfiles/end.php");
    exit;
}

require_once ("../incfiles/head.php");
$main_act = array('chancom', 'com', 'deldn', 'edit', 'editcom', 'new', 'say', 'showdn', 'view', 'wr','delcom', 'delrec', 'topview','vote','top','bad','newcm','reset','rescom','massdel');
if (in_array($act, $main_act))
{
   require_once ($act . '.php');
}
else
{
  echo '<div class="phdr">Bloglar</div>';
  echo '<div class="topmenu">';
  echo 'Top: <a href="./?act=top">ovozlar</a> | <a href="./?act=topview">o\'qilganlar</a><br/>';
  $dn_new = blogs::dn_new();
  $dn_com = blogs::dnevniki_com_new();
  if($dn_new or $dn_com)
    echo 'Yangilar: '.($dn_new !=0 ? '<a href="?act=new">ta sahifa</a> <span class="red">('.$dn_new.')</span>' : '').(($dn_new and $dn_com) ? ' | ' : '').($dn_com !=0 ? '<a href="?act=newcm">fikrlar</a> <span class="red">('.$dn_com.')</span>' : '').'';
  echo '</div>'; 
  $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'dir'"), 0);
  if ($total > 0)
  {
    $req = mysql_query("SELECT * FROM `dnevniki` WHERE `dnid` = 'dir' ORDER BY `vr` DESC  LIMIT $start,$kmess");
    while ($res = mysql_fetch_assoc($req))
    {
      $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res['userid']."' LIMIT 1");
      $datauser = mysql_fetch_assoc($req_user);
      
      echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
      $col_dn = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'txt' AND `userid` = '".$res['userid']."'"), 0);
      echo '<table  cellpadding="0" cellspacing="0"><tr><td><a href="?act=showdn&amp;id='.$res['userid'].'">';
      if(file_exists('../files/users/avatar/'.$res['userid'].'.png'))
      {
        if(file_exists('./covers/'.$res['userid'].'.png'))
          echo '<img src="./covers/'.$res['userid'].'.png" />';
        else
          echo '<img src="cover.php?id='.$res['userid'].'" />';
      }
      else
      {
        echo '<img src="./img/folder_blue.png" />';  
      }
      echo '</a></td><td>';
      echo '&nbsp;<b>';
      if ($datauser['sex'])
        echo '<img src="../theme/' . $set_user['skin'] . '/images/' . ($datauser['sex'] == 'm' ? 'm' : 'w') . ($datauser['datereg'] > $realtime - 86400 ? '_new' : '') . '.png" width="16" height="16" align="middle" />&nbsp;';
      else
         echo '<img src="../images/del.png" width="12" height="12" align="middle" />&nbsp;';
      echo '<a href="?act=showdn&amp;id='.$res['userid'].'">'.$res['username'].'</a></b><br/>
      <span class="gray"><small>&nbsp;Sahifalar: '.$col_dn.'';
      echo '</small></span>';
      echo '</td></tr></table>';
      $req222 = mysql_query("SELECT * FROM `dnevniki` WHERE `dnid` = 'txt' AND `userid` = '".$res['userid']."' ORDER BY `vr` DESC LIMIT 1"); 
      $res222 = mysql_fetch_assoc($req222);
      $cont = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$res222['id']."'"), 0); 
      echo '<hr/><small>Oxirgi sahifa <b>"<a href="?act=view&amp;id='.$res222['id'].'">'.htmlentities($res222['zag'], ENT_QUOTES, 'UTF-8').'</a>"</b> '.date("d.m.y в H:i", $res222['vr']).'dan <a href="?act=com&amp;id='.$res222['id'].'">('.$cont.''.dnevniki_com_new_local($res222['id']).')</a></small>';
      echo '</div>';
      ++$i;
    }    
    echo '<div class="phdr">Umumiy bloglar: <b>'.$total.'</b></div>';
  }
  else
  {
    echo '<div class="menu"><p>Ro\'yxat bo\'sh</p></div>';
    echo '<div class="phdr">&nbsp;</div>';
  }
  
  if ($total > $kmess)
    echo '<div class="topmenu">' . functions::display_pagination('?', $start, $total, $kmess) . '</div>';
  echo '<a href="./?act=bad"><img src="img/bad.png" width="16" height="16" />Eng rasvo sahifalar</a><br/>';
  if (mysql_num_rows(mysql_query("SELECT * FROM `dnevniki` WHERE `userid` = '".$user_id."' AND `dnid` = 'dir' LIMIT 1")))
    echo '<a href="?act=showdn&amp;id='.$user_id.'"><img src="./img/folder.png" /> Mening blogim</a>';
  else
    echo '<a href="?act=wr&amp;id='.$user_id.'"><img src="./img/add.png" /> O\'z blogingizni yarating</a>';
}
require_once ('../incfiles/end.php');
?> 