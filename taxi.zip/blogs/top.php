<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
$total=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki` WHERE `raiting` > "0" and `dnid` = "txt" ;'), 0);
echo '<div class="phdr"><a href="./">Bloglar</a> | TOP ovozlar</div>';
if($total > 0)
{
   $res1 = mysql_query('SELECT * FROM `dnevniki` WHERE `raiting` > "0" and `dnid` = "txt" ORDER BY  RIGHT(CONCAT("00",`raiting`),3) DESC LIMIT '.$start.','.$kmess.';');
   $i=1;
   while($res = mysql_fetch_array($res1))
   {
      $total_plus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "1" AND `content`= "'.$res['id'].'" ;'), 0);
      $total_minus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "0" AND `content`= "'.$res['id'].'" ;'), 0); 
      $total_vote=$total_plus-$total_minus;
      echo ($i % 2) ? '<div class="list1">' : '<div class="list2">';
      echo '<b><a href="?act=view&amp;id='.$res['id'].'"><img src="img/dn.png" width="16" height="16" /> '.htmlentities($res['zag'], ENT_QUOTES, 'UTF-8').'</a></b><br />';
      echo htmlentities(mb_substr($res['text'], 0, 100), ENT_QUOTES, 'UTF-8').'...<br />';
      $cont = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$res['id']."'"), 0);
      echo '<a href="?act=com&amp;id='.$res['id'].'">Комментарии</a> ('.$cont.')';
      echo '<div class="sub">Qo\'shildi: '.date("d.m.y / H:i", $res['vr']).' <br /> Reyting: '.$total_vote.'</div>';
      echo '</div>';
      $i++;
   }
   echo '<div class="phdr">Umumiy: <b>'.$total.'</b></div>';
   if ($total > $kmess)
     echo '<div class="topmenu">' . functions::display_pagination('./?act=top&amp;id='.$id.'&amp;', $start, $total, $kmess) . '</div>';
}
else
{
  echo '<div class="menu">Ovoz olgan sahifalar yo\'q!</div>';  
  echo '<div class="phdr">&nbsp;</div>';  
}

echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a>';
?>
