<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
    $req222 = mysql_query("SELECT * FROM `dnevniki` WHERE `dnid` = 'txt' AND `id` = '".$id."' ORDER BY `vr` DESC LIMIT 1");
    if (mysql_num_rows($req222))
    {
      $res222 = mysql_fetch_assoc($req222);
      $req_user222 = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res222['userid']."' LIMIT 1");
      $datauser222 = mysql_fetch_assoc($req_user222);
      echo '<div class="phdr"><a href="./">Bloglar</a> | '.$res222['username'].'</div>';
      echo '<div class="phdr"><img src="img/dn.png" width="16" height="16" />  <b><a href="?act=view&amp;id='.$res222['id'].'">'.htmlentities($res222['zag'], ENT_QUOTES, 'UTF-8').'</a></b> | Kommentlar</div>';
      if(!$ban['1'] and !$ban['16'] and !$ban['10'])
      {
        echo '<div class="gmenu"><form name="mess" action="?act=say&amp;id='.$id.'" method="post">Sizning fikringiz (max. 2000):<br/>';
        echo bbcode::auto_bb('mess', 'msg').'<textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea><br/>';
        echo '<input type="checkbox" name="msgtrans" value="1" /> Translit<br/>';
        echo '<input type="submit" title="Qoshish" name="submit" value="Yuborish"/>';
        echo '</form></div>';
      }
      $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$id."'"), 0);       
      $req = mysql_query("SELECT * FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$id."' ORDER BY `vr` DESC LIMIT $start,$kmess");
      if (($rights >= 6) and $total)
        echo '<form action="index.php?act=massdel" method="post">';
      while ($res = mysql_fetch_assoc($req))
      {
            
         $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res['userid']."' LIMIT 1");
         $uz = mysql_fetch_assoc($req_user);
         echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
         if ($set_user['avatar'])
         {
           echo '<table cellpadding="0" cellspacing="0"><tr><td>';
           if (file_exists(('../files/avatar/' . $res['userid'] . '.png')))
             echo '<img src="../files/avatar/' . $res['userid'] . '.png" width="32" height="32" alt="' . $res['userid'] . '" />&nbsp;';
           else
             echo '<img src="../images/empty.png" width="32" height="32" alt="' . $res['useid'] . '" />&nbsp;';
           echo '</td><td>';
         }
         if ($uz['sex'])
           echo '<img src="../theme/' . $set_user['skin'] . '/images/' . ($uz['sex'] == 'm' ? 'm' : 'w') . ($uz['datereg'] > time() - 86400 ? '_new' : '') . '.png" width="16" height="16" align="middle" />&nbsp;';
         else
           echo '<img src="../images/del.png" width="12" height="12" align="middle" />&nbsp;';
         if ((!empty ($_SESSION['uid'])) && ($_SESSION['uid'] != $uz['id']) and $uz['id'])
           echo '<a href="../users/profile.php?user='.$uz['id'].'"><font style="color: '.$uz['skype'].';"><b>'.$res['username'].'</b></font></a> ';
         else
           echo '<b>'.$res['username'].'</b> ';
         $vr1 = date("d.m.Y / H:i", $res['time'] + 5 * 60 * 60);
            $user_rights = array (
                        3 => '(FMod)',
                        4 => '(DMod)',
                        5 => '(LMod)',
                        6 => '(Smd)',
                        7 => '(Adm)',
                        9 => '(SV!)'
                    );
            echo $user_rights[$uz['rights']];
         $ontime = $uz['lastdate'];
         $ontime2 = $ontime + 300;
         echo (time() > $uz['lastdate'] + 300 ? '<span class="red"> [Off]</span> ' : '<span class="green"> [On]</span> ');
         if (!empty($uz['status']))
           echo '<div class="status"><img src="../theme/' . $set_user['skin'] . '/images/label.png" alt="" align="middle"/>&nbsp;' . $uz['status'] . '</div>';
         if ($set_user['avatar'])
           echo '</td></tr></table>';
         echo '<span class="gray"><b><small>('.date("d.m.y | H:i", $res['vr'] + 5 * 60 * 60).')</small></b></span><br />';
         $text=$res['text'];
         $text=functions::checkout($text, 1, 1);
         $text = functions::smileys($text, $datauser['rights'] ? 1 : 0);
         echo $text;
         if ($res['last_mod']) echo '<br /><span class="gray"><small>O\'zg. <b>'.$res['mod_who'].'</b> ('.date("d.m.y | H:i", $res['last_mod'] + 5 * 60 * 60).')</small></span>';
         if ($user_id==$res['userid'] or (($rights >= 6) and $rights >= $uz['rights']))
           echo '<div class="sub">'.((($rights >= 6) and $rights >= $uz['rights']) ? '<input type="checkbox" name="delch[]" value="' . $res['id'] . '"/>&nbsp;' : '').'<a href="?act=editcom&amp;id='.$res['id'].'">Taxrirlash</a> | <a href="?act=delcom&amp;id='.$res['id'].'">O\'chirish</a></div>';
         echo '</div>'; 
         ++$i;
      }
       if(!$total)
       {
         echo '<div class="menu"><p>Sahifalar yo\'q</p></div>';    
       }
       if($user_id)
       { 
          $old = time() - (3 * 24 * 3600);
          $read1 = mysql_query("SELECT * FROM `dnevniki` LEFT JOIN `dnevniki_com_rdm` ON `dnevniki`.`id` = `dnevniki_com_rdm`.`comid` AND `dnevniki_com_rdm`.`userid` = '" . $user_id . "' WHERE `dnevniki_com_rdm`.`userid` IS NULL AND `dnevniki`.`dnid` = 'com' AND `dnevniki`.`com_id` = '".$id."' AND `dnevniki`.`time` > '".$old."' ORDER BY `dnevniki`.`time`;");
          while($read = mysql_fetch_array($read1))
          {
            mysql_query("INSERT INTO `dnevniki_com_rdm` SET `comid` = '".$read['id']."', `recordid` = '".$id."', `type` = '0', `userid` = '".$user_id."', `time` = '".time()."';");
          }
       }
       if (($rights >= 6) and $total)
       {
         echo '<div class="rmenu"><input type="submit" value="Ochirish"/></div>';
         echo '</form>';
       }
      echo '<div class="phdr">Umumiy: '.$total.'</div>';
      if ($total > $kmess)
        echo '<div class="topmenu">' . functions::display_pagination('?act=com&amp;id='.$id.'&amp;', $start, $total, $kmess) . '</div>';
      echo '<a href="?act=view&amp;id='.$res222['id'].'"><img src="./img/edit.png" /> Zapislar</a><br />';
      echo '<a href="?act=showdn&amp;id='.$res222['userid'].'"><img src="./img/folder_user.png" />'.$datauser222['name'].' blogi</a><br />';
      echo '<a href="./"><img src="./img/folder.png" />Bloglar</a>';
  }
  else
  {
    echo functions::display_error('Bunday sahifa mavjud emas!', '<a href="./">Ortga</a>');
    require_once ('../incfiles/end.php');
    exit;
  }  
?>
