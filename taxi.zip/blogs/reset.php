<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
if($user_id)
{
$old = time() - (3 * 24 * 3600);
$raz1 = mysql_query("SELECT * FROM `dnevniki` LEFT JOIN `dn_rdm` ON `dnevniki`.`id` = `dn_rdm`.`dnid` AND `dn_rdm`.`user_id` = '" . $user_id . "' WHERE `dn_rdm`.`user_id` IS NULL AND `dnevniki`.`dnid` = 'txt' AND `vr` > '".$old."' ");
  while($raz = mysql_fetch_array($raz1))
  {
    mysql_query("INSERT INTO `dn_rdm` SET `dnid` = '".$raz['id']."', `user_id` = '".$user_id."', `time` = '".$realtime."'");  
  }
  echo '<div class="phdr">Bloglar</div>';
  echo '<div class="menu">Tozalash yakunlandi!<br/><a href="./">Ortga</a></div>';
  echo '<div class="phdr">&nbsp;</div>';
}
?>
