<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
if($ban[1])
{
  echo functions::display_error('Siz banan yegansiz!');
  require_once ('../incfiles/end.php');
  exit;    
}

$req = mysql_query("SELECT * FROM `dnevniki` WHERE `id` = '".$id."' AND `dnid` = 'txt' LIMIT 1");
if(mysql_num_rows($req))
{
  $res = mysql_fetch_assoc($req);  
  $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res['userid']."' LIMIT 1");
  $uz = mysql_fetch_assoc($req_user);
  if (($user_id==$res['userid'] or (($rights >= 7) and $rights > $uz['rights']))) 
  {
    $del = $_GET['del'];
    if($del)
    {
      mysql_query("DELETE FROM `dnevniki` WHERE `dnid` = 'txt' AND `id` = '".$id."' LIMIT 1");
      mysql_query("DELETE FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$id."'");
      mysql_query("DELETE FROM `dn_rdm` WHERE `dnid` = '".$id."'");
      echo '<div class="phdr"><a href="./">Bloglar</a> | Sahifani o\'chirish</div>';
      echo '<div class="menu">Sahifa o\'chirildi!<br/>';
      echo '<a href="?act=showdn&amp;id='.$res['userid'].'">Davom etish</a></div>';
      echo '<div class="phdr">&nbsp;</div>';
      echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
      require_once ('../incfiles/end.php');
      exit;
    } 
    echo '<div class="phdr"><a href="./">Bloglar</a> | Sahifani o\'chirish</div>';
    echo '<div class="menu">Sahifani o\'chirmoqchimisiz?<br/>';     
    echo '<a href="?act=delrec&amp;del=del&amp;id='.$id.'">O\'chirish</a> | <a href="?act=view&amp;id='.$id.'">Bekor qilish</a></div>'; 
    echo '<div class="phdr">&nbsp;</div>';
    echo '<a href="./"><img src="./img/folder.png" />Bloglar</a><br />';
  }
  else
  {
    echo '<div class="phdr"><a href="./">Bloglar</a> | Sahifani o\'chirish</div>';
    echo '<div class="menu">';
    echo 'Sizga mumkinmas!<br/>';
    echo '<a href="./">Ortga</a>';
    echo '</div>';
    echo '<div class="phdr">&nbsp;</div>';
  }
}
else
{
  echo '<div class="phdr"><a href="./">Bloglar</a> | Sahifani o\'chirish</div>';
  echo '<div class="menu">';
  echo 'Sizga mumkinmas!<br/>';
  echo '<a href="./">Ortga</a>';
  echo '</div>';
  echo '<div class="phdr">&nbsp;</div>';
}
?>
