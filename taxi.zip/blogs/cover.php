<?php
$id=intval(abs($_GET['id']));
header("Content-type: image/png");
$img = imagecreatefrompng('img/folder_blue.png');
imagealphablending($img, true);
imagesavealpha($img, true);
if(!$id)
{
 
}
else
{
  if(file_exists('../files/users/avatar/'.$id.'.png'))
  {
    header("Content-type: image/png");
    $avatar = @imagecreatefrompng('../files/users/avatar/'.$id.'.png');
    if(!$avatar)
      $avatar = @imagecreatefromgif('../files/users/avatar/'.$id.'.png'); 
    imagealphablending($avatar, true);
    imagesavealpha($avatar, true);
    $src_w = imagesx($avatar);
    $src_h = imagesy($avatar);
    $res = imagecreatetruecolor(23,23);
    imagefill($res, 0, 0, 0xffffff);
    imagecopyresampled($res, $avatar, 0, 0, 0, 0, 23, 23, $src_w, $src_h);
    $res = imagerotate($res, 10, -1);
    $w = imagesx($res);
    $h = imagesy($res);
    imagecopyresampled ($img, $res, 3, 6, 0, 0, $w, $h, $w, $h);
    if(!file_exists('covers/'.$id.'.png'))
    {
      $img2 = $img;
      imagepng($img,'covers/'.$id.'.png');   
    }
  }
  else
  {
      
  }
}
imagepng($img);

?>
