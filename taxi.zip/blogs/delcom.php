<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
if($ban[1])
{
  echo display_error('Siz ban olgansiz!', '<a href="?act=com&amp;id='.$id.'">Ortga</a>');
  require_once ('../incfiles/end.php');
  exit;    
}

$req = mysql_query("SELECT * FROM `dnevniki` WHERE `id` = '".$id."' AND `dnid` = 'com' LIMIT 1");
if(mysql_num_rows($req))
{
  $res = mysql_fetch_assoc($req);  
  $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res['userid']."' LIMIT 1");
  $uz = mysql_fetch_assoc($req_user);
  if (($user_id==$res['userid'] or (($rights >= 7) and $rights >= $uz['rights']))) 
  {
    $del = $_GET['del'];
    if($del)
    {
      mysql_query("DELETE FROM `dnevniki` WHERE `dnid` = 'com' AND `id` = '".$id."' LIMIT 1");
      mysql_query("DELETE FROM `dnevniki_com_rdm` WHERE `recordid` = '".$res['com_id']."' AND `comid` = '".$id."' ;");
      $users_com1 = mysql_query("SELECT * FROM `dnevniki_com_rdm` WHERE `recordid` = '".$res['com_id']."' AND `userid` != '".$res['userid']."'");
      while($users_com = mysql_fetch_array($users_com1))
      {
         mysql_query("UPDATE `dnevniki_com_rdm` SET `type` = '0'  WHERE `recordid` = '".$res['com_id']."' AND `userid` = '".$users_com['userid']."' LIMIT 1;");
      }
      $tot_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki_com_rdm` WHERE `recordid` = '".$res['com_id']."' AND `type` = '0' AND `userid` = '".$res['userid']."';"), 0);
      if($tot_new ==0)
      {
        mysql_query("INSERT INTO `dnevniki_com_rdm` SET `comid` = '0', `recordid` = '".$res['com_id']."', `userid` = '0', `type` = '0', `time` = '0' ;");
      }
      echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlarni tozalash</div>';
      echo '<div class="menu">Fikrlar o\'chirildi!<br/>';
      echo '<a href="?act=com&amp;id='.$res['com_id'].'">Davom etish</a></div>';
      echo '<div class="phdr">&nbsp;</div>';
      echo '<a href="?act=com&amp;id='.$res['com_id'].'"><img src="./img/folder_user.png" /> Fikrlar</a><br />';
      echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
      require_once ('../incfiles/end.php');
      exit;
    } 
    echo '<div class="phdr"><a href="./">Bloglar</a> | Tozalash</div>';
    echo '<div class="menu">Fikrlarni tozalamoqchimisiz?<br/>';     
    echo '<a href="?act=delcom&amp;del=del&amp;id='.$id.'">O\'chirish</a> | <a href="?act=com&amp;id='.$res['com_id'].'">Bekor qilish</a></div>'; 
    echo '<div class="phdr">&nbsp;</div>';  
    echo '<a href="?act=com&amp;id='.$res['com_id'].'"><img src="./img/folder_user.png" /> Fikrlar</a><br />';
    echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
  }
  else
  {
    echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlarni tozalash</div>';
    echo '<div class="menu">';
    echo 'Tozalash taqiqlanadi!<br/>';
    echo '<a href="./">Ortga</a>';
    echo '</div>';
    echo '<div class="phdr">&nbsp;</div>';
  }
}
else
{
  echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlarni tozalash</div>';
  echo '<div class="menu">';
  echo 'Tozalash taqiqlanadi!<br/>';
  echo '<a href="./">Ortga</a>';
  echo '</div>';
  echo '<div class="phdr">&nbsp;</div>';
}
?>
