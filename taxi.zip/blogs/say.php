<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
if($ban[1])
{
  echo functions::display_error('Siz banan yegansiz!', '<a href="?act=com&amp;id='.$id.'">Ortga</a>');
  require_once ('../incfiles/end.php');
  exit;    
}
$old = ($rights > 0) ? 10 : 60;
if ($datauser['lastpost'] > (time() - $old))
{
  echo '<div class="phdr"><a href="./">Ortga</a> | Fikrlar</div>';
  echo '<div class="menu">Siz bunaqa tez-tez yozishiz mumkinmas. ' . $old . ' sekund sabr qiling.<br/><a href="?act=com&amp;id='.$id.'">Ortga</a></div>';
  echo '<div class="phdr">&nbsp;</div>';
  require_once ("../incfiles/end.php");
  exit;
}
if($id and (!$ban['1'] and !$ban['16'] and !$ban['10'] and $user_id))
{
  $req2 = mysql_query("SELECT * FROM `dnevniki` WHERE `dnid` = 'txt' AND `id` = '".$id."' LIMIT 1");
  if(mysql_num_rows($req2))
  {
    $msg = trim($_POST['msg']);
    if($msg)
    {
      if(mb_strlen($msg) > 2000)
      {
        echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlar</div>';
        echo '<div class="menu">';
        echo 'Fikr matni 2000 belgidan ortib ketdi!<br/>';
        echo '<a href="?act=com&amp;id='.$id.'">Ortga</a>';
        echo '</div>';
        echo '<div class="bmenu">&nbsp;</div>';
      }
      else
      {
         mysql_query("INSERT INTO `dnevniki` SET
         `text` = '" . mysql_real_escape_string($msg) . "',
         `dnid` = 'com',
         `com_id` = '".$id."',
         `userid` = '".$user_id."',
         `username` = '".$datauser['name']."',
         `time` = '".time()."',
         `vr` = '".time()."'");
         $postid = mysql_insert_id();
         if (empty($datauser['komm']))
           $fpst = 1;
         else
           $fpst = $datauser['komm'] + 1;
         mysql_query("UPDATE `users` SET
         `komm` = '" . $fpst . "',
         `lastpost` = '" . time() . "'
          WHERE `id` = '" . $user_id . "';"); 
        
        mysql_query("DELETE FROM `dnevniki_com_rdm` WHERE `recordid` = '".$id."' AND `userid`='0'");
        mysql_query("UPDATE `dnevniki_com_rdm` SET `type` = '1' WHERE `recordid` = '" . $id . "' AND `type` = '0' AND `userid` != '".$user_id."';");
        mysql_query("UPDATE `dnevniki` SET `time` = '".time()."' WHERE `id` = '" . $id . "'");
        mysql_query("INSERT INTO `dnevniki_com_rdm` SET `comid` = '".$postid."', `recordid` = '".$id."', `type` = '0', `userid` = '".$user_id."', `time` = '".time()."';"); 
        
        echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlar</div>';   
        echo '<div class="menu">Fikringiz qo\'shildi!<br />';
        echo '<a href="?act=com&amp;id='.$id.'">Davom etish</a></div>';
        echo '<div class="phdr">&nbsp;</div>';
      }  
    }
    else
    {
      echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlar</div>';
      echo '<div class="menu">';
      echo 'Fikrni kiritmadingiz!<br/>';
      echo '<a href="?act=com&amp;id='.$id.'">Ortga</a>';
      echo '</div>';
      echo '<div class="bmenu">&nbsp;</div>'; 
    }
  }
  else
  {
     echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlar</div>';
     echo '<div class="menu">';
     echo 'Sizga mumkinmas!<br/>';
     echo '<a href="?act=com&amp;id='.$id.'">Назад</a>';
     echo '</div>';
     echo '<div class="bmenu">&nbsp;</div>';
  }
}
else
{
  echo '<div class="phdr"><a href="./">Bloglar</a> | Fikrlar</div>';
  echo '<div class="menu">';
  echo 'Sizga mumkinmas!<br/>';
  echo '<a href="?act=com&amp;id='.$id.'">Ortga</a>';
  echo '</div>';
  echo '<div class="bmenu">&nbsp;</div>';
}
?>
