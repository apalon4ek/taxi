<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
if($user_id)
{
  $old = time() - (3 * 24 * 3600);  
  $read1 = mysql_query("SELECT * FROM `dnevniki` LEFT JOIN `dnevniki_com_rdm` ON `dnevniki`.`id` = `dnevniki_com_rdm`.`comid` AND `dnevniki_com_rdm`.`userid` = '" . $user_id . "' WHERE `dnevniki_com_rdm`.`userid` IS NULL AND `dnevniki`.`dnid` = 'com' AND `dnevniki`.`time` > '".$old."' ORDER BY `dnevniki`.`time`;");
  while($read = mysql_fetch_array($read1))
  {
    mysql_query("INSERT INTO `dnevniki_com_rdm` SET `comid` = '".$read['id']."', `recordid` = '".$read['com_id']."', `type` = '0', `userid` = '".$user_id."', `time` = '".$realtime."';");
  }
  echo '<div class="phdr">Blog</div>';
  echo '<div class="menu">Fikrlarni tozalash yakunlandi!<br/><a href="./">Qaytish</a></div>';
  echo '<div class="phdr">&nbsp;</div>';
}    
?>
