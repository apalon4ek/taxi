<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');

  if($ban[1])
  {
      echo functions::display_error('Siz banan yegansiz!');
      require_once ('../incfiles/end.php');
      exit; 
      
  }
    $req = mysql_query("SELECT * FROM `dnevniki` WHERE `id` = '".$id."' AND `dnid` = 'txt' LIMIT 1"); 
    if (mysql_num_rows($req))
    {    
      $res = mysql_fetch_assoc($req);
      $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res['userid']."' LIMIT 1");
      $datauser = mysql_fetch_assoc($req_user);
      if($user_id==$res['userid'] or (($rights >= 7) and $rights > $datauser['rights']))
      {
        $save = $_GET['save'];
        if($save)
        {
          $name22 = trim($_POST['name']);
          $text = trim($_POST['text']);
          if(!$name22)
            $err .= 'Nomini kiritmadingiz!<br/>';
          else
          {
            if(mb_strlen($name22) > 30)
              $err .= 'Sahifa nomi 30 belgidan oshmasligi kerak!<br/>';
          }
          if(!$text)
            $err .= 'Siz matnni kiritmadingiz!<br/>';
          else
          {
            if(mb_strlen($text) > 6000)
             $err .= 'Sahifa matni 6000 belgidan oshmasligi kerak!<br/>';   
          }  
        }
        if($save and !$err)
        {
          mysql_query("UPDATE `dnevniki` SET
          `text` = '" . mysql_real_escape_string($text) . "',
          `zag` = '" . mysql_real_escape_string($name22) . "',
          `mod_who` = '".$login."',
          `last_mod` = '".time()."'
           WHERE `id` = '".$id."'");
           
          echo '<div class="phdr"><a href="./">Bloglar</a> | Sahifani taxrirlash</div>';
          echo '<div class="menu">';
          echo 'Blog taxrirlandi!<br/>';
          echo '<a href="?act=view&amp;id='.$id.'">Davom etish</a>';
          echo '</div>';
          echo '<div class="phdr">&nbsp;</div>';
          echo '<a href="?act=view&amp;id='.$id.'"><img src="./img/edit.png" /> Sahifalarga</a><br />';
          echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
          require_once ('../incfiles/end.php');
          exit; 
        } 
        echo '<div class="phdr"><a href="./">Bloglar</a> | Sahifani taxrirlash</div>';
        if($err)
          echo '<div class="rmenu">'.$err.'</div>';
        echo '<form name="mess" action="?act=edit&amp;save=save&amp;id='.$id.'" method="post">';
        echo '<div class="gmenu">Заголовок:<br /><input type="text" name="name" value="'.($name22 ? htmlentities($name22, ENT_QUOTES, 'UTF-8') : htmlentities($res['zag'], ENT_QUOTES, 'UTF-8')).'" /></div>';
        echo '<div class="menu">Matn (bb-kod va smayllarga ruhsat):<br />'.bbcode::auto_bb('mess', 'text').'<textarea rows="' . $set_user['field_h'] . '" name="text">'.($text ? htmlentities($text, ENT_QUOTES, 'UTF-8') : htmlentities($res['text'], ENT_QUOTES, 'UTF-8')).'</textarea><br />';
        echo '<input type="submit" name="submit" value="Saqlash"/></div>';
        echo '<div class="phdr">&nbsp;</div>';
        echo '</form>';
        echo '<a href="?act=view&amp;id='.$id.'"><img src="./img/edit.png" /> Sahifalar</a><br />';
        echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
      }
      else
      {
        echo functions::display_error('Siz bu sahifani taxrirlayolmaysiz!');
        require_once ('../incfiles/end.php');
        exit;
      }
    }
    else
    {
      echo functions::display_error('XATOLIK!');
      require_once ('../incfiles/end.php');
      exit;
    }
?>
