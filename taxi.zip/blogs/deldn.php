<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
if($ban[1])
{
  echo functions::display_error('Siz ban olgansiz!');
  require_once ('../incfiles/end.php');
  exit; 
}
if($id)
{
  $req = mysql_query("SELECT * FROM `dnevniki` WHERE `userid` = '".$id."' AND `dnid` = 'dir' LIMIT 1");  
  if(mysql_num_rows($req))
  {
    $res = mysql_fetch_assoc($req);
    $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res['userid']."' LIMIT 1");
    $uz = mysql_fetch_assoc($req_user);
    if ($user_id==$id or (($rights >= 7) and $rights > $uz['rights']))
    {
      $del = $_GET['del'];
      if($del)
      {
        $deldn1  = mysql_query("SELECT * FROM `dnevniki` WHERE `dnid` = 'txt' AND `userid` = '".$id."';");  
        while ($deldn = mysql_fetch_assoc($deldn1))
        {
           mysql_query("DELETE FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$deldn['id']."'");
        }
        mysql_query("DELETE FROM `dnevniki` WHERE `userid` = '".$id."' AND `dnid`='dir'");
        mysql_query("DELETE FROM `dnevniki` WHERE `userid` = '".$id."' AND `dnid`='txt'");  
        echo '<div class="phdr"><a href="./">Bloglar</a> | Blogni o\'chirish</div>';
        echo '<div class="menu">Blog o\'chirildi!<br/>';
        echo '<a href="./">Davom etish</a></div>';
        echo '<div class="phdr">&nbsp;</div>';
        echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';
        require_once ('../incfiles/end.php');
        exit;
      }  
      echo '<div class="phdr"><a href="./">Bloglar</a> | Blogni o\'chirish</div>'; 
      echo '<div class="menu">'.$res['username'].'ning blogini o\'chirmoqchimisiz?<br/>';
      echo '<a href="?act=deldn&amp;del=del&amp;id='.$id.'">O\'chirish</a> | <a href="?act=showdn&amp;id='.$id.'">Bekor qilish</a></div>';
      echo '<div class="phdr">&nbsp;</div>';
      echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a><br />';  
    }
    else
    {
      echo '<div class="phdr"><a href="./">Bloglar</a> | Blogni o\'chirish</div>';
      echo '<div class="menu">';
      echo 'Sizga mumkinmas!<br/>';
      echo '<a href="./">Ortga</a>';
      echo '</div>';
      echo '<div class="phdr">&nbsp;</div>';
    }
  }
  else
  {
    echo '<div class="phdr"><a href="./">Bloglar</a> | Blogni o\'chirish</div>';
    echo '<div class="menu">';
    echo 'Sizga mumkinmas!<br/>';
    echo '<a href="./">Ortga</a>';
    echo '</div>';
    echo '<div class="phdr">&nbsp;</div>'; 
  }  
}
else
{
  echo '<div class="phdr"><a href="./">Bloglar</a> | Blogni o\'chirish</div>';
  echo '<div class="menu">';
  echo 'Sizga mumkinmas!<br/>';
  echo '<a href="./">Ortga</a>';
  echo '</div>';
  echo '<div class="phdr">&nbsp;</div>'; 
}
?>
