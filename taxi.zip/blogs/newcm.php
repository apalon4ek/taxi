<?php
defined('_IN_JOHNCMS') or die('Error: restricted acces');
$old = time() - (3 * 24 * 3600);
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` LEFT JOIN `dnevniki_com_rdm` ON `dnevniki`.`id` = `dnevniki_com_rdm`.`recordid` AND (`dnevniki_com_rdm`.`userid` = '".$user_id."' OR `dnevniki_com_rdm`.`userid` = '0' OR (`dnevniki_com_rdm`.`time` = '0' AND `dnevniki_com_rdm`.`userid` = '".$user_id."')) AND `dnevniki_com_rdm`.`type` = '0'  WHERE `dnevniki_com_rdm`.`userid` IS NULL AND `dnevniki`.`dnid` = 'txt' AND `dnevniki`.`time` > '".$old."'"), 0);
echo '<div class="phdr"><a href="./">Bloglar</a> | Yangi fikrlar</div>';
if($total > 0)
{
   $res1 = mysql_query("SELECT `dnevniki`.* FROM `dnevniki` LEFT JOIN `dnevniki_com_rdm` ON `dnevniki`.`id` = `dnevniki_com_rdm`.`recordid` AND (`dnevniki_com_rdm`.`userid` = '".$user_id."' OR `dnevniki_com_rdm`.`userid` = '0') AND `dnevniki_com_rdm`.`type` = '0'  WHERE `dnevniki_com_rdm`.`userid` IS NULL AND `dnevniki`.`dnid` = 'txt' AND `dnevniki`.`time` > '".$old."' ORDER BY `dnevniki`.`time` DESC LIMIT $start,$kmess");  
   $i=1;
   while($res = mysql_fetch_array($res1))
   {
      $total_plus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "1" AND `content`= "'.$res['id'].'" ;'), 0);
      $total_minus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "0" AND `content`= "'.$res['id'].'" ;'), 0); 
      $total_vote=$total_plus-$total_minus;
      echo ($i % 2) ? '<div class="list1">' : '<div class="list2">';
      echo '<b><a href="?act=view&amp;id='.$res['id'].'"><img src="img/dn.png" width="16" height="16" /> '.htmlentities($res['zag'], ENT_QUOTES, 'UTF-8').'</a></b><br />';
      echo htmlentities(mb_substr($res['text'], 0, 100), ENT_QUOTES, 'UTF-8').'...<br />';
      $cont = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$res['id']."'"), 0);
      echo '<a href="?act=com&amp;id='.$res['id'].'">Fikrlar</a> ('.$cont.dnevniki_com_new_local($res['id']).')';
      echo '<div class="sub">Qo\'shilgan: '.date("d.m.y / H:i", $res['vr']).' <br /> Reyting: '.$total_vote.'</div>';
      echo '</div>';
      $i++;
   }
   echo '<div class="bmenu">Umumiy: <b>'.$total.'</b></div>';
   if ($total > $kmess)
   {
     echo '<div class="topmenu">' . functions::display_pagination('?act=newcm&amp;', $start, $total, $kmess) . '</div>';
   }
}
else
{
  echo '<div class="menu">Yangi fikrlar yo\'q!</div>';  
  echo '<div class="phdr">&nbsp;</div>';
}
if ($user_id)
  echo '<a href="./?act=rescom"><img src="img/reset.png" width="16" height="16" /> Tozalash!</a><br/>';
echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a>';
?>
