<?php
if($rights >= 7)
{
  require_once ('../incfiles/head.php');
  if (isset ($_GET['yes']))
  {
    $dc = $_SESSION['dc'];
    $prd = $_SESSION['prd'];
    foreach ($dc as $delid)
    {
      //Далее следует чудовищный говнокод, слабонервным не смотреть!!! Я предупредил!!!
      $req = mysql_query("SELECT * FROM `dnevniki` WHERE `id` = '".intval($delid)."' AND `dnid` = 'com' LIMIT 1");
      $res = mysql_fetch_assoc($req);
      
      mysql_query("DELETE FROM `dnevniki` WHERE `dnid` = 'com' AND `id` = '".intval($delid)."' LIMIT 1");
      mysql_query("DELETE FROM `dnevniki_com_rdm` WHERE `recordid` = '".$res['com_id']."' AND `comid` = '".intval($delid)."' ;");
      $users_com1 = mysql_query("SELECT * FROM `dnevniki_com_rdm` WHERE `recordid` = '".$res['com_id']."' AND `userid` != '".$res['userid']."'");
      while($users_com = mysql_fetch_array($users_com1))
      {
         mysql_query("UPDATE `dnevniki_com_rdm` SET `type` = '0'  WHERE `recordid` = '".$res['com_id']."' AND `userid` = '".$users_com['userid']."' LIMIT 1;");
      }
      $tot_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki_com_rdm` WHERE `recordid` = '".$res['com_id']."' AND `type` = '0' AND `userid` = '".$res['userid']."';"), 0);
      if($tot_new ==0)
      {
        mysql_query("INSERT INTO `dnevniki_com_rdm` SET `comid` = '0', `recordid` = '".$res['com_id']."', `userid` = '0', `type` = '0', `time` = '0' ;");
      }
      
    }
    echo '<div class="phdr"><a href="./">Bloglar</a> | Tozalash</div>';
    echo '<div class="menu">Belgilangan postlar tozalandi<br/><a href="' . $prd . '">Davom etish</a></div>';
    echo '<div class="phdr">&nbsp;</div>';
  } 
  else
  {
    if (empty ($_POST['delch']))
    {
      echo '<div class="phdr"><a href="./">Bloglar</a> | Tozalash</div>';
      echo '<div class="menu">O\'chirish uchun hechnima tanlanmadi<br/><a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">Ortga</a></div>';
      echo '<div class="phdr">&nbsp;</div>';
      require_once ("../incfiles/end.php");
      exit;
    }
    foreach ($_POST['delch'] as $v)
    {
      $dc[] = intval($v);
    }
    $_SESSION['dc'] = $dc;
    $_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
    echo '<div class="phdr"><a href="./">Bloglar</a> | Tozalash</div>'; 
    echo '<div class="menu">Belgilangan postlarni tozalamoqchimisiz?<br/><a href="index.php?act=massdel&amp;yes">Tozalash</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">Оrtga</a></div>';
    echo '<div class="phdr">&nbsp;</div>';
  }  
  require_once ('../incfiles/end.php');
}    
?>