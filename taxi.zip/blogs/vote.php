<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
$do=$_GET['do'];
if($id)
{
  $alb1 = mysql_query('SELECT * FROM `dnevniki` WHERE `id` = "'.$id.'" AND `dnid`="txt" LIMIT 1');
  if (mysql_num_rows($alb1))
  {
     $alb = mysql_fetch_assoc($alb1);
     if(!$do)
     {
        echo '<div class="phdr">Bloglar</div>';
        echo '<div class="menu">Bunday sahifa mavjud emas!<br/><a href="./">Qaytish</a></div>';
        echo '<div class="phdr">&nbsp;</div>';
     }
     elseif($do=='adplus')
     {
       if($alb['userid']!=$user_id and $user_id)
       {
           if($ban['1'] or $ban['10'] or $ban['16'])
           {
             echo '<div class="phdr"><a href="./">Bloglar</a> | Ovoz berish</div>';
             echo '<div class="menu">Siz banan yegansiz va ovoz bera olmaysiz!<br/><a href="./">Ortga</a></div>';
             echo '<div class="phdr">&nbsp;</div>';
             require_once ("../incfiles/end.php");
             exit;  
           }
           $total_vote=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `content`= "'.$id.'" AND `userid` = "'.$user_id.'" ;'), 0);
           if($total_vote == 0)
           {
               mysql_query("INSERT INTO `dnevniki_vote` SET
              `type` = '1',
              `content` = '".$id."',
              `userid` = '".$user_id."',
              `username` = '".$datauser['name']."',
              `time` = '".time()."'");
              $total_plus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "1" AND `content`= "'.$id.'" ;'), 0);
              $total_minus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "0" AND `content`= "'.$id.'" ;'), 0);
              $total_vote=$total_plus-$total_minus; 
              mysql_query("UPDATE `dnevniki` SET
                `raiting` = '".$total_vote."'
                WHERE `id` = '".$id."'");
              echo '<div class="phdr"><a href="./">Bloglar</a> | Ovoz berish</div>';
              echo '<div class="menu">Ovozingiz qabul qilindi!<br/><a href="./?act=view&amp;id='.$id.'">Davom etish </a></div>';
              echo '<div class="phdr">&nbsp;</div>';  
           }
           else
           {
              echo '<div class="phdr"><a href="./">Bloglar</a> | Ovoz berish</div>';
              echo '<div class="menu">Siz ovoz berib bo\'lgansiz!<br/><a href="./?act=view&amp;id='.$id.'">Ortga</a></div>';
              echo '<div class="phdr">&nbsp;</div>';
           }
       }  
       else
       {
         echo '<div class="phdr"><a href="./">Bloglar</a> | Ovoz berish</div>';
         echo '<div class="menu">Siz o\'z sahifangizga ovoz bera olmaysiz!<br/><a href="./?act=view&amp;id='.$id.'">Ortga</a></div>';
         echo '<div class="phdr">&nbsp;</div>';  
       }
     }
     elseif($do=='adminus')
     {
       if($alb['userid']!=$user_id and $user_id)
       {
           if($ban['1'] or $ban['10'] or $ban['16'])
           {
             echo '<div class="phdr"><a href="./">Bloglar</a> | Ovoz berish</div>';
             echo '<div class="menu">Siz banan yegansiz va ovoz bera olmaysiz!<br/><a href="./">Ortga</a></div>';
             echo '<div class="phdr">&nbsp;</div>';
             require_once ("../incfiles/end.php");
             exit;  
           }
           $total_vote=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `content`= "'.$id.'" AND `userid` = "'.$user_id.'" ;'), 0);
           if($total_vote == 0)
           {
              mysql_query("INSERT INTO `dnevniki_vote` SET
              `type` = '0',
              `content` = '".$id."',
              `userid` = '".$user_id."',
              `username` = '".$datauser['name']."',
              `time` = '".time()."'");
              $total_plus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "1" AND `content`= "'.$id.'" ;'), 0);
              $total_minus=mysql_result(mysql_query('SELECT COUNT(*) FROM `dnevniki_vote` WHERE `type` = "0" AND `content`= "'.$id.'" ;'), 0);
              $total_vote=$total_plus-$total_minus; 
              mysql_query("UPDATE `dnevniki` SET
                `raiting` = '".$total_vote."'
                WHERE `id` = '".$id."'"); 
              echo '<div class="phdr"><a href="./">Bloglar</a> | Ovoz berish</div>';
              echo '<div class="menu">Ovozingiz qabtl qilindi!<br/><a href="./?act=view&amp;id='.$id.'">Davom etish</a></div>';
              echo '<div class="phdr">&nbsp;</div>';  
           }
           else
           {
              echo '<div class="phdr"><a href="./">Bloglar</a> | Ovoz berish</div>';
              echo '<div class="menu">Siz ovoz berib bo\'lgansiz!<br/><a href="./?act=view&amp;id='.$id.'">Ortga</a></div>';
              echo '<div class="phdr">&nbsp;</div>';
           }
       }  
       else
       {
         echo '<div class="phdr"><a href="./">Bloglar</a> | Ovoz berish</div>';
         echo '<div class="menu">Siz o\'z sahifangizga ovoz bera olmaysiz!<br/><a href="./?act=view&amp;id='.$id.'">Ortga</a></div>';
         echo '<div class="phdr">&nbsp;</div>';  
       } 
     }
  }
  else
  {
    echo '<div class="phdr">Bloglar</div>';
    echo '<div class="menu">Bunday sahifa mavjud emas!<br/><a href="./">Ortga</a></div>';
    echo '<div class="phdr">&nbsp;</div>'; 
  }
}
else
{
  echo '<div class="phdr">Bloglar</div>';
  echo '<div class="menu">Bunday sahifa mavjud emas!<br/><a href="./">Ortga</a></div>';
  echo '<div class="phdr">&nbsp;</div>';          
}
?>
