<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
echo '<div class="phdr"><b>Bloglar</b> | Yangi sahifalar</div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` LEFT JOIN `dn_rdm` ON `dnevniki`.`id` = `dn_rdm`.`dnid` AND `dn_rdm`.`user_id` = '" . $user_id . "' WHERE `dn_rdm`.`user_id` IS NULL AND `dnevniki`.`dnid` = 'txt' AND `vr` > '".$old."' ;"), 0); 
if ($total)
{
  echo '<div class="bmenu">Непрочитанные записи</div>';
  $old = time() - (3 * 24 * 3600);
  $req = mysql_query("SELECT * FROM `dnevniki` LEFT JOIN `dn_rdm` ON `dnevniki`.`id` = `dn_rdm`.`dnid` AND `dn_rdm`.`user_id` = '" . $user_id . "' WHERE `dn_rdm`.`user_id` IS NULL AND `dnevniki`.`dnid` = 'txt' AND `vr` > '".$old."' ORDER BY `vr` DESC LIMIT $start,$kmess");
  while ($res = mysql_fetch_assoc($req))
  {
    $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$res['userid']."' LIMIT 1");
    $datauser = mysql_fetch_assoc($req_user); 
    echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
    echo '<b><a href="?act=view&amp;id='.$res['id'].'"><img src="img/dn.png" width="16" height="16" /> '.htmlentities($res['zag'], ENT_QUOTES, 'UTF-8').'</a></b><br />';
    echo htmlentities(mb_substr($res['text'], 0, 100), ENT_QUOTES, 'UTF-8').'...<br />';
    $cont = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$res['id']."'"), 0); 
    echo '<a href="?act=com&amp;id='.$res['id'].'">Fikrlar</a> ('.$cont.dnevniki_com_new_local($res['id']).')';
    echo '<span class="gray"><br />Muallif:'.$datauser['name'].'</span>';
    echo '<div class="sub">Qo\'shildi: '.date("d.m.y / H:i", $res['vr']).' <br /> O\'qilgan: '.$res['views'].' marta</div>';
    echo '</div>';
    ++$i;
  }
}
else
{
  echo '<div class="menu">O\'qilmagan sahifalar yo\'q!</div>';
  $total=0;
}
echo '<div class="phdr">Umumiy sahifalar: <b>'.$total.'</b></div>';
if ($total > $kmess)
{
  echo '<div class="topmenu">' . functions::display_pagination('?act=new&amp;', $start, $total, $kmess) . '</div>';
}
if ($total and $user_id)
  echo '<a href="./?act=reset"><img src="img/reset.png" width="16" height="16" /> Yangilash!</a><br/>';
echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a>';

?>
