<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');

  $dn1 = mysql_query("SELECT * FROM `dnevniki` WHERE `userid` = '".$id."' AND `dnid` = 'dir' LIMIT 1");
  if (mysql_num_rows($dn1))
  {
    $req_user = mysql_query("SELECT * FROM `users` WHERE `id` = '".$id."' LIMIT 1");
    $datauser = mysql_fetch_assoc($req_user);  
    $dn = mysql_fetch_assoc($dn1);
    if ($user_id==$id)
      echo '<div class="phdr"><a href="./">Bloglar</a> | Mening blogim</div>';
    else
      echo '<div class="phdr"><a href="./">Bloglar</a> | <b>'.($datauser['id'] ? '<a  href="../users/profile.php?user='.$id.'">'.$dn['username'].'</a>' : $dn['username'] ).'</b>ning blogi</div>';
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'txt' AND `userid` = '".$id."'"), 0); 
    $req = mysql_query("SELECT * FROM `dnevniki` WHERE `dnid` = 'txt' AND `userid` = '".$id."' ORDER BY `vr` DESC LIMIT $start,$kmess"); 
    while ($res = mysql_fetch_assoc($req))
    {
      echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
      echo '<b><a href="?act=view&amp;id='.$res['id'].'"><img src="img/dn.png" width="16" height="16" /> '.htmlentities($res['zag'], ENT_QUOTES, 'UTF-8').'</a></b><br />';
      echo htmlentities(mb_substr($res['text'], 0, 100), ENT_QUOTES, 'UTF-8').'...<br />';
      $cont = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'com' AND `com_id` = '".$res['id']."'"), 0); 
      echo '<a href="?act=com&amp;id='.$res['id'].'">Fikrlar</a> ('.$cont.dnevniki_com_new_local($res['id']).')';
      echo '<div class="sub">Qo\'shildi: '.date("d.m.y / H:i", $res['vr'] + 5 * 60 * 60).' <br /> O\'qilgan: '.$res['views'].' marta</div>';
      echo '</div>';
      ++$i;
    }
    echo '<div class="phdr">Umumiy sahifalar: <b>'.$total.'</b></div>';
    if ($total > $kmess)
       echo '<div class="topmenu">' . functions::display_pagination('?act=showdn&amp;id='.$id.'&amp;', $start, $total, $kmess) . '</div>';
    if ($user_id==$id and !$ban[1] and !$ban[16])
       echo '<a href="?act=wr&amp;id='.$id.'"><img src="img/add.png" width="16" height="16" /> Sahifa qo\'shish</a><br />';
    if (($user_id==$id or (($rights==7 or $rights >= 7) and $rights > $datauser['rights'])))
       echo '<a href="?act=deldn&amp;id='.$id.'"><img src="img/remove.png" width="16" height="16" /> Blogni o\'chirish</a><br />';
    echo '<a href="./"><img src="./img/folder.png" /> Bloglar</a>';

  }
  else
  {
      echo functions::display_error('Bunday blog mavjud emas!','<a href="./">Ortga</a>');
      require_once ('../incfiles/end.php');
      exit;
  }
?>
