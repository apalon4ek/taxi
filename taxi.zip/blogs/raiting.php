<?php
header("Content-type: image/png");
$img = imagecreatefrompng('img/back.png');
$show=intval(abs($_GET['show']));
if($show <= 100 and $show >= 0)
{
  $strip = imagecreatefrompng('img/raiting.png');
  $imgwidth = imagesx($strip);
  $imgheight = imagesy($strip);
  $width=ceil($imgwidth*$show/100);
  imagecopy($img, $strip, 0, 0, 0, 0, $width, $imgheight);
  imagepng($img);  
}
else
{
  imagepng($img);  
}
?>
