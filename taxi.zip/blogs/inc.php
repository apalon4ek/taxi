<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
function dnevniki_com_new_local($id)
{
  global $user_id;
  $old = time() - (3 * 24 * 3600);
  $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` LEFT JOIN `dnevniki_com_rdm` ON `dnevniki`.`id` = `dnevniki_com_rdm`.`comid` AND `dnevniki_com_rdm`.`userid` = '" . $user_id . "' WHERE `dnevniki_com_rdm`.`userid` IS NULL AND `dnevniki`.`dnid` = 'com' AND `dnevniki`.`com_id` = '".$id."' AND `dnevniki`.`time` > '".$old."' ORDER BY `dnevniki`.`time`;"), 0);
  if ($total) return '/<span class="red">+'.$total.'</span>';  
}

////////////////самоочистка системы////////////////////////
$old = time() - (3 * 24 * 3600);
mysql_query("DELETE FROM `dnevniki_com_rdm` WHERE `time` < '".$old."' AND `comid` != '0';");
mysql_query("DELETE FROM `dnevniki_rdm` WHERE `time` < '".$old."';");
///////////////////////////////////////////////////////////
?>
