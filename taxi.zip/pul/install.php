<?php

define('_IN_JOHNCMS', 1);
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

if($rights >= 9){
mysql_query("DROP TABLE `balans_popol`;");
mysql_query("CREATE TABLE `balans_popol` (
`id` INT NOT NULL AUTO_INCREMENT,
`user` VARCHAR(20) NOT NULL,
`bal` VARCHAR(10) NOT NULL,
`status` set('1','2') DEFAULT '1',
`time` VARCHAR(10) NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)) ENGINE = MyISAM;");


mysql_query("DROP TABLE `balans_vivod`;");
mysql_query("CREATE TABLE `balans_vivod` (
`id` INT NOT NULL AUTO_INCREMENT,
`user` VARCHAR(20) NOT NULL,
`bal` VARCHAR(10) NOT NULL,
`kow` VARCHAR(16) NOT NULL,
`status` set('1','2') DEFAULT '1',
`time` VARCHAR(10) NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)) ENGINE = MyISAM;");


mysql_query("DROP TABLE `balans_obmen`;");
mysql_query("CREATE TABLE `balans_obmen` (
`id` INT NOT NULL AUTO_INCREMENT,
`user` VARCHAR(20) NOT NULL,
`bal` VARCHAR(10) NOT NULL,
`nomer` VARCHAR(16) NOT NULL,
`status` set('1','2') DEFAULT '1',
`time` VARCHAR(10) NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)) ENGINE = MyISAM;");

echo'.Установлено !';
}else{
echo 'Че ты  сдесь забыл!';
}

require_once ('../incfiles/end.php');
?>
PRIMARY KEY (`id`)) ENGINE = MyISAM;");


mysql_query("DROP TABLE `balans_vivod`;");
mysql_query("CREATE TABLE `balans_vivod` (
`id` INT NOT NULL AUTO_INCREMENT,
`user` VARCHAR(20) NOT NULL,
`bal` VARCHAR(10) NOT NULL,
`kow` VARCHAR(16) NOT NULL,
`status` set('1','2') DEFAULT '1',
`time` VARCHAR(10) NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)) ENGINE = MyISAM;");


mysql_query("DROP TABLE `balans_obmen`;");
mysql_query("CREATE TABLE `balans_obmen` (
`id` INT NOT NULL AUTO_INCREMENT,
`user` VARCHAR(20) NOT NULL,
`bal` VARCHAR(10) NOT NULL,
`nomer` VARCHAR(16) NOT NULL,
`status` set('1','2') DEFAULT '1',
`time` VARCHAR(10) NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)) ENGINE = MyISAM;");

echo'Таблицы ОК. ))';
}else{
echo 'У вас не хватает прав!';
}

require_once ('../incfiles/end.php');
?>
