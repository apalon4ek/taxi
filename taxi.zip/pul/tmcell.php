﻿<?php
define('_IN_JOHNCMS', 1);
$headmod = 'pul';
$textl = 'Pullar paneli';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
if (empty($_SESSION['uid']))
{
    echo "Faqat sayt azolari uchun!<br/>";
    require_once ("../incfiles/end.php");
    exit;
}
// Проверка на флуд
$flood = functions::antiflood();
if ($flood) {
require('../incfiles/head.php');
echo functions::display_error($lng['error_flood'] . ' ' . $flood . $lng['sec'], '<a href="?id=' . $id . '&amp;start=' . $start . '">' . $lng['back'] . '</a>');
require('../incfiles/end.php');
exit;
}
echo '<div class="phdr"><a href="index.php"><b>Pullar paneli</b></a> | UZ operatorlariga pul yechish </div>';

echo '<div class="menu">&#160;<center><span class="red">Nosozlik:<br /> UZ operatorlariga pul yechish haftada bir marta boladi. Minimum pul yechish 3 som!</span>
</div>';

if (isset($_POST['submit'])) {
$error = false;
$bal= isset($_POST['bal']) ? trim($_POST['bal']) : '';
$nomer= isset($_POST['nomer']) ? trim($_POST['nomer']) : '';

if (mb_strlen($nomer) > 15)
$error = 'Telefon belgi notogri. Mak 15 simowl!';

if($datauser['manat']<$bal)
$error = 'Ýetarli pul  yok!';

if (!$error) {
// Добавляем тему
mysql_query("INSERT INTO `balans_obmen` SET `id` = '$id', `time` = '" . time() . "', `user` = '$login', `nomer` = '$nomer', `bal` = '$bal'");
echo '<div class="rmenu">Malumotlar moderatsiya yuborildi! Biroz quting.
</div>';

} else {

// Выводим сообщение об ошибке
require_once('../incfiles/head.php');
echo '<div class="rmenu"><p>Nosozlik!<br />' . $error . '<br /><a href="index.php?act=add">Boshqatdan</a></p></div>';
require_once('../incfiles/end.php');
exit;
}

} else {

echo '<form action="tmcell.php?act=tmcell" method="post"><div class="menu">';
echo '<p><h3>yechish  summa:</h3><textarea rows="1" cols="5" type="text" name="bal"></textarea></p>';

echo '<p><h3>Telefon nomer:</h3><textarea rows="1" cols="5" type="text" name="nomer">+998</textarea></p>';
echo '<p><input type="submit" value="Davom etish" name="submit" /></p></div>';
echo '</form>';
}

require_once ("../incfiles/end.php");
?>
