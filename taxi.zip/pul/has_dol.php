﻿<?php
define('_IN_JOHNCMS', 1);
$headmod = 'pul';
$textl = 'Hisobingizni toldirish';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
if (empty($_SESSION['uid']))
{
    echo "Faqat azo bolganlar uchun!<br/>";
    require_once ("../incfiles/end.php");
    exit;
}
// Проверка на флуд
$flood = functions::antiflood();
if ($flood) {
require('../incfiles/head.php');
echo functions::display_error($lng['error_flood'] . ' ' . $flood . $lng['sec'], '<a href="?id=' . $id . '&amp;start=' . $start . '">' . $lng['back'] . '</a>');
require('../incfiles/end.php');
exit;
}

echo '<div class="zetpro"><b><a href="../pul/index.php">Pullar paneli</a> | Hisobni toldurish</b></div>';

echo '<div class="menu"><b>Hisobingizni toldirish uchun <i>+998</i> tel raqamga,pulni otkazasiz wa osha nomerdan sms qilib oingizning id raqamingizni yoki nikingizni yozib yuboring ! Sizning hisobingiz 24 soat ichida toldiriladi!</b> </div>';

require_once ("../incfiles/end.php");
?>