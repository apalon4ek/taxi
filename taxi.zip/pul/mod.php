<?php
define('_IN_JOHNCMS', 1);
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

if ($rights >= 9) {
if (empty($_SESSION['uid']))
{
echo "Вы не авторизованы!<br/>";
require_once ("../incfiles/end.php");
exit;
}
if($rights >= 9){
echo '<div class="phdr">Админ Панель / Запросы ввода/вывода рублей </div>';


$q = mysql_query("SELECT * FROM `balans_popol` WHERE `status` = '1'" );
$count = mysql_num_rows($q);
for ($i = 0; $i++ < $count; ) {
$result = mysql_fetch_assoc($q);

echo 'Номер счета: ' . $result['id'] . '<br/>';
echo 'Запросил: <a href="../users/profile.php?user=' . $us['id'] . '">'. $result['user'] .'</a><br/>';
echo 'Сумма ввода: ' . $result['bal'] . ' рубл<br/>';
echo 'Время ввода:  '.functions::display_date($result['time']).'<br/>';
echo '<a href="/billing/set.php?oki=' . $result [ 'id' ]. '">Выполнить </a> | <a href="/billing/set.php?del=' . $result [ 'id' ]. '"> Удалить</a><br/>' ;
}

$q = mysql_query("SELECT * FROM `balans_vivod` WHERE `status` = '1'" );
$count = mysql_num_rows($q);
for ($i = 0; $i++ < $count; ) {
$result = mysql_fetch_assoc($q);

echo '&#160;<span class="red">Номер вывода: ' . $result['id'] . '<br/>';
echo 'Запросил: <a href="../users/profile.php?user=' . $us['id'] . '">'. $result['user'] .'</a><br/>';
echo 'Сумма вывода: ' . $result['bal'] . ' рубл<br/>';
echo 'Кошелек: ' . $result['kow'] . '<br/>';
echo 'Время вывода:  '.functions::display_date($result['time']).'</span><br/>';
echo '<a href="/billing/setv.php?oki=' . $result [ 'id' ]. '">Выполнить </a> | <a href="/billing/setv.php?del=' . $result [ 'id' ]. '"> Удалить</a><br/>';

}

$q = mysql_query("SELECT * FROM `balans_obmen` WHERE `status` = '1'" );
$count = mysql_num_rows($q);
for ($i = 0; $i++ < $count; ) {
$result = mysql_fetch_assoc($q);

echo '&#160;<span class="gray">Номер счета: ' . $result['id'] . '<br/>';
echo 'Запросил: <a href="../users/profile.php?user=' . $us['id'] . '">'. $result['user'] .'</a><br/>';
echo 'Сумма обмена: ' . $result['bal'] . ' рубл<br/>';
echo 'Номер телефона: ' . $result['nomer'] . '<br/>';
echo 'Время добавления:  '.functions::display_date($result['time']).'</span><br/>';
echo '<a href="/billing/setv.php?oki=' . $result [ 'id' ]. '">Выполнить </a> | <a href="/billing/setv.php?del=' . $result [ 'id' ]. '"> Удалить</a><br/>';

}
}
}
require_once ( "../incfiles/end.php" );
?>
