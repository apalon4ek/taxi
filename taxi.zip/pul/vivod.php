<?php
define('_IN_JOHNCMS', 1);
$headmod = 'pul';
$textl = 'Биллинг  панель';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

if (empty($_SESSION['uid']))
{
    echo "Вы не авторизованы!<br/>";
    require_once ("../incfiles/end.php");
    exit;
}
// Проверка на флуд
$flood = functions::antiflood();
if ($flood) {
require('../incfiles/head.php');
echo functions::display_error($lng['error_flood'] . ' ' . $flood . $lng['sec'], '<a href="?id=' . $id . '&amp;start=' . $start . '">' . $lng['back'] . '</a>');
require('../incfiles/end.php');
exit;
}
echo '<div class="phdr"><a href="index.php"><b>Биллинг панель</b></a> | Запросить вывод </div>';

echo '<div class="phdr">&#160;<span class="red">Выплаты отменить нельзя.<br />Для вывода средствь в вашем счете должно быть достаточно сумм для вывода. В противном случае вы получите блокировку аккаунта!</span>
</div>';

if (isset($_POST['submit'])) {
$error = false;
$bal= isset($_POST['bal']) ? trim($_POST['bal']) : '';
$kow= isset($_POST['kow']) ? trim($_POST['kow']) : '';

if (mb_strlen($bal) > 3)
$error = 'Сумма баланса слишком великий. Максимум 999 рубл !';
if (mb_strlen($kow) > 13)
$error = 'Номер котелка неверный. Максимум 15 символов !';

if($datauser['manat']<$bal)
$error = 'Недостаточно баланса на счете  !';

if (!$error) {
// Добавляем тему
mysql_query("INSERT INTO `balans_vivod` SET
`id` = '$id',
`time` = '" . time() . "',
`user` = '$login',
`kow` = '$kow',
`bal` = '$bal'");
echo '<div class="rmenu">
Ваш баланс будет выведен в течении 24 часов. В случае задержки, обращайтесь наник  Админ.
</div>';

} else {

// Выводим сообщение об ошибке
require_once('../incfiles/head.php');
echo '<div class="rmenu"><p>ОШИБКА!<br />' . $error . '<br /><a href="index.php?act=add">Повторить</a></p></div>';
require_once('../incfiles/end.php');
exit;
}

} else {

echo '<form action="vivod.php?act=vivod" method="post"><div class="menu">';
echo '<p><h3>Сумма:</h3><textarea rows="1" cols="5" type="text" name="bal"></textarea></p>';

echo '<p><h3>Кошелек:</h3><textarea rows="1" cols="5" type="text" name="kow">R' . $datauser['wmr']   . '</textarea></p>';
echo '<p><input type="submit" value="Продолжить" name="submit" /></p></div>';
echo '</form>';
}

require_once ("../incfiles/end.php");
?>
