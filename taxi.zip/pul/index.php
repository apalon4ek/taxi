﻿<?php
define('_IN_JOHNCMS', 1);
$headmod = 'pul';
$textl = 'Pullar paneli';

require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");


if (empty($_SESSION['uid']))
{
    echo "<div class='rmenu'>Faqat azolar uchun!</div><br/>";
    require_once ("../incfiles/end.php");
    exit;
}
echo '<div class="zetpro"><b>Pullar paneli</b></div>';

echo '<div class="menu"><img src="img/manat.png" alt="" /> Sizda: <b>'.$datauser['manat'].'</b> som bor!</div>';

echo '<div class="menu"><img src="../images/coins.png" alt="" /> Sizda: <b><a href="../shop/index.php">'.$datauser['balans'].'</a></b> ball bor!</div>';



echo '<div class="habar1"><img src="img/addr.png" alt="" /> <a href="has_dol.php">Hisobni toldirish</a></div>';

echo '<div class="habar1"><img src="img/money_arrow.png" alt="" /> <a href="tmcell.php">Pul yechish</a></div>';

//echo '<div class="habar1"><img src="img/vyvod.png" alt="" /> <a href="vivod.php">Webmoney,Payeer,Qiwi koshelyoklariga pul yechish</a></div>';


echo '<div class="habar1"><img src="img/zzz.png" alt="" /> <a href="../shop/manat.php">Manat paýlaşmak</a></div>';

//echo '<div class="menu"><img src="img/sc.png" alt="" /> <a href="cheat.php">Счета</a></div>';

//echo '<div class="menu"><img src="img/keep.png" alt="" /> <a href="kow.php">Miniň gapjygym</a></div>';


//echo '<div class="menu"><img src="img/vyvod.png" alt="" /> <a href="vivod.php">Услуги</a></div>';


require_once ("../incfiles/end.php");
?>
