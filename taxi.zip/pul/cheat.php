<?

define('_IN_JOHNCMS', 1);
$textl = 'Meniň gapjygym';
$rootpath = '../';
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');


if (empty($_SESSION['uid']))
{
echo "Diňe agzalar üçin!<br/>";
require_once ("../incfiles/end.php");
exit;
}
if($rights >= 9){
echo '<div class="phdr">Meniň gapjygym</div>';

   
echo '<div class="func">Gapjyk: R'.$datauser['wmr'].'<br />
BL:<img src="https://stats.wmtransfer.com/Levels/pWMIDLevel.aspx?wmid='.htmlspecialchars($datauser['wmid']).'&amp;w=35&amp;h=16&amp;bg=0XDBE2E9" width="35" height="16" alt="BL" title="Biznes dereje [BL]" /><br />
Претензии/Отзывы/Иски: </span><img src="http://arbitrage.webmoney.ru/xml/AL2.aspx?wmid='.htmlspecialchars($datauser['wmid']).' "/>&#160;<br /></div>';


}

require('../incfiles/end.php');
?>
