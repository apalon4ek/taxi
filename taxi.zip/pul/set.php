<?php
define ( '_IN_JOHNCMS' , 1 );
require( '../incfiles/core.php' );
require( '../incfiles/head.php' );
$textl = 'Стол заказов';

if ($rights >= 9) {
if (isset( $_GET [ 'del' ]) && $_GET [ 'del' ] != NULL )
{
mysql_query ( "DELETE FROM `balans_popol` WHERE `id` = '" . intval ( $_GET [ 'del' ]). "'" );


echo 'Удалил нахер ! :)';
}
if (isset( $_GET [ 'oki' ])) {
$id = abs ( intval ( $_GET [ 'oki' ]));
$balans_popol = mysql_fetch_array ( mysql_query ( "SELECT * FROM `balans_popol` WHERE `id` = ' $id ' LIMIT 1" ));

if (!isset( $balans_popol [ 'id' ])) {
echo 'Ошибка!';
} else {
mysql_query ( "UPDATE `balans_popol` SET `status`= '2' WHERE `id` = ' $id '" );
mysql_query ("UPDATE `users` SET
`manat`=`manat`+" . $balans_popol['bal'] . "
WHERE `id`='" . $balans_popol['user'] . "'");

echo 'Добавил брат! :)';
}
}
}
require( '../incfiles/end.php' );
?>
