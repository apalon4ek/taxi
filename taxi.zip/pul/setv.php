<?php
define ( '_IN_JOHNCMS' , 1 );
require( '../incfiles/core.php' );
require( '../incfiles/head.php' );
$textl = 'Стол заказов';

if (isset( $_GET [ 'del' ]) && $_GET [ 'del' ] != NULL )
{
mysql_query ( "DELETE FROM `balans_vivod` WHERE `id` = '" . intval ( $_GET [ 'del' ]). "'" );
}
if (isset( $_GET [ 'oki' ])) {
$id = abs ( intval ( $_GET [ 'oki' ]));
$balans_vivod = mysql_fetch_array ( mysql_query ( "SELECT * FROM `balans_vivod` WHERE `id` = ' $id ' LIMIT 1" ));

if (!isset( $balans_vivod [ 'id' ])) {
echo 'Ошибка!';
} else {
mysql_query ( "UPDATE `balans_vivod` SET `status`= '2' WHERE `id` = ' $id '" );
mysql_query ("UPDATE `users` SET `manat`=`manat`-" . $balans_vivod['bal'] . " WHERE `id`='" . $balans_vivod['user'] . "'");


echo 'Всё огонь! :)';
}
}
require( '../incfiles/end.php' );
?>
