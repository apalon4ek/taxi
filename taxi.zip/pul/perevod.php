<?php
define('_IN_JOHNCMS', 1);
$textl = 'Биллинг панель/Перевод баллов';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

echo '<div class="phdr">Биллинг панель / Перевод средств </div>';

if(!$user_id){
echo '<div class="rmenu">Только для зарегистрированных!</div>';
require_once ('../incfiles/end.php');
exit;
}
if (isset($_POST['submit'])){

$ids=($_POST['id']);
$bal=($_POST['bal']);
if($datauser['manat']<$bal){
echo '<div class="rmenu">У вас недостаточно баланса!</div>';
require_once ('../incfiles/end.php');
exit;
}
if (empty($ids))
{
echo '<div class="rmenu">Вы незаполнили поле ид!</div>';
require_once ('../incfiles/end.php');
exit;
}
if (empty($bal))
{
echo '<div class="rmenu">Вы незаполнили поле баланс!</div>';
require_once ('../incfiles/end.php');
exit;
}
mysql_query("UPDATE `users` SET
`manat`=`manat`-" . $bal . "
WHERE `id`='" . $user_id . "'");
mysql_query("UPDATE `users` SET
`manat`=`manat`+" . $bal . "
WHERE `id`='" . $ids . "'");

echo '<div class="gmenu">С вашего счета была переводено '.$bal.' рубл на  ' . $id . ' иду</div><br><a href="../users/profile.php>Назад</a>';


} else {
echo '<div class="menu"><form action="" method="post">Введите id пользавателя : <br/><input type="text" name="id" size="20" maxlength="27"/>
Введите количество рублей:<br/><input type="text" name="bal" size="20" maxlength="10" /><input type="submit" name="submit" value="Переводить!" /></form></div>';
}
echo '</div>';
require_once ("../incfiles/end.php");
?>
