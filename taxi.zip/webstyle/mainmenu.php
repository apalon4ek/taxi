<?

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();
/*
    --------------------------------------------слайд---------------------
    */
/*
-----------------------------------------------------------------
Блок информации
-----------------------------------------------------------------
*/
echo '<div class="gphdr"><b>' . $lng['information'] . '</b></div>';
echo $mp->news;
echo '<div class="gpmenu"><a href="news/index.php">' . $lng['news_archive'] . '</a> (' . $mp->newscount . ')</div>' .
    '<div class="gpmenu"><a href="pages/faq.php">' . $lng['information'] . ', FAQ</a></div>';

/*
-----------------------------------------------------------------
Блок общения
-----------------------------------------------------------------
*/

echo '<div class="gphdr"><b>Bizning xizmatlar</b></div>';
 
echo '<div class="gpmenu"><a href="taxi">BIZNESS TAXI</a></div>';
echo '<div class="gpmenu"><a href="sovun">Xo\'jalik mahsulotlari</a></div>';
echo '<div class="gpmenu"><a href="sayt">Dastur tuzish</a></div>';
echo '<div class="gpmenu"><a href="pay">Pul o\'tkazmalari</a></div>';




echo '<div class="gphdr"><b>' . $lng['dialogue'] . '</b></div>';
// Ссылка на гостевую
if ($set['mod_guest'] || $rights >= 7)
    echo '<div class="gpmenu"><a href="guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')</div>';
// Ссылка на Форум
if ($set['mod_forum'] || $rights >= 7)
    echo '<div class="gpmenu"><a href="forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')</div>';

/*
-----------------------------------------------------------------
Блок полезного
-----------------------------------------------------------------
*/    




echo '</div><!-- lefts--> ';
    echo '<div class="main">';
?>
