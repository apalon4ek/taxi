<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
require_once ('rightmenu.php');
echo '<div class="both"></div>
<div class="footer"><span class="wap" style=float:left> ' . counters::online() . '
</span><span class="wap"><a href="' . $set['homeurl'] . '/mode.php?mode=wap">WAP versiya</a></span>
';

// Счетчики каталогов
functions::display_counters();

// Рекламный блок сайта
if (!empty($cms_ads[3])) {
    echo '<br />' . $cms_ads[3];
}

echo '<div><small>&copy; <a href="http://alijohn">AAK</a></small></div>
</div>
</body>
</html> 
';
?>

