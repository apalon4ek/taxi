<?php  
defined('_IN_JOHNCMS') or die('Error: restricted access');
echo '</div><div class="right"> <!-- right -->
  <ul>';
  if (!$user_id) {
  	// форма входа на сайт для гостей
 echo '<li class="title"><b>Saytga kirish</b></li>
 <div class="new1"><form method="post" action="/login.php">'.

'Login:<br/><input type="text" name="n" maxlength="20" size="15" /><br/>'.

'Parol:<br/><input type="password" name="p" maxlength="20" size="15" /><br/>'.

'<input type="checkbox" name="mem" value="1" checked="checked"/> Eslab qol<br/>'.

'<input name="login" type="hidden" id="login" value="submit" />'.

'<button type="submit"/>Kirish</button></form></div>';

echo '<div class="new1"><a href="/registration.php">Ro\'yxatdan o\'tish</a> | <a href="/users/skl.php?continue">Parolni unutdizmi?</a></div>'; 
 } else { // блок для пользователей
 echo'<li class="title"><b>' . $lng['hi'] . ', ' . $login . '</b>!</li>';
 echo '<li class="title" style="margin-top:-1px"><b><a href="'.$home.'/choyxor/bfaol.php">Sayt faollari</a></b></li>';
 $faollar = mysql_query("SELECT * FROM `chat_faoli` ORDER BY RAND() LIMIT 1");
while ($faol = mysql_fetch_array($faollar)) {  
    $faolid = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '" .$faol['user_id']. "' "));
    $yoshi = (2000 + date("y")) - $faol['yili'];
    $info = '<span class="gray">Ismi: </span> '.$faol['ism'].', '.$yoshi.' <span class="gray">yoshda</span>, '.$faol['shaxar'].'<span class="gray">dan</span>.<br /><span class="gray">Harakteri: </span> '.$faol['xarakteri'].'.';
   $header = '';
                $arg = array(
                    'header' => $header,
                    'body'   => $info,
                    'iphide' => 1
                );
                echo '<li><br />'.functions::display_user($faolid, $arg).'</li>';
}
		$faolmi = mysql_result(mysql_query("select count(*) from `chat_faoli` where `user_id` = '".$user_id."'"),0);
   if ($faolmi == 0) 
 echo '<li class="title" style="margin-top:-1px"><b>Tezkor manzillar:</b></li>
 <li><a href="'.$home.'/shop">Sayt magazini</a></li>
 <li><a href="'.$home.'/guestbook">Ommaviy savol-javob</a></li>';
 }

echo '<li class="title" style="margin-top:-1px"><b>Forumdagi so\'nggi xabarlar</b></li>';
$limit = '5'; // количество тем 
$req_t = mysql_query("SELECT `id`, `text` FROM `forum` WHERE `type`='t' ORDER BY `time` DESC LIMIT $limit "); // запрос 
while($res_t = mysql_fetch_array($req_t)){ 
echo '<li class="lis"> <a href="/forum/?id='.$res_t['id'].'"> '.$res_t['text'].'</a></li>'; // вывод темы 
}

    $i = 0;
    while ($row = mysql_fetch_assoc($sql)) {
        echo '<li class="lis">';
        echo '<a href="'.$home.'/library/index.php?id=' . $row['id'] . '">' . functions::checkout($row['name']) . '</a><br />';
        echo '' . functions::checkout(bbcode::notags($row['announce'])) . '';
        echo '</li>';
    }

echo'</div>
</ul>
';
?>