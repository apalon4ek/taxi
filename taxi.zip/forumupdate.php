<?php
define('_IN_JOHNCMS', 1);
set_time_limit(1200);

$mtime = explode(' ', microtime());
$mtime = $mtime[1] + $mtime[0];
$starttime = $mtime;

$rootpath = '';
require 'incfiles/core.php';

$textl = 'Форум by seg0ro';

require 'incfiles/head.php';

if ($rights < 9){
  echo functions::display_error('У вас недостаточно прав для просмотра этой страницы!');
  require 'incfiles/end.php';
  exit;
}

switch (trim($_GET['step'])){
  
  case 'tables':
    
    mysql_query("ALTER TABLE `forum_forums` ADD `close` TINYINT( 1 ) NOT NULL ,
ADD `template` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;");

     mysql_query("ALTER TABLE `forum_posts` CHANGE `edit` `edit` VARCHAR( 250 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '';");

    mysql_query("CREATE TABLE IF NOT EXISTS `forum_logs` (
    `time` int( 11 ) NOT NULL ,
    `user_id` int( 11 ) NOT NULL ,
    `text` text NOT NULL ,
    `browser` varchar( 250 ) NOT NULL ,
    `ip` bigint( 11 ) NOT NULL ,
    `ip_via_proxy` bigint( 11 ) NOT NULL 
    ) ENGINE = MYISAM DEFAULT CHARSET = utf8;");
  
    echo '<div class="phdr">Установка таблиц</div><div class="gmenu">Таблицы обновлены/установлены</div>'.
   '<div class="menu">Выберите ссылку для перехода на форум:<br /><a href="forum/index.php">Форум</a></div>';
  break;
  
  default:
   echo '<div class="phdr">Форум by seg0ro</div><div class="gmenu">Добро пожаловать в мастер обновления форума.</div>'.
   '<div class="menu">Выберите ссылку для продолжения процесса обновления данных:<br /><a href="foruminstall.php?step=tables">Установка таблиц</a></div>';
  
}

$mtime = explode(' ', microtime());
$mtime = $mtime[1] + $mtime[0];
$endtime = $mtime;
$totaltime = round(($endtime - $starttime), 3);
echo '<div class="topmenu">Генерация: '.$totaltime.' сек.</div>';

require 'incfiles/end.php';