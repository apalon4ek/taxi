﻿<?php
define('_IN_JOHNCMS', 1);
require_once ('inc/core.php');

if (!$set['java']) exit('<div class="error">Модуль закрыт администратором</div>');

$req = mysql_query("SELECT `name`,`text` FROM `article` WHERE `id` = '$id' AND `type` = '2' LIMIT 1;");
if (mysql_num_rows($req) == 0) {
    require_once ('inc/head.php');
    echo '<div class="error">Статья не найдена</div>';
    require_once ("inc/foot.php");
    exit;
    }
    $res = mysql_fetch_array($req);
	
// Заголовки
$title = 'Скачивание java-книги';	
require_once ('inc/head.php');
#############################

	echo '<div class="title">Скачивание java-книги</div>';
    // Создаем JAR файл
    if (!file_exists('files/' . $id . '.jar')) {
        $midlet_name = mb_substr($res['name'], 0, 10);
        $midlet_name = iconv('UTF-8', 'windows-1251', $midlet_name);

        // Записываем текст статьи
        $files = fopen("java/textfile.txt", 'w+');
        flock($files, LOCK_EX);
        $book_name = iconv('UTF-8', 'windows-1251', $res['name']);
        $book_text = iconv('UTF-8', 'windows-1251', $res['text']);
        $result = "\r\n" . $book_name . "\r\n\r\n----------\r\n\r\n" . notags($book_text) . "\r\n\r\n$home";
        fputs($files, $result);
        flock($files, LOCK_UN);
        fclose($files);

        // Записываем манифест
        $manifest_text = 'Manifest-Version: 1.0
MIDlet-1: Книга ' . $id . ', , br.BookReader
MIDlet-Name: Книга ' . $id .'
MIDlet-Vendor: WBLIB
MIDlet-Version: 1.5.3
MIDletX-No-Command: true
MIDletX-LG-Contents: true
MicroEdition-Configuration: CLDC-1.0
MicroEdition-Profile: MIDP-1.0
TCBR-Platform: Generic version (all phones)';
        $files = fopen("java/META-INF/MANIFEST.MF", 'w+');
        flock($files, LOCK_EX);
        fputs($files, $manifest_text);
        flock($files, LOCK_UN);
        fclose($files);

        // Создаем архив
        require_once ('inc/pclzip.lib.php');
        $archive = new PclZip('files/' . $id . '.jar');
        $list = $archive->create('java', PCLZIP_OPT_REMOVE_PATH, 'java');
        if (!file_exists('files/' . $id . '.jar')) {
            echo '<div class="error">Ошибка создания JAR-файла</вшм>';
            require_once ("inc/foot.php");
            exit;
        }
    }
 // Создаем JAD файл
    if (!file_exists('files/' . $id . '.jad')) {
        $filesize = filesize('files/' . $id . '.jar');
        $jad_text = 'Manifest-Version: 1.0
MIDlet-1: Книга ' . $id . ', , br.BookReader
MIDlet-Name: Книга ' . $id .'
MIDlet-Vendor: WBLIB
MIDlet-Version: 1.5.3
MIDletX-No-Command: true
MIDletX-LG-Contents: true
MicroEdition-Configuration: CLDC-1.0
MicroEdition-Profile: MIDP-1.0
TCBR-Platform: Generic version (all phones)
MIDlet-Jar-Size: ' . $filesize. '
MIDlet-Jar-URL: ' . $home . '/files/' . $id . '.jar';
        $files = fopen('files/' . $id . '.jad', 'w+');
        flock($files, LOCK_EX);
        fputs($files, $jad_text);
        flock($files, LOCK_UN);
        fclose($files);
    }
	if (isset($_POST['go'])) {
	   if (intval($_POST['format']) == 1) {
	   header("Location: files/$id.jar");
	   }
	   else {
	   header("Location: files/$id.jad");
	   }
	}
    echo '<div class="link">';
	echo 'Название: ' . $res['name'] . '<br />';
    echo 'Выбире формат java-книги :<br />';
	echo '<form action="java.php?id='.$id.'" method="POST">
	<select name="format">
	<option value="1">Jar</option>
	<option value="2">Jad</option>
	</select>
	<input type="submit" name="go" value="Скачать"/>
	</form>';
	echo '</div>';
    echo '<div class="bar"><a href="article.php?id=' . $id . '">К статье</a></div>';

require_once ('inc/foot.php');
?>