<?php

define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$lng_faq = core::load_lng('faq');
$lng_smileys = core::load_lng('smileys');
$textl = 'FAQ';
$headmod = 'faq';
require('../incfiles/head.php');

// Обрабатываем ссылку для возврата
if (empty($_SESSION['ref'])) {
    $_SESSION['ref'] = isset($_SERVER['HTTP_REFERER']) ? htmlspecialchars($_SERVER['HTTP_REFERER']) : $home;
}

switch ($act) {
    // forum qoidalari
    case 'forum':
echo '<div class="phdr"><a href="faq.php"><b>Ma\'lumot FAQ</b></a> | Forum qoidalari</div>
<div class="menu"><h3>Mavzu ochish</h3></div>
<div class="menu"><b>1.1 Bir xil o\'xshash mavzu</b><br/>
Bir xil o\'xshash mavzular ochish taqiqlanadi. Agarda shunday mavzu bor bo\'lsa (agar yopilgan bo\'lsa Moderatorlarga murojat qiling) o\'sha mavzuda davom ettiring.</div>
<div class="menu"><b>1.2 Flud mavzu</b><br/>
Bir vaqtning o\'zida podforumlarda bir xil mavzular yaratish taqiqlanadi.</div>
<div class="menu"><b>1.3 Yopilgan mavzularni davom ettirish</b><br/>
Ma\'muriyat tomonidan yopilgan mavzularni davom ettirish taqiqlanadi.</div>
<div class="menu"><b>1.4 Hech qanday ma\'lumotga ega bo\'lmagan mavzu nomlari</b><br/>
Mavzu nomi uni tarkibini (qisman bo\'lsada) aks ettirishi lozim. &quot;Yordam kerak&quot;, &quot;Muammo bor&quot; kabi ko\'rinishdagi mavzular ogohlantirishsiz o\'chiriladi yoki o\'zgartiriladi.</div>
<div class="menu"><b>1.5 Aniq bir foydalanuvchiga murojat</b><br/>
Forumda ma\'lum bir foydalanuvchiga qaratilgan mavzu ochish taqiqlanadi. Bunday vaziyatlarda shaxsiy xabarlardan foydalanishingiz mumkin.</div>
<div class="menu"><b>1.6 Ajratib ko\'rsatilgan mavzular</b><br/>
Mavzularni nomlash faqat katta harflarda (bunga extiyoj bo\'lmasa ham) foydalanish va har xil belgilar bilan bezak berish taqiqlanadi.</div>
<div class="menu"><b>1.7 Tematika</b><br/>
Millatchilik, davlat siyosatiga aralashish, diniy mavzulardagi mavzular qat\'iyan taqiqlanadi.</div>
<div class="menu"><b>1.8 Podforumlar uchun alohida mavzular</b><br/>
Bazi podforumlarda shu bo\'lim uchun mavzu qoidalar mavjud, ular bilan tanishib chiqib amal qilishingiz lozim.</div>

<div class="menu"><h3>Xabar qoldirish</h3></div>
<div class="menu"><b>2.1 Flud</b><br/>
Mavzularda takroriy xabarlar qoldirish taqiqlanadi.</div>
<div class="menu"><b>2.2 Offtop (mavzudan chetlashish)</b><br/>
Belgilangan mavzudan chetlashish, mavzuga aloqador bo\'lmagan xabar qoldirish taqiqlanadi.</div>
<div class="menu"><b>2.3 Fleym</b><br/>
Shaxsiy adovat sababli qo\'pol ohangda (tekkizib) gapirish, masxaralash taqiqlanadi.</div>
<div class="menu"><b>2.4 Reklama</b><br/>
To\'g\'ridan to\'g\'ri ssilka o\'rnatib, ruhsat etilmagan joylarda saytga taklif qilish taqiqlanadi. Shu jumladan referal ssilka qo\'yish ham ta\'qiqlanadi. Reklama uchun alohida bo\'limimiz mavjud.</div>
<div class="menu"><b>2.5 So\'kinish</b><br/>
Senzuraga to\'g\'ri kelmaydigan so\'zlardan foydalanib xabar qoldirish taqiqlanadi.</div>
<div class="menu"><b>2.6 Noto\'g\'ri ma\'lumot</b><br/>
Xabar matni noto\'g\'ri, yolg\'on ma\'lumotlardan iborat bo\'lmasligi shart.</div>
<div class="menu"><b>2.7 Xabarlarni bezatish</b><br/>
Xabar matnini quyidagi yo\'llar bilan bezatish taqiqlanadi: 1) haddan ortiq smayllar 2) jargon so\'zlar 3) grammatik xatolar 4) har-xil rang berish, shriftlarni o\'zgartirish</div>
<div class="menu"><b>2.8 Qoidabuzarlikga undash</b><br/>
O\'zb. Res. qonunlarini yoki forum qoidalarini buzishga undovchi xabarlar qoldirish taqiqlanadi.</div>
<div class="menu"><b>2.9 Targ\'ibot</b><br/>
Zo\'ravonlik, fashizm, terarizm, irqchilik, millatchilik, din va boshqa O\'zb. Res. qonunlarida taqiqlangan holatlarni targ\'ib qilish taqiqlanadi.</div>
<div class="menu"><b>2.10 Buzg\'unchi dasturlar</b><br/>
Buzg\'unchi dasturlar ya\'ni virus, spamer, shell va hokozolarni kabi dasturlarni forumga yuklash yoki yuklash uchun ssilka qo\'yish taqiqlanadi.</div>
<div class="menu"><b>2.11 Mualliflik huquqi</b><br/>
Mualliflik huquqiga ega bo\'lgan maqola, dastur va hakozolarni muallif ruhsatisiz tarqatish, so\'rash taqiqlanadi.</div>
<div class="menu"><b>2.12 Ma\'muriyat ishlarni tahlil qilish</b><br/>
Ma\'muriyat ishlarni ochiqdan ochiq tahlil qilish taqiqlanadi. Savollar, muammolar kelib chiqqan holda shaxsiy xabar orqali ma\'muriyat bilan bog\'lanishingiz mumkin.</div>
<div class="menu"><b>2.13 Qarz so\'rash</b><br/>
Pul vositalari(forum tangasi)ni o\'zingiz yoki biron kim uchun qarzga so\'rash taqiqlanadi.</div>
<div class="menu"><b>2.13 Xizmatlar</b><br/>
Spam, hisoblagichlarni suniy oshirish, buzg\'unchilik xizmatlarini taklif qilish yoki sotish taqiqlanadi.</div>
<div class="menu"><b>2.14 Ruhsatsiz moderatorlik qilish</b><br/>
Ruhsatsiz moderatorlik bilan shug\'ullanish, boshqa foydalanuvchilarga tanbex berish taqiqlanadi. Qoidabuzarlik haqida xabar berish uchun &quot;Arz&quot; ssilkasini bosishingiz kerak.</div>
<div class="menu"><b>2.15 To\'g\'ri yozish</b><br/>
Iltimos, o\'zbek tili grammatikasini buzmagan holda xatosiz yozishga harakat qiling. Bu sizni bilim saviyangizni bildirib turadi.<br/>
Harflarni turli belgilar bilan qisqartirib yozish (ch-4, o\'-6, sh-w) taqiqlanadi. <br/>
Adabiychaga yaqin bo\'lgan shevalarda yozishga qisman ruhsat etiladi.</div>
<div class="menu"><b>2.16 Reytingni oshirish</b><br/>
Har qanday holatda reytingni oshirishni so\'rash taqiqlandi.</div>
<div class="menu"><b>2.17 Qo\'shimcha qoidalar</b><br/>
Ba\'zibir podforumlarda shu podforumga tegishli qo\'shimcha qoidalar mavjud. Xabar qoldirishda shu qoidalarga amal qilinishi shart.</div>
<div class="menu"><b>2.18  Manba ko\'rsatish</b><br/>
Boshqa saytlardan forumga yoki aksincha ma\'lumot ko\'chirganda o\'sha saytning manzili (manba) ko\'rsatilishi shart.<br/>
Masalan:<br/> &quot;Manba: shaddod.uz&quot;<br/>
Manba ko\'rsatishdan oldin, ma\'lumot haqiqatdan ham shu saytga tegishli ekanligini tekshirib ko\'ring. &quot;Qaroqchi&quot; saytlarga qo\'yilgan manba haqiqiy hisoblanmaydi.</div>
<div class="menu"><b>* 5.19 Iqtibos qilish</b><br/>
Sizdan oldin yozilgan xabar (post) ni zarurat bo\'lmasada to\'liqligicha iqtibos qilish ya\'ni katta hajmli postlarni sitata qilish (overquoting) taqiqlanadi.</div>

<div class="menu"><h3>Tavsiyalar</h3></div>
<div class="menu"><b>3.1</b><br/>
Suhbatdoshingizga hurmat bilan munosabatda bo\'ling, fikrlaringizni tushunarli va aniq faktlar yordamida bayon eting.</div>
<div class="menu"><b>3.2</b><br/>
O\'zingizni haqorat qilindi deb hisoblasangiz ham unga haqorat bilan javob qaytarmang. Biroz kuting yoki ma\'muriyat a\'zolariga shaxsiy xabar orqali xabar bering. Qolganini ma\'muriyat a\'zolari hal qilishadi.</div>
<div class="menu"><b>3.3</b><br/>
Agar qoidabuzarlikni ko\'rsangiz, bu haqida forumga jar solishni keragi yo\'q. &quot;Arz&quot; ssilkani bosing va sababini yozib qoldiring, ma\'muriyat a\'zolari ko\'rib chiqib chora ko\'rishadi.</div>
<div class="menu"><b>3.4</b><br/>
Savol berish yoki mavzu ochishdan oldin, forumdan izlab ko\'ring. Balki, sizni qiziqtirayotgan narsa allaqachon bor bo\'lishi mumkin.</div>

<div class="phdr"><b>Qoidabuzarlik atamalari</b></div>
<div class="menu"><h3>Flud yoki oftop nima degani?</h3></div><div class="menu">
<b>Flud</b> (inglizcha "flood" so\'zini noto\'g\'ri talaffuz qilish - "suv to\'lish, "suv bosish") - kerak bo\'lmagan ma\'lumotni bir necha bora qaytarilishi, bir hil ma\'lumotlarni joylash, qaytariladigon frazalar, belgilar, harflar, bir hil grafik fayllar yoki forum, chat, bloglardagi oddiygina qisqa ma\'nosiz xabarlar. Internet-slengda "Flud" tarqatuvchi odam "Fluder" deyiladi. Forumlarda dablpost(doublepost) yoki overpost, 2ta yoki ko\'proq xabarlar ketma ketligini bildiradi.<br/>
<b>Offtop</b> (inglizcha off topic) - avvaldan belgilangan mavzudan chiquvchi tarmoqdagi xar qanday xabar offtopic (qisqa varianti offtop) deyiladi. Masalan: Forumning umumiy yo\'nalishi yoki forum mavzusining yo\'nalishiga mos kelmagan xabarlar.</div>
<div class="menu"><h3>Fleym va spam nima?</h3></div><div class="menu">
<b>Fleym</b> ( inglizcha flame - o\'t, olov, alanga) - internet forum va chatlarda so\'z bilan urushib muloqot qilish jarayoni. Fleym xabarlari shaxsiy kamsitish, janjalni davom ettirishga qaratiladi. Ba\'zida trolling konteksida ishlatiladi, lekin ko\'proq fleym biror kishini boshqa kishidan hafa bo\'lganida yuzaga keladi.<br/>
<b>Spam</b> (inglizcha spam) qa\'bul qilishni xohlamagan shaxslarga xar xil turdagi reklamalarni keng qamrovda tarqatish. Ba\'zi turdagi davlat qonunchiligida ruhsat etilgan ba\'zi ma\'lumotlarni keng qamrovda tarqatish xollarixam kuzatilishi mumkun, lekin bu qonunni buzishga kirmaydi. Masalan ob-xavo ma\'lumotlarini operatorlar tomonidan abonentlarga yuborish. ICQ, Mail Agent, QIP va shu turdagi serverlardagi spam SPIM (ingl. Spam over IM) nomi bilan ataladi.</div>
<div class="menu"><h3>Overkvoting, trolling, xolivar nima?</h3></div><div class="menu">
<b>Overkvoting</b> (inglizcha overquoting) forumdagi xabarlarni katta hajmdagi sitata qilish. Bu ko\'pincha noqulaylik keltirib chiqaradi.<br/>
<b>Trolling</b> (inglizcha trolling) - internetda (forumlarda, Usenet yangilik guruhlarida, wiki-proyektlarda va h.k) provokatsiyali xabarlarni fleym, kelishmovchilik, haqorat va boshqa maqsadlarda ma\'lumot joylash. "Trolling" bilan shug\'ullanuvchi odam "Troll" deb ataladi, bu mifologik jonzot bilan nomdosh.<br/>
<b>Xolivar</b> (inglizcha holy war) - internet-forum va chatlarda foydalanuvchilarning o\'zlarini nuqtai nazarini singdirish maqsadidagi ma\'nosiz disskusiyasi(munozarasi). Masalan bir biriga bir necha alternativ narsalarni(kompyuter dasturlari, texnologiyalar, aktyorlar, musiqiy guruhlar va h.k) qay biri ustunligini ko\'rsatib berish.</div>

<div class="rmenu"><b>DIQQAT !!!</b><br/>
Agar foydalanuvchi qoidalarga qarshilik qilsa, uning akkounti ma\'lum muddatga bloklanadi yoki umuman o\'chirib tashlanadi.</div>';
    break;
		
// bb-kodlar
    case 'tags':
 echo '<div class="phdr"><a href="faq.php"><b>Ma\'lumot FAQ</b></a> | BB-kodlar</div>
 <div class="menu"><h3>BB-kodlardan foydalanish:</h3></div>
 <div class="menu"><p><table cellpadding="3" cellspacing="0">
 <tr><td align="right">[php]...[/php]</td><td>PHP kod</td></tr>
 <tr><td align="right">[url=http://]...[/url]</td><td><a>URL ssilka</a></td></tr>
 <tr><td align="right">[b]...[/b]</td><td><b>Yog\'liq</b></td></tr>
 <tr><td align="right">[i]...[/i]</td><td><i>Egilgan</i></td></tr>
 <tr><td align="right">[u]...[/u]</td><td><u>Tagi chiziqli</u></td></tr>
 <tr><td align="right">[s]...[/s]</td><td><strike>Usti chiziqli</strike></td></tr>
 <tr><td align="right">[red]...[/red]</td><td><span style="color:red">Qizil</span></td></tr>
 <tr><td align="right">[green]...[/green]</td><td><span style="color:green">Yashil</span></td></tr>
 <tr><td align="right">[blue]...[/blue]</td><td><span style="color:blue">Ko\'k</span></td></tr>
 <tr><td align="right">[color=]...[/color]</td><td>Rangli xabar</td></tr>
 <tr><td align="right">[bg=][/bg]</td><td>Fonli xabar</td></tr>
 <tr><td align="right">[c]...[/c]</td><td><span class="quote">Sitata</span></td></tr>
 <tr><td align="right">[*]...[/*]</td><td><span class="bblist">Markerli ro\'yhat</span></td></tr>
 <tr><td align="right">[spoiler=]...[/spoiler]</td><td>Spoiler</td></tr>
<tr><td align="right">[img]http://rasm-manzili[/img]</td><td>Xabarga rasm yuklash</td></tr>
 </table></p></div>';
        break;
	
	// translitlash
    case 'trans':
 echo '<div class="phdr"><a href="faq.php"><b>Ma\'lumot FAQ</b></a> | Translitlash</div>
 <div class="menu"><h3>Translitlash jadvali:</h3></div>
 <div class="menu">А - A<br/>Б - B<br/>В - V<br/>Г - G<br/>Д - D<br/>Е - E<br/>Ё - YO<br/>Ж - ZH<br/>З - Z<br/>И - I<br/>Й - J<br/>К - K<br/>Л - L<br/>М - M<br/>Н - N<br/>О - O<br/>П - P<br/>Р - R<br/>С - S<br/>Т - T<br/>У - U<br/>Ф - F<br/>Х - H<br/>Ц - C<br/>Ч - CH<br/>Ш - W<br/>Щ - SH<br/>Ъ - Q<br/>Ы - Y<br/>Э - X<br/>Ю - YU<br/>Я - YA</div>
 <div class="menu">а - a<br/>б - b<br/>в - v<br/>г - g<br/>д - d<br/>е - e<br/>ё - yo<br/>ж - zh<br/>з - z<br/>и - i<br/>й - j<br/>к - k<br/>л - l<br/>м - m<br/>н - n<br/>о - o<br/>п - p<br/>р - r<br/>с - s<br/>т - t<br/>у - u<br/>ф - f<br/>х - h<br/>ц - c<br/>ч - ch<br/>ш - w<br/>щ - sh<br/>ъ - q<br/>ы - y<br/>э - x<br/>ю - yu<br/>я - ya</div>';
    break;

// smayllar
    case 'smileys':
        echo '<div class="phdr"><a href="faq.php"><b>Ma\'lumot FAQ</b></a> | Smayllar</div>';
        $dir = glob(ROOTPATH . 'images/smileys/*', GLOB_ONLYDIR);
        foreach ($dir as $val) {
            $cat = explode('/', $val);
            $cat = array_pop($cat);
            if (array_key_exists($cat, $lng_smileys)) {
                $smileys_cat[$cat] = $lng_smileys[$cat];
            } else {
                $smileys_cat[$cat] = ucfirst($cat);
            }
        }
        asort($smileys_cat);
        foreach ($smileys_cat as $key => $val) {
            echo '<div class="menu">&raquo; <a href="faq.php?act=smusr&amp;cat=' . urlencode($key) . '">' . htmlspecialchars($val) . '</a>' .
                ' <span class="count">' . count(glob(ROOTPATH . 'images/smileys/' . $key . '/*.{gif,jpg,png}', GLOB_BRACE)) . '</span></div>';
        }
        echo '<div class="phdr"><a href="' . $_SESSION['ref'] . '">' . $lng['back'] . '</a></div>';
        break;

    case 'smusr':
        /*
        -----------------------------------------------------------------
        Каталог пользовательских Смайлов
        -----------------------------------------------------------------
        */
        $dir = glob(ROOTPATH . 'images/smileys/*', GLOB_ONLYDIR);
        foreach ($dir as $val) {
            $val = explode('/', $val);
            $cat_list[] = array_pop($val);
        }
        $cat = isset($_GET['cat']) && in_array(trim($_GET['cat']), $cat_list) ? trim($_GET['cat']) : $cat_list[0];
        $smileys = glob(ROOTPATH . 'images/smileys/' . $cat . '/*.{gif,jpg,png}', GLOB_BRACE);
        $total = count($smileys);
        $end = $start + $kmess;
        if ($end > $total) $end = $total;
        echo '<div class="phdr"><a href="faq.php?act=smileys"><b>' . $lng['smileys'] . '</b></a> | ' .
            (array_key_exists($cat, $lng_smileys) ? $lng_smileys[$cat] : ucfirst(htmlspecialchars($cat))) .
            '</div>';
        if ($total) {
            for ($i = $start; $i < $end; $i++) {
                $smile = preg_replace('#^(.*?).(gif|jpg|png)$#isU', '$1', basename($smileys[$i], 1));
                echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
                echo '<img src="../images/smileys/' . $cat . '/' . basename($smileys[$i]) . '" alt="" />&#160;:' . $smile . ': ' . $lng['lng_or'] . ' :' . functions::trans($smile) . ':</div>';
            }
        } else {
            echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
        }
        echo '<div class="phdr">' . $lng['total'] . ': ' . $total . '</div>';
        if ($total > $kmess) {
            echo '<div class="topmenu">' . functions::display_pagination('faq.php?act=smusr&amp;cat=' . urlencode($cat) . '&amp;', $start, $total, $kmess) . '</div>';
        }
        break;

	// bosh sahifasi
    default:
echo '<div class="phdr"><b>Sayt haqida ma\'lumot</b></div>
<div class="menu"><b>Bu qanday sayt?</b><br/>
- Bu sayt  </div>
<div class="menu"><b>Ushbu sayt nimani ko\'zlaydi?</b><br/>
- Sayt tematikasi bizning korxonada mavjud barcha xizmatlarni taklif etishdan va iborat.</div>
<div class="menu"><b>Sayt boshqaruvchilari kimlar?</b><br/>
- Sayt boshqaruvchilari korxonada faoliyat yurituvchi kishilar va ma\'muriyat a\'zolari hisoblanishadi. Mamuriyat a\'zolariga administratorlar va moderatorlar kirishadi.</div>
<div class="menu"><b>Saytda qaysi tilda yozish mumkun?</b><br/>
- Saytda umumiy til o\'zbek tilidir. Faqat noilojiy vaziyatlardagina boshqa tildan foydalanishga vaqtincha ruhsat etiladi. Xabarlaringizni iloji boricha lotin alifbosi harflarida va bexato yozing. So\'z va harflarni qisqartirib yozish (bilan = b.n, uchun = u.n, sh = w, ch = 4 va h.k) mumkun emas.</div>';
	
echo '<div class="phdr"><b>Kirish va ro\'yxatdan o\'tish</b></div>
<div class="menu"><b>Men nega kira olmayapman?</b><br/>- Siz ro\'yxatdan o\'tdingizmi? Kirish uchun avval ro\'yxatdan o\'tishingiz lozim. Siz saytga kirishdan man qilindingizmi? (Ushbu holda bu haqida xabar chiqadi.) Unday bo\'lsa, sababini aniqlash uchun sayt administratori bilan bog\'lanishingiz kerak. Agar siz ro\'yxatdan o\'tgan bo\'lsangiz va kirishdan ta\'qiqlanmagan bo\'lsangiz ham kira olmayotgan bo\'lsangiz foydalanuvchi nomi (login) va parolingizni qayta tekshiring. Ko\'p hollarda muammo ana shunda bo\'ladi. Sunda ham kirish amalga oshmasa, sayt administratori bilan bog\'laning.</div>
<div class="menu"><b>Men o\'zi nega ro\'yxatdan o\'tishim kerak?</b><br/>- Siz ro\'yxatdan o\'tishingiz shart emas. Lekin saytdan to\'liq foydalanishingiz uchun ro\'yxatdan o\'tishingiz shart. Nima bo\'lganda ham, ro\'yxatdan o\'tish sizga mehmon foydalanuvchilarda bo\'lmagan qo\'shimcha imkoniyatlar beradi. Masalan: forum va suhbatxonalarda xabar qoldirish, yuklama va maqolalarga fikr bildirish va hokazo. Ro\'yxatdan o\'tish faqatgina bir necha daqiqalarni oladi. Shuning uchun sizga ro\'yxatdan o\'tish tavsiya qilinadi.</div>
<div class="menu"><b>Men parolimni esimdan chiqarib qo\'ydim!</b><br/>- Havotir olmang, parolingiz qayta tiklanmasada, uni boshqa parolga o\'zgartirish mumkin. Agar anketangizga o\'zingizning xaqiqiy e-mailingizni kiritgan bo\'lsangiz. Buning uchun "Kirish" sahifasiga borib "Parolni unutdingizmi?" degan joyni bosasiz. Ko\'rsatmalarga rioya qiling va tez orada saytga kira olasiz.</div>
<div class="menu"><b>Men ro\'yxatdan o\'tdim ammo kira olmayapman!</b><br/>- Avvalo to\'g\'ri nom va parol kiritayotganingizni tekshiring.  Agar sabab bu bo\'lmasa sizni nomingiz aktivizatsiya qilishni talab etadi. Ba\'zi forumlar barcha yangi ro\'yxatdan o\'tganlarni kirish uchun yo o\'zlari yoki forum administratori tomonidan aktivizatsiya qilinishini talab qiladi. Ro\'yxatdan o\'tganingizdan so\'ng sizga aktivizatsiya qilish zarurligi haqida xabar beriladi. Agar sizga e-mail jo\'natilgan bo\'lsa undagi ko\'rsatmalarga rioya qiling; agar e-mail olmagan bo\'lsangiz ro\'yxatdan o\'tishda e-mail adresingizni to\'g\'ri kiritganligingizni tekshiring. Aktivizatsiyani talab qilishning bir sababi - forumni anonim ravishda suiste\'mol qilinishini oldini olishdir. Agar to\'g\'ri adres berganingizga amin bo\'lsangiz forum administratori bilan bog\'laning.</div>
<div class="menu"><b>Men avval ro\'yxatdan o\'tgan edim ammo endi kira olmayapman!</b><br/>- Ko\'p ehtimolki buning sabablari yo siz noto\'g\'ri nom va parol kiritgansiz (ro\'yxatdan o\'tgan vaqtingizda sizga yuborilgan xatni tekshiring), yoki administrator sizni nomingizni ayrim sabablarga ko\'ra o\'chirib yuborgan yoki o\'zgartirgan. Agar ikkinchisi to\'g\'ri bo\'lsa, balki siz hech qanday xabar qoldirmagansiz yoki qoidalarni buzganisiz bo\'lsangiz kerak. Administratorlar vaqti vaqti bilan ma\'lumotlar bazasi hajmini kamaytirish maqsadida nofaol foydalanuvchilarni o\'chirib turishadi. Administratorlar bilan bog\'laning.</div>
<div class="menu"><b>Ro\'yhatdan o\'tish qoidalari mavjudmi?</b><br/>
- Saytdan ro\'yhatdan o\'tishingiz sayt qoidalarga roziligingizni anglatadi.<br/>
- Har bir foydalanuvchi faqat bitta akkount ochishi mumkin. Boshqa akkountlar ogohlantirishsiz o\'chiriladi.<br/>
- Boshqa foydalanuvchilarni nikini nusxalashtirish (klonlashtirish) ta\'qiqlanadi.<br/>
- Tahallus (nik) tarkibida haqoratli so\'zlar, sayt nomlarini ishlatish, maxsus belgilardan foydalanish va har hil g\'alati tahalluslar (Jinni, AAAAA, 77777 va h.k) ta\'qiqlanadi.<br/>
- Tahallusda klub va futbolchilarni xaqoratlovchi so\'zlardan foydalanish qattiyan ta\'qiqlanadi!<br/>
- Akkountni birovga berish yoki sotish ta\'qiqlanadi.</div>';

echo '<div class="phdr"><b>Qisqacha ma\'lumotlar</b></div>
<div class="menu"><b>Sayt a\'zolarining biridan spam yoki haqoratlovchi xat oldim</b><br/>- Shunday holat yuz bersa, siz administratorga olgan xatingizni to\'liq nusxasi bilan birga xat yuborishingiz kerak. Bunda har bir qismini kiritishingiz juda muhimdir. (Ularda xat yuborgan odam haqida ma\'lumot bo\'ladi.) Shunda administrator tegishli choralar ko\'rishi mumkin.</div>
<div class="menu"><b>BB-kodlar nima?</b><br/>- BB-kodlar bu HTMLning maxsus qo\'llanilishidir! BB-kodni o\'zi HTMLga o\'xshashdir. Teglar &lt; va &gt; da emas. Balki, to\'rtburchak qavslar [ va ] ichiga olinadi. U foydalanuvchilarga biror bir narsaning qanday ko\'rinishini tuzish borasida katta imkoniyatlar beradi. BB-kodlardan foydalanishni <a href="?act=tags">mana bu sahifada</a> o\'rganishingiz mumkun.</div>
<div class="menu"><b>Smayliklar nima?</b><br/>- Smayllar hissiyotlarni aks ettirish uchun ishlatiladigan kichik suratlardir. Masalan. <b>:)</b> hursandchilik, <b>:(</b> hafalikni bildiradi. Smayliklarni keragidan ortiqcha ishlatib yubormang. Xabaringizni o\'qishda noqulayliklar tug\'diradi va moderator xabaringizni qayta taxrir qilishi yoki umuman o\'chirib yuborishi mumkin. Smayllardan foydalanishni <a href="?act=smileys">mana bu sahifada</a> o\'rganishingiz mumkun.</div>
<div class="menu"><b>Translitlash nima?</b><br/>- Translitlash o\'girish ma\'nosi anglatib, lotin alifbosi belgilarni kril alifbosiga yoki aksini bajarishda qo\'llaniladi. Translitlash qoidalarini <a href="?act=trans">manabu sahifa</a> orqali ko\'rib olishingiz mumkun.</div>
<div class="menu"><b>Forum mavzularning turlari bormi?</b><br/>- Fotum mavzulari uchta E\'lon, Top va Yopiq mavzularga bo\'linadi. E\'lon mavzular - odatda o\'z ichiga muxim xabarni oladi va siz ularni iloji boricha tez o\'qishingiz kerak. E\'lonlar har doim forumning har bir sahifasini yuqori qismida joylashgan bo\'ladi. E\'lon mavzu ochish faqat administrator va moderatorlarga ruhsat etilgan. Top mavzular - forumni ko\'rish sahifasida e\'londan pastroqda va faqat birinchi sahifada joylashgan bo\'ladi. Odatda ular ham qandaydir muhim xabarni o\'z ichiga oladi. E\'lon mavzu singari top-mavzularni ochish faqat administrator va moderatorlarga ruhsat etilgan. Yopiq mavzular - faqat mavzu muallifi, moderator yoki administrator tomonidan yopilishi mumkin. Siz yopiq mavzularga javob yoza olmaysiz va uning ichidagi har qanday so\'rovnomalar avtomatik ravishda tugatiladi. Mavzular ko\'p sabablarga ko\'ra yopilishi mumkin.</div>';

echo '<div class="phdr"><b>Qoidalar</b></div>
<div class="menu"><b>Ban nima?</b><br/>- Ban - bu sayt qoidalarini buzganlikingiz uchun belgilangan muddatga sizning saytdan foydalanish huquqini olib qo\'yilishidir. Qoidalarni bilmaslik sizni jazodan ozod qilmaydi. Aksincha bu ham qoida buzarlik hisoblanadi.</div>
<div class="menu"><b>Qanday ish qilganlar Ban oladi?</b><br/>- Saytda keltirilgan qonun-qoidalarni buzganlar va qoidalarga qarshilik ko\'rsatganlar.</div>
<div class="menu"><b>Ban muddati uzaytirilishi mumkunmi?</b><br/>- Foydalanuvchi ban olgan paytda boshqa akkount ochib saytdan foydalansa ban muddati uzaytiriladi va boshqa akkountlari o\'chiriladi.</div>
<div class="menu"><b>Noxaq banlansam nima qilaman?</b><br/>- Qaysi moderatorni noxaq deb hisoblasangiz, bu haqida batafsil Administratorga shaxsiy xabar orqali arz qilishingiz mumkin.</div>
<div class="menu"><b>Forum qoidalari mavjudmi?</b><br/>- Ha, albatta. Forumning qoidalari haqida <a href="?act=forum">mana bu sahifa</a> orqali to\'liq ma\'lumotga ega bo\'lasiz.</div>
<div class="menu"><b>Statusda nimalar ta\'qiqlanadi?</b><br/>- Foydalanuvchi statusida nostandart belgilardan foydalanish, reklama, so\'kinish va shuning dek saytning boshqa qoidalarida ta\'qiqlangan holatlar bo\'lishi man etiladi.</div>
<div class="menu"><b>Ushbu saytda nimalar ta\'qiqlanadi?</b><br/>
- O\'zbekiston Respublikasi hamda Rossiya federatsiyasi qonunchiligini buzulishi;<br/>
- Madaniyat doirasida so\'zlashmaslik (Haqorat,So\'kinish,G\'iybat,Tuhmat...);<br/>
- Mahsulot yoki sayt nomini reklama qilish;<br />
- Boshqa foydalanuvchilarga nisbtadan agressiv holatda bo\'lish, asabga tegish, bezbetlik;<br/>
- Pornografik ma\'lumotlarni tarqatish, kiritish, yuklash;<br/>
- Ko\'p profillardan foydalanish;<br/>
- Saytdan yomon maqsadlarda xususan hackerlik yo\'lida foydalanish;<br/>
- Diniy  yoki targ\'ib yo\'lida ma\'lumot yuklash, kiritish, tarqatish;<br/>
- Adminstratsiya ishini muhokama qilish;</div>';

 echo'<div class="phdr"><b>Javobgarlik</b></div>
<div class="menu"><b>Saytda tartib-qoidalar uchun kimlar javobgar?</b><br/>- Saytda tartib-qoidalar uchun Administrator va maxsus tayinlangan Moderatorlar javob beradi. Ular qoidalarga to\'g\'ri kelmaydigan har qanday fayl, maqola va xabarlarni ogohlantirishsiz o\'chirish va tahrirlash huquqiga egadir. Administrator qoidalarga o\'zgartirish kiritish va yangilarini qo\'shish huquqiga ega. Qoidalarda keltirilmagan boshqa vaziyatlar bo\'yicha masalalarni Administrator hal qiladi.</div>
<div class="menu"><b>Administratorlar kimlar?</b><br/>- Adminisratorlar sayt ustidan yuqori darajada boshqaruv imkoniyatiga ega foydalanuvchilardir. Ular sayt operatsiyalarining barcha taraflari ustidan nazorat olib bora oladilar. Ular shuning dek saytda to\'liq moderatorlik huquqiga egadirlar.</div>
<div class="menu"><b>Moderatorlar kimlar?</b><br/>- Moderatorlar sayt faoliyatini har kuni nazorat qilib turuvchi foydalanuvchilar (yoki foydalanuvchi guruhlari)dir. Ular o\'zlari javobgar bo\'lgan bo\'limlarni rivojlantirish va foydalanuvchilarni bo\'im qoidalariga rioya qilishiga masuldirlar. Umuman olganda, moderatorlarning asosiy vazifasi, foydalanuvchilarning sayt qoidalari bo\'yicha nazorat qilishdan iborat.</div>
<div class="menu"><b>Adminstratsiya qanday holatda javobgar hisoblanadi?</b><br/>- Foydalanuvchilarning shahsiy ma\'lumotlari o\'chib ketganda, sayt ishlamay qolganda, saytda xatolik yuz berganda administratorlar javobgar hisoblanishadi.</div>
<div class="menu"><b>Men ham javobgarmanmi?</b><br/>- Albatta. Siz o\'zingiz yozgan yoki kiritgan har qanday ma\'lumot yoki faylga javobgar hisoblanasiz. Nomaqbul ma\'lumot yoki fayl uchun sizga qonun doirasida chora ko\'riladi.</div>
<div class="menu"><b>Adminstratsiya qanday holatda javobgar emas?</b><br/>- Foydalanuvchining shahsiy ma\'lumoti yoki fayli tarqalib ketgan holatda. Foydalanuvchilar tomonidan kiritilgan har qanday fayl yoki ma\'lumotning hech biriga administratorlar javobgar hisoblanishmaydi. Ushbu holatda javobgarlik to\'laqonli foydalanuvchi zimmasida turadi.</div>';		

echo '<div class="rmenu"><b>DIQQAT !!!</b><br/>Sayt qonun-qoidalarini buzgan foydalanuvchiga sayt doirasida yoki O\'zbekiston Respublikasi qonunchiligi doirasida chora ko\'riladi!</div>';
}

require('../incfiles/end.php');