﻿<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();

/*
-----------------------------------------------------------------
Блок информации
-----------------------------------------------------------------
*/
echo '<div class="phdr"><b>' . $lng['information'] . '</b></div>';
echo $mp->news;
echo '<div class="menu"><a href="news/index.php">' . $lng['news_archive'] . '</a> (' . $mp->newscount . ')</div>' .
    '<div class="menu"><a href="pages/faq.php">Qoidalar</a></div>';

/*
-----------------------------------------------------------------
Блок общения
-----------------------------------------------------------------
*/
echo '<div class="phdr"><b>Bizning xizmatlar</b></div>';
 
echo '<div class="menu"><a href="taxi">BIZNESS TAXI</a></div>';
echo '<div class="menu"><a href="sovun">Xo\'jalik mahsulotlari</a></div>';
echo '<div class="menu"><a href="sayt">Dastur tuzish</a></div>';
echo '<div class="menu"><a href="pay">Pul o\'tkazmalari</a></div>';






echo '<div class="phdr"><b>Muloqot</b></div>';
// Ссылка на гостевую
if ($set['mod_guest'] || $rights >= 7)
    echo '<div class="menu"><a href="guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')</div>';
// Ссылка на Форум
if ($set['mod_forum'] || $rights >= 7)
    echo '<div class="menu"><a href="forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')</div>';
//forum boshqaruvi
include('forum/newtem.php');

// Sayt aktivlari
if ($user_id || $set['active']) {
    echo '<div class="phdr"><b>' . $lng['community'] . '</b></div>' .
        '<div class="menu"><a href="users/index.php">' . $lng['users'] . '</a> (' . counters::users() . ')</div>';
}
//choyxor boshqaruvi
include('choyxor/faollar.php');
//yuklamalar
include('download/newtem.php');
/*
-----------------------------------------------------------------
Блок полезного
-----------------------------------------------------------------
*/    
?>
