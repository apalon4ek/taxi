<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'delgift';
$textl = $lng_gifts['delgift'];
require('../incfiles/head.php');
$res = mysql_fetch_assoc(mysql_query("SELECT * FROM `users_gifts` WHERE `id` = '$id'"));
if(empty($res['id']))
    echo functions::display_error($lng_gifts['not_gift']);
else {
    if( $rights < 7 AND ($res['user_id'] != $user_id))
        echo functions::display_error($lng_gifts['access_denine']);
    else {
        if(isset($_POST['submit'])) {
            mysql_query("DELETE FROM `users_gifts` WHERE `id` = '$id' LIMIT 1");
            header("Location: index.php?act=showall&user=$res[user_id]");
        } else {
            echo '<div class="gmenu"><form action="?act=delmygift&amp;id='.$id.'" method="post">'.
        '<div class="rmenu">' . $lng_gifts['delete'] . '?</div>
        <table cellspacing="0" callpadding="0" width="100%">
        <tr>
        <td width="50%">' .
		'
		<input type="submit" name="submit" value="' . $lng_gifts['delgift'] . '" /></td><td align="right">';
        //Название директории с изображениями
                    $dir='gifts';
                    //Задаем параметры ресайза, в нашем случае - ширина и высота
                    $imageWidth='128';
                    $imageHeight='128';
                    $rgsdimg = $home .'/image.php?image=/images/'.$dir.'/'. $res['image'] .'&amp;width='. $imageWidth .'&amp;height='. $imageHeight.'&amp;cropratio=1:1';
                    $photo='<img  src="'. $rgsdimg .'" title="'.$res['image'].'"  />';
                    echo $photo;
                    echo '</td></tr></table>';
		echo '</form></div>';
        }
    }
}