<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'delgift';
$textl = $lng_gifts['delgift'];
require('../incfiles/head.php');


if($rights >= 7)
{
    $gift = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` WHERE `id` = '$id'"));
    $parent = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` WHERE `id` = '$gift[cat]'"));
    if($id) {
    echo '<div class="bmenu">
            <a href="index.php'.($parent ? '?id='.$parent['id'] : NULL).'">
                <table cellspacing="0" callpadding="0" width="100%">
                    <tr>
                        <td width="36px">
                            <img src="' . $home . '/images/folder_up.png" alt="Folder" align="middle" />
                        </td>
                        <td align="left">
                            ' . ($parent ? $parent['name'] : $lng_gifts['cats']) . '
                        </td>
                    </tr>
                </table>
            </a>
        </div>';
    }
    if(isset($_POST['submit'])) {
        unlink($rootpath . 'images/gifts/' . $gift['image']);
        mysql_query("DELETE FROM `gifts` WHERE `id` = '$id'");
        header("Location: index.php" . ($parent ? '?id='.$parent['id'] : NULL));
    } else {
        echo '<div class="gmenu"><form action="?act=delgift&amp;id='.$id.'" method="post">'.
        '<div class="rmenu">' . $lng_gifts['delgift'] . '?</div>
        <table cellspacing="0" callpadding="0" width="100%">
        <tr>
        <td width="50%">' .
		'
		<input type="submit" name="submit" value="' . $lng_gifts['delgift'] . '" /></td><td align="right">';
        //Название директории с изображениями
                    $dir='gifts';
                    //Задаем параметры ресайза, в нашем случае - ширина и высота
                    $imageWidth='128';
                    $imageHeight='128';
                    $rgsdimg = $home .'/image.php?image=/images/'.$dir.'/'. $gift['image'] .'&amp;width='. $imageWidth .'&amp;height='. $imageHeight.'&amp;cropratio=1:1';
                    $photo='<img  src="'. $rgsdimg .'" title="'.$gift['image'].'"  />';
                    echo $photo;
                    echo '</td></tr></table>';
		echo '</form></div>';
    }
    
} else
    header("location: index.php");