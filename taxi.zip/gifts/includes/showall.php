<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'showall';
$textl = $lng_gifts['showall'];
require('../incfiles/head.php');
/*
-----------------------------------------------------------------
Определяем получателя
-----------------------------------------------------------------
*/
if($user) {
    $ank = functions::get_user($user);
    if(!$ank)
        $ank = $datauser;
} else
    $ank = $datauser;
echo '<div class="phdr"><b>' . $lng_gifts['gifts'] . ' ' . $ank['name'] . '</b></div>';
$total_gifts = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_gifts` WHERE `user_id`='{$ank['id']}'"), 0);
if($total_gifts > 0) {
    if ($total_gifts > $kmess) {
        echo '<div class="topmenu">' . functions::display_pagination('index.php?act=showall' . ($ank['id'] != $user_id ? '&amp;user=' . $ank['id'] : NULL) . '&amp;', $start, $total_gifts, $kmess) . '</div>';
    }
    $req = mysql_query("SELECT * FROM `users_gifts` WHERE `user_id` = '$ank[id]' ORDER BY `id` DESC LIMIT $start, $kmess");
    for ($i = 0; $res = mysql_fetch_assoc($req); ++$i) {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        //Название директории с изображениями
        $dir='gifts';
        //Задаем параметры ресайза, в нашем случае - ширина и высота
        $imageWidth='128';
        $imageHeight='128';
        $rgsdimg = $home .'/image.php?image=/images/'.$dir.'/'. $res['image'] .'&amp;width='. $imageWidth .'&amp;height='. $imageHeight.'&amp;cropratio=1:1';
        $photo='<img  src="'. $rgsdimg .'" title="'.$res['image'].'" alt="' . $res['name'] . '"  />';
        echo '
        <table cellspacing="0" callpadding="0" width="100%">
            <tr>
                <td width="130px">
                ' . $photo . '
                </td>
                <td align="left">';
                    if($res['type'] == 1) {
                        if($res['user_id'] == $user_id || $rights >= 7) {
                            $whom = functions::get_user($res['from_id']);
                            echo $lng_gifts['from'] . ' <a href="/users/profile.php' . ($whom['id'] == $user_id ? NULL : '?user=' . $whom['id']) . '">' . $whom['name'] . '</a><br />' .
                            $lng_gifts['gift'] . ':&nbsp;<strong>' . (!empty($res['text']) ? functions::checkout($res['text'],0,0) : $res['name']) . '</strong> <span class="red">' . $lng_gifts['privat'] . '</span><br />' .
                            $lng_gifts['send_ok'] . '&nbsp;' . functions::display_date($res['time']);
                        } else {
                            echo $lng_gifts['privat'] . '<br />' .
                            $lng_gifts['send_ok'] . '&nbsp;' . functions::display_date($res['time']);
                        }
                    } else {
                        $whom = functions::get_user($res['from_id']);
                        echo $lng_gifts['from'] . ' <a href="/users/profile.php' . ($whom['id'] == $user_id ? NULL : '?user=' . $whom['id']) . '">' . $whom['name'] . '</a><br />' .
                        $lng_gifts['gift'] . ':&nbsp;<strong>' . (!empty($res['text']) ? functions::checkout($res['text'],0,0) : $res['name']) . '</strong><br />' .
                        $lng_gifts['send_ok'] . '&nbsp;' . functions::display_date($res['time']);
                    }
                echo '</td>
            </tr>
            <tr>
                <td colspan="2">' .
                ( ($res['user_id'] == $user_id || $rights >= 7) ? '<div class="rmenu"><a href="index.php?act=delmygift&amp;id=' . $res['id'] . '">' . $lng_gifts['delgift'] . '</a></div>' : NULL) .       
                '</td>
            </tr>
        </table>';
        echo '</div>';
    }
    echo '<div class="phdr">' . $lng['total'] . ': ' . $total_gifts . '</div>';
            if ($total_gifts > $kmess) {
                echo '<div class="topmenu">' . functions::display_pagination('index.php?act=showall' . ($ank['id'] != $user_id ? '&amp;user=' . $ank['id'] : NULL) . '&amp;', $start, $total_gifts, $kmess) . '</div>' .
                    '<p><form action="index.php?act=showall' . ($ank['id'] != $user_id ? '&amp;user=' . $ank['id'] : NULL) . '" method="get"><input type="text" name="page" size="2"/>' .
                    '<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
            }
} else
    echo functions::display_error($lng_gifts['empty_cat']);

echo '<div class="phdr"><a href="' . $home . '/users/profile.php?user=' . $ank['id'] . '">' . $lng['back'] . '</a></div>';