<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'addcat';
$textl = $lng_gifts['send'];
require('../incfiles/head.php');


if($id && mysql_result(mysql_query("SELECT COUNT(*) FROM `gifts` where `id` = '$id'"),0) < 1)
    header("Location: index.php");

/*
-----------------------------------------------------------------
Определяем получателя
-----------------------------------------------------------------
*/
if($user) {
    $ank = functions::get_user($user);
    if(!$ank)
        $ank = $datauser;
} else
    $ank = $datauser;
echo '<div class="phdr"><b>' . $lng_gifts['gift'] . ' ' . $lng_gifts['for'] . ' ' . $ank['name'] . '</b></div>';
    
/*
-----------------------------------------------------------------
Выводим верхнее меню
-----------------------------------------------------------------
*/
$gift = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` WHERE `id` = '$id'"));
$parent = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` WHERE `id` = '$gift[cat]'"));
if($id) {
    echo '<div class="bmenu">
            <a href="index.php'.($parent ? '?id='.$parent['id'].($ank['id'] != $user_id ? '&amp;user=' . $ank['id'] : NULL) : ($ank['id'] != $user_id ? '?user=' . $ank['id'] : NULL)).'">
                <table cellspacing="0" callpadding="0" width="100%">
                    <tr>
                        <td width="36px">
                            <img src="' . $home . '/images/folder_up.png" alt="Folder" align="middle" />
                        </td>
                        <td align="left">
                            ' . ($parent ? $parent['name'] : $lng_gifts['cats']) . '
                        </td>
                    </tr>
                </table>
            </a>
        </div>';
}
if($gift && !empty($gift['cost'])) {
    if(isset($_POST['submit'])) {
        // Принимаем и фильтруем данные
        $type = isset($_POST['type']) ? intval($_POST['type']) : 0;
        $text = !empty($_POST['text']) ? mysql_real_escape_string(substr($_POST['text'],0,56)) : null;
        if($_POST['type'] == 1)
			$cost = $gift['pcost'];
		else
			$cost = $gift['cost'];
        $newbalans = ($datauser['balans'] - $cost);
        if($newbalans > 0) {
            mysql_query("INSERT INTO  `users_gifts` (
												`id` ,
												`name` ,
												`user_id`,
												`text` ,
												`time` ,
												`image`,
												`from_id`,
												`type`
												)
											VALUES (
												NULL ,
                                                '".$gift['name']."',
                                                '".$ank['id']."',
                                                '".$text."',
                                                '".time()."',
                                                '".$gift['image']."',
                                                '".$user_id."',
                                                '".$type."'
											);
           ") or die(mysql_error());
           $pid = mysql_insert_id();
           $whom = $ank['id'];
           mysql_query("INSERT INTO `cms_mail` SET
					`user_id` = '$user_id', 
					`from_id` = '" . $ank['id'] . "',
					`text` = '" . mysql_real_escape_string(($type != 0 ? $lng_gifts['new_gift_privat'] : $lng_gifts['new_gift']) . " [url=".$home."/gifts/?act=showall&user=$whom]$gift[name][/url] " . $lng_gifts['from'] . " " . $login) . "',
					`time` = '" . time() . "',
					`sys` = '1',
					`them` = '" . $lng_gifts['new_gift'] . "'");
            mysql_query("update `users` set `balans` = '".$newbalans."' where `id` = '".$user_id."'");
            header("location: /users/profile.php?user=$ank[id]");
        } else
            echo functions::display_error($lng_gifts['not_balans']);
    } else {
        $gift['pcost'] = $gift['pcost'];
		$gift['cost'] = $gift['cost'];
		echo '<div class="gmenu"><form action="?act=send&amp;id='.$id.'&amp;user='.$ank['id'].'" method="post">
		' .
		(!empty($ank['name']) ? 
		'<div class="rmenu">' . $lng_gifts['gift'] . ' ' . $lng_gifts['for'] . ' '.functions::check($ank['name']).'</div><input type="hidden" name="name" value="'.functions::check($ank['name']).'" />' : '<div>' . $lng_gifts['whom'] . '</div>
		<input type="text" name="name" value="'.$ank['name'].'" />') .
        '<table cellspacing="0" callpadding="0" width="100%">
        <tr>
        <td width="50%">' .
		'<div>' . $lng_gifts['text_to_text'] . '</div>
		<input type="text" name="text" value="" />
		<div>' . $lng_gifts['type'] . '</div>
		<input type="radio" name="type" value="0" checked="checked" /> - ' . $lng_gifts['public'] . ', <b>'. $gift['cost'].'</b> ' . $lng_gifts['balans'] . '<br/>
		<input type="radio" name="type" value="1" />- ' . $lng_gifts['privat'] . ', <b>'.$gift['pcost'].'</b> ' . $lng_gifts['balans'] . '
		<br/><input type="submit" name="submit" value="' . $lng_gifts['send'] . '" /></td><td align="right">';
        //Название директории с изображениями
                    $dir='gifts';
                    //Задаем параметры ресайза, в нашем случае - ширина и высота
                    $imageWidth='128';
                    $imageHeight='128';
                    $rgsdimg = $home .'/image.php?image=/images/'.$dir.'/'. $gift['image'] .'&amp;width='. $imageWidth .'&amp;height='. $imageHeight.'&amp;cropratio=1:1';
                    $photo='<img  src="'. $rgsdimg .'" title="'.$gift['image'].'"  />';
                    echo $photo;
                    echo '</td></tr></table>';
		echo '</form></div>';
        
    }
} else
    header("Location: index.php");


if($rights >= 7) {
    echo '<div class="rmenu"><a href="index.php?act=delgift&amp;id=' . $id . '">' . $lng_gifts['delgift'] . '</a></div>' .
    '<div class="rmenu"><a href="index.php?act=editgift&amp;id=' . $id . '">' . $lng_gifts['editgift'] . '</a></div>';
}
?>