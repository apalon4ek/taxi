<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'delcat';
$textl = $lng_gifts['delcat'];
require('../incfiles/head.php');
$path = '../../';

if($rights >= 7)
{

function delCategory($id=0) {
    global $home;
		$child = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` where `cat` = '$id'"));
        if($child) {
            if($child['type'] != '1')
                delCategory($child['id']);
            else {
                mysql_query("DELETE FROM `gifts` WHERE `id` = '$child[id]' LIMIT 1");
                unlink('/images/gifts/' . $child['image']);
            }                
        } else 
            mysql_query("DELETE FROM `gifts` WHERE `id` = '$id' LIMIT 1");
	}
    $cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` WHERE `id` = '$id'"));
    $parent = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` WHERE `id` = '$cat[cat]'"));
    if($id) {
    echo '<div class="bmenu">
            <a href="index.php'.($parent ? '?id='.$parent['id'] : NULL).'">
                <table cellspacing="0" callpadding="0" width="100%">
                    <tr>
                        <td width="36px">
                            <img src="' . $home . '/images/folder_up.png" alt="Folder" align="middle" />
                        </td>
                        <td align="left">
                            ' . ($parent ? $parent['name'] : $lng_gifts['cats']) . '
                        </td>
                    </tr>
                </table>
            </a>
        </div>';
    }
    if(isset($_POST['submit'])) {
        $child = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` where `cat` = '$id'"));
        if($child)
            echo functions::display_error($lng_gifts['not_empty']);
        else
        {
            delCategory($id);
            header("Location: index.php");
        }
    } else {
        echo '<div class="gmenu"><form action="?act=delcat&amp;id='.$id.'" method="post">'.
        '<div class="rmenu">' . $lng_gifts['delcat'] . '?</div>
        <input type="submit" name="submit" value="' . $lng_gifts['delcat'] . '" />';
		echo '</form></div>';
    }
    
 
} else
    header("location: index.php");