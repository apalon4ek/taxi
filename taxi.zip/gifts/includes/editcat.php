<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'editcat';
$textl = $lng_gifts['editcat'];
require('../incfiles/head.php');



if($rights >= 7)
{
    if(!$id)
			header("location: ?");
		else
		{
			$cat = mysql_fetch_assoc(mysql_query("select * from `gifts` where `id` = '" . $id . "'"));
			if(isset($_POST['submit']))
			{
				$name = !empty($_POST['name']) ? mysql_real_escape_string($_POST['name']) : $cat['name'];
				$parent = !empty($_POST['parent']) ? abs(intval($_POST['parent'])) : $cat['parent'];
				mysql_query("UPDATE  `gifts` SET `cat` = '".$parent."', `name` = '".$name."' where `id` = '".$id."'");
				header("location: index.php?id=$id");
			}
			else
			{
				echo '<form action="?act=editcat&amp;id='.$id.'" method="post">
			<div class="gemnu">
			<div>' . $lng_gifts['name'] . '</div>
			<input type="text" name="name" value="'.$cat['name'].'" />
			<div>' . $lng_gifts['cat'] . '</div>
			<select name="parent">
			<option value="0">' . $lng_gifts['empty'] . '</option>';
			$sql = mysql_query("select * from `gifts` where `type` = '0' and `id` != '$id'");
			while($row = mysql_fetch_assoc($sql))
			{
				echo '<option value="'.$row['id'].'"'.($row['id'] == $cat['cat'] ? ' selected="selected"' : '').'>'.$row['name'].'</option>';
			}
			echo '</select>
			<br/><input type="submit" name="submit" value="' . $lng['save'] . '" />
			</div>
			</form>';
			}
		}
}