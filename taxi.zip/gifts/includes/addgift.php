<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'addgift';
$textl = $lng_gifts['addgift'];
require('../incfiles/head.php');



if($rights >= 7)
	{
		if(isset($_POST['submit']))
		{
			$name = trim(mysql_real_escape_string($_POST['name']));
			$cid = isset($_POST['parent']) ? abs(intval($_POST['parent'])) : 0;
			$cost = isset($_POST['cost']) ? abs(intval($_POST['cost'])) : 100;
			$pcost = isset($_POST['pcost']) ? abs(intval($_POST['pcost'])) : 200;
			$cost = $cost > 0 ? $cost : 100;
            $pcost = $pcost > 0 ? $pcost : 100;
            // Каталог, в который мы будем принимать файл:
			$uploaddir = $rootpath . '/images/gifts/';
            if(file_exists($uploaddir.basename($_FILES['uploadfile']['name']))) 
                $uploadfile = $uploaddir.'copy_'.basename($_FILES['uploadfile']['name']);
            else
                $uploadfile = $uploaddir.basename($_FILES['uploadfile']['name']);

			// Копируем файл из каталога для временного хранения файлов:
			if (copy($_FILES['uploadfile']['tmp_name'], $uploadfile))
			{
			     chmod($uploadfile, 0666);
				mysql_query("INSERT INTO  `gifts` (
												`id` ,
												`cat` ,
												`name` ,
												`cost` ,
												`pcost` ,
												`image`,
                                                `type`
												)
											VALUES (
												NULL ,
                                                '".$cid."',
                                                '".$name."',
                                                '".$cost."',
                                                '".$pcost."',
                                                '".basename($_FILES['uploadfile']['name'])."',
                                                '1'
											);
			") or die(mysql_error());
			header("location: index.php" . ($id ? '?id=' . $id : null));
            } else {
                echo functions::display_error($lng_gifts['error_upload']);
            }
		}
		else
		{
			echo '<form action="?act=addgift' . ($id ? '&amp;id=' . $id : null) . '" method="post" enctype="multipart/form-data">
			<div class="gemnu">
			<div>' . $lng_gifts['name'] . '</div>
			<input type="text" name="name" value="" />
			<div>' . $lng_gifts['cost'] . '</div>
			<input type="text" name="cost" value="" />
			<div>' . $lng_gifts['pcost'] . '</div>
			<input type="text" name="pcost" value="" />
			<div>' . $lng_gifts['cat'] . '</div>
			<select name="parent">
			<option value="0">' . $lng_gifts['empty'] . '</option>';
			$sql = mysql_query("select * from `gifts` where `type` = '0'");
			while($row = mysql_fetch_assoc($sql))
			{
				echo '<option value="'.$row['id'].'"'.( ($id && $id == $row['id']) ? ' selected="selected"' : NULL).'>'.$row['name'].'</option>';
			}
			echo '</select>
			<div>' . $lng_gifts['image'] . '</div>
			<input type="file" name="uploadfile" />
			<br/><input type="submit" name="submit" value="' . $lng['save'] . '" />
			</div>
			</form>';
		}
	}
	else
		header("location: ?");