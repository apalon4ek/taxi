<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'addcat';
$textl = $lng_gifts['addcat'];
require('../incfiles/head.php');


if($rights >= 7)
	{
		if(isset($_POST['submit']))
		{
			$name = trim(mysql_real_escape_string($_POST['name']));
			$cid = isset($_POST['parent']) ? abs(intval($_POST['parent'])) : 0;
			mysql_query("INSERT INTO  `gifts` (
												`id` ,
												`cat` ,
												`name` ,
												`cost` ,
												`image`,
                                                `type`
												)
											VALUES (
												NULL ,  '".$cid."',  '".$name."',  '',  '', '0'
											);
			") or die(mysql_error());
			header("location: index.php" . ($id ? '?id=' . $id : null));
		}
		else
		{
			echo '
			<form action="?act=addcat' . ($id ? '&amp;id=' . $id : null) . '" method="post">
			<div class="gmenu">
			<div>' . $lng_gifts['name'] . '</div>
			<input type="text" name="name" value="" />
			<div>' . $lng_gifts['parent'] . '</div>
			<select name="parent">
			<option value="0">' . $lng_gifts['empty'] . '</option>
			';
			$sql = mysql_query("select * from `gifts` where `type` = '0'");
			while($row = mysql_fetch_assoc($sql))
			{
				echo '<option value="'.$row['id'].'"'.( ($id && $id == $row['id']) ? ' selected="selected"' : NULL).'>'.$row['name'].'</option>';
			}
			echo '
			</select>
			<br/><input type="submit" name="submit" value="' . $lng_gifts['create'] . '" />
			</div>
			</form>
			';
		}




echo '<div class="menu"><a href="index.php'.( $id ? '?id=' . $id : NULL).'">
<table cellspacing="0" callpadding="0" width="100%">
                    <tr>
                        <td width="36px">
                            <img src="' . $home . '/images/folder_up.png" alt="Folder" align="middle" />
                        </td>
                        <td align="left">
                            ' . $lng['back'] . '
                        </td>
                    </tr>
                </table></a></div>';
	}
?>