<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'editcat';
$textl = $lng_gifts['editcat'];
require('../incfiles/head.php');



if($rights >= 7)
{
   if(!$id)
			header("location: ?");
		else
		{
			$gift = mysql_fetch_assoc(mysql_query("select * from `gifts` where `id` = '" . $id . "'"));
			if(isset($_POST['submit']))
			{
				$name = !empty($_POST['name']) ? mysql_real_escape_string($_POST['name']) : $gift['name'];
				$cost = !empty($_POST['cost']) ? mysql_real_escape_string($_POST['cost']) : $gift['cost'];
                $pcost = !empty($_POST['pcost']) ? mysql_real_escape_string($_POST['pcost']) : $gift['pcost'];
				$parent = !empty($_POST['parent']) ? abs(intval($_POST['parent'])) : $gift['parent'];
				mysql_query("UPDATE  `gifts` SET `cat` = '".$parent."', `name` = '".$name."', `cost` = '".$cost."', `pcost` = '".$pcost."' where `id` = '".$id."'");
				header("location: index.php?id=$parent");
			}
			else
			{
			 if(!empty($gift['image'])) {
			     echo '<div>';
			     //Название директории с изображениями
                 $dir='gifts';
                 //Задаем параметры ресайза, в нашем случае - ширина и высота
                 $imageWidth='64';
                 $imageHeight='64';
                 $rgsdimg = $home .'/image.php?image=/images/'.$dir.'/'. $gift['image'] .'&amp;width='. $imageWidth .'&amp;height='. $imageHeight.'&amp;cropratio=1:1';
                 $photo='<img  src="'. $rgsdimg .'" title="'.$gift['image'].'"  />';
                 echo $photo;
			echo '</div>';
            }
            echo '<form action="?act=editgift&amp;id='.$id.'" method="post">
			<div class="gemnu">
			<div>' . $lng_gifts['name'] . '</div>
			<input type="text" name="name" value="'.$gift['name'].'" />
			<div>' . $lng_gifts['cost'] . '</div>
			<input type="text" name="cost" value="'.$gift['cost'].'" />
			<div>' . $lng_gifts['pcost'] . '</div>
			<input type="text" name="pcost" value="'.$gift['pcost'].'" />
			<div>' . $lng_gifts['cat'] . '</div>
			<select name="parent">
			<option value="0">' . $lng_gifts['empty'] . '</option>';
			$sql = mysql_query("select * from `gifts` where `cost` < '1'");
			while($row = mysql_fetch_assoc($sql))
			{
				echo '<option value="'.$row['id'].'"'.($row['id'] == $gift['cat'] ? ' selected="selected"' : '').'>'.$row['name'].'</option>';
			}
			echo '</select>
			<br/><input type="submit" name="submit" value="' . $lng['save'] . '" />
			</div>
			</form>';
			}
		} 
}