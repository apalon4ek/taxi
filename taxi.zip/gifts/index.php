<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);

$headmod = 'gifts';
$rootpath = '../';
require('../incfiles/core.php');
$lng_gifts = core::load_lng('gifts');
/*
-----------------------------------------------------------------
Закрываем от неавторизованных юзеров
-----------------------------------------------------------------
*/
if (!$user_id) {
    require('../incfiles/head.php');
    echo functions::display_error($lng['access_guest_forbidden']);
    require('../incfiles/end.php');
    exit;
}

/*
-----------------------------------------------------------------
Переключаем режимы работы
-----------------------------------------------------------------
*/
$array = array(
    'addcat' => 'includes',
    'addgift' => 'includes',
    'editcat' => 'includes',
    'editgift' => 'includes',
    'delgift' => 'includes',
    'delcat' => 'includes',
    'delmygift' => 'includes',
    'showall' => 'includes',
    'send' => 'includes'
);
$path = !empty($array[$act]) ? $array[$act] . '/' : '';
if (array_key_exists($act, $array) && file_exists($path . $act . '.php')) {
    require_once($path . $act . '.php');
} else {
    $textl = $lng_gifts['gifts'];
    require('../incfiles/head.php');
    /*
    -----------------------------------------------------------------
    Определяем получателя
    -----------------------------------------------------------------
    */
    if($user) {
        $ank = functions::get_user($user);
        if(!$ank)
            $ank = $datauser;
    } else
        $ank = $datauser;
    echo '<div class="phdr"><b>' . $lng_gifts['gift'] . ' ' . $lng_gifts['for'] . ' ' . $ank['name'] . '</b></div>';
    
    if($id && mysql_result(mysql_query("SELECT COUNT(*) FROM `gifts` where `id` = '$id'"),0) < 1)
        header("Location: index.php");
        /*
        -----------------------------------------------------------------
        Выводим верхнее меню
        -----------------------------------------------------------------
        */
        $cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` WHERE `id` = '$id'"));
        $parent = mysql_fetch_assoc(mysql_query("SELECT * FROM `gifts` WHERE `id` = '$cat[cat]'"));
        if($id) {
            echo '<div class="bmenu"><a href="index.php'.($parent ? '?id='.$parent['id'].($ank['id'] != $user_id ? '&amp;user=' . $ank['id'] : NULL) : ($ank['id'] != $user_id ? '?user=' . $ank['id'] : NULL)).'">
                <table cellspacing="0" callpadding="0" width="100%">
                    <tr>
                        <td width="36px">
                            <img src="' . $home . '/images/folder_up.png" alt="Folder" align="middle" />
                        </td>
                        <td align="left">
                            ' . ($parent ? $parent['name'] : $lng_gifts['cats']) . '
                        </td>
                    </tr>
                </table>
            </a></div>';
        }
        
        /*
        -----------------------------------------------------------------
        Получаем список категорий и подарков
        -----------------------------------------------------------------
        */
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `gifts` WHERE `cat` = '$id'"),0);
        if($total > 0) {
            $req = mysql_query("SELECT * FROM `gifts` WHERE `cat` = '$id' ORDER BY `type` ASC, `name` ASC LIMIT $start, $kmess");
            for ($i = 0; $res = mysql_fetch_assoc($req); ++$i) {
                $text = '';
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                if($res['type'] == 1) {
                    //Название директории с изображениями
                    $dir='gifts';
                    //Задаем параметры ресайза, в нашем случае - ширина и высота
                    $imageWidth='32';
                    $imageHeight='32';
                    $rgsdimg = $home .'/image.php?image=/images/'.$dir.'/'. $res['image'] .'&amp;width='. $imageWidth .'&amp;height='. $imageHeight.'&amp;cropratio=1:1';
                    $photo='<img  src="'. $rgsdimg .'" title="'.$res['image'].'"  />';
                } else 
                    $photo='<img  src="'. $home .'/images/folder.png" title="Папка"  />';
                echo '<a href="index.php?id=' . $res['id'] . ($res['type'] == 0 ? NULL : '&amp;act=send') . ($ank['id'] != $user_id ? '&amp;user=' . $ank['id'] : NULL) . '">' .
                '<table cellspacing="0" callpadding="0" width="100%">
                    <tr>
                        <td width="36px">
                            ' . $photo . '
                        </td>
                        <td align="left">
                            ' . $res['name'] . '
                        </td>
                    </tr>
                </table>' .
                '</a>';
                echo '</div>';
            }
            echo '<div class="phdr">' . $lng['total'] . ': ' . $total . '</div>';
            if ($total > $kmess) {
                echo '<div class="topmenu">' . functions::display_pagination('index.php?', $start, $total, $kmess) . '</div>' .
                    '<p><form action="index.php" method="get"><input type="text" name="page" size="2"/>' .
                    '<input type="submit" value="' . $lng['to_page'] . ' &gt;&gt;"/></form></p>';
            }
        } else 
            echo functions::display_error($lng_gifts['not_cat']);
            
        /*
        -----------------------------------------------------------------
        Выводим нижнее меню
        -----------------------------------------------------------------
        */
        /*if($id) {
            echo '<div class="bmenu"><a href="index.php'.($parent ? '?id='.$parent['id'] : '').'">
                <table cellspacing="0" callpadding="0" width="100%">
                    <tr>
                        <td width="36px">
                            <img src="' . $home . '/images/folder_up.png" alt="Folder" align="middle" />
                        </td>
                        <td align="left">
                            ' . ($parent ? $parent['name'] : $lng_gifts['cats']) . '
                        </td>
                    </tr>
                </table>
            </a></div>';
        }*/
        
        /*
        -----------------------------------------------------------------
        Выводим административные ссылки
        -----------------------------------------------------------------
        */
        if($rights >= 7) {
            echo '<div class="rmenu"><a href="index.php?act=addcat' . ($id ? '&amp;id=' . $id : '') . '">' . $lng_gifts['addcat'] . '</a></div>' .
            '<div class="rmenu"><a href="index.php?act=addgift' . ($id ? '&amp;id=' . $id : '') . '">' . $lng_gifts['addgift'] . '</a></div>' .
            ($id ? '<div class="rmenu"><a href="index.php?act=delcat' . ($id ? '&amp;id=' . $id : '') . '">' . $lng_gifts['delcat'] . '</a></div>' : NULL) .
            ($id ? '<div class="rmenu"><a href="index.php?act=editcat' . ($id ? '&amp;id=' . $id : '') . '">' . $lng_gifts['editcat'] . '</a></div>' : NULL);
        }
}
require_once('../incfiles/end.php');