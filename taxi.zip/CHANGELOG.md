# AliJohnCMS v1
Original JohnCMS 6.1.2dan tuzilgan
### O'zgartirishlar
  * Wap va web modulida ishlaydi
  * Bloglar moduli qo'shilgan
  * YoSH-MaSTeR muallifligidagi statuslar moduli versiyaga moslangan, o'zgartirishlar kiritilgan
  * Sovg'alar yuborish moduli qo'shilgan
  * Sayt magazini, ballar va bonuslar ulangan
  * Barcha userlarga xabar yuborish funksiyasi (AliMail)
  * Bosh sahifani admin paneldan turib boshqarish
  * Va boshqa kichik o'zgartirishlar