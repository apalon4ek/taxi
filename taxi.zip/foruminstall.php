<?php
define('_IN_JOHNCMS', 1);
set_time_limit(1200);

$mtime = explode(' ', microtime());
$mtime = $mtime[1] + $mtime[0];
$starttime = $mtime;

$rootpath = '';
require 'incfiles/core.php';

$textl = 'Форум by seg0ro';

require 'incfiles/head.php';

if ($rights < 9){
  echo functions::display_error('У вас недостаточно прав для просмотра этой страницы!');
  require 'incfiles/end.php';
  exit;
}

switch (trim($_GET['step'])){
  
  case 'tables':
    
    mysql_query("CREATE TABLE IF NOT EXISTS `forum_favourites` (
    `topic` int(11) NOT NULL,
    `user_id` int(11) NOT NULL,
    KEY `topic` (`topic`),
    KEY `user_id` (`user_id`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");

     mysql_query("CREATE TABLE IF NOT EXISTS `forum_files` (
    `file` int(11) NOT NULL AUTO_INCREMENT,
    `post` int(11) NOT NULL,
    `topic` int(11) NOT NULL,
    `time` int(11) NOT NULL,
    `user_id` int(11) NOT NULL,
    `filename` varchar(50) NOT NULL,
    `down` int(11) NOT NULL,
    `tempid` int(11) NOT NULL,
    PRIMARY KEY (`file`),
    KEY `post` (`post`),
    KEY `topic` (`topic`),
    KEY `user_id` (`user_id`),
    KEY `tempid` (`tempid`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");

    mysql_query("CREATE TABLE IF NOT EXISTS `forum_forums` (
    `forum` int(11) NOT NULL AUTO_INCREMENT,
    `sort` int(11) NOT NULL,
    `parent` int(11) NOT NULL,
    `type` int(1) NOT NULL DEFAULT '0',
    `forumname` varchar(100) NOT NULL,
    `desc` tinytext NOT NULL,
    `keyw` tinytext NOT NULL,
    `descw` text NOT NULL,
    `last_topic` varchar(250) NOT NULL,
    `count` int(11) NOT NULL,
    `close` TINYINT( 1 ) NOT NULL,
    `template` text NOT NULL,
    PRIMARY KEY (`forum`),
    KEY `sort` (`sort`),
    KEY `parent` (`parent`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
    
    mysql_query("CREATE TABLE IF NOT EXISTS `forum_journal` (
    `time` int(11) NOT NULL,
    `user_id` int(10) NOT NULL,
    `text` text NOT NULL,
    `readed` int(1) NOT NULL,
    PRIMARY KEY (`time`),
    KEY `user_id` (`user_id`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
    
    mysql_query("
    CREATE TABLE IF NOT EXISTS `forum_logs` (
    `time` int( 11 ) NOT NULL ,
    `user_id` int( 11 ) NOT NULL ,
    `text` text NOT NULL ,
    `browser` varchar( 250 ) NOT NULL ,
    `ip` bigint( 11 ) NOT NULL ,
    `ip_via_proxy` bigint( 11 ) NOT NULL 
    ) ENGINE = MYISAM DEFAULT CHARSET = utf8;");
    
    mysql_query("CREATE TABLE IF NOT EXISTS `forum_polled` (
    `topic` int(11) NOT NULL,
    `poll` int(11) NOT NULL,
    `user_id` int(11) NOT NULL,
    KEY `topic` (`topic`),
    KEY `user_id` (`user_id`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
    
    mysql_query("CREATE TABLE IF NOT EXISTS `forum_polls` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `topic` int(11) NOT NULL,
    `variantname` varchar(150) NOT NULL,
    `count` int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `topic` (`topic`),
    KEY `count` (`count`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
    
    mysql_query("CREATE TABLE IF NOT EXISTS `forum_posts` (
    `post` int(11) NOT NULL AUTO_INCREMENT,
    `topic` int(11) NOT NULL,
    `time` int(11) NOT NULL,
    `user_id` int(11) NOT NULL,
    `user` varchar(40) NOT NULL,
    `text` text NOT NULL,
    `edit` varchar(250) NOT NULL DEFAULT '',
    `files` int(1) NOT NULL,
    `browser` varchar(250) NOT NULL,
    `ip` bigint(11) NOT NULL,
    `ip_via_proxy` bigint(11) NOT NULL,
    `rating` int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`post`),
    KEY `topic` (`topic`),
    KEY `time` (`time`),
    KEY `user_id` (`user_id`),
    KEY `files` (`files`),
    FULLTEXT KEY `text` (`text`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
    
    mysql_query("CREATE TABLE IF NOT EXISTS `forum_posts_rating` (
    `post` int(11) NOT NULL,
    `user_id` int(11) NOT NULL,
    KEY `post` (`post`),
    KEY `user_id` (`user_id`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
    
    mysql_query("CREATE TABLE IF NOT EXISTS `forum_readed` (
    `topic` int(11) NOT NULL,
    `user_id` int(11) NOT NULL,
    `time` int(11) NOT NULL,
    `lastpost` int(11) NOT NULL,
    PRIMARY KEY (`topic`,`user_id`),
    KEY `time` (`time`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
    
    mysql_query("CREATE TABLE IF NOT EXISTS `forum_topics` (
    `topic` int(11) NOT NULL AUTO_INCREMENT,
    `forum` int(11) NOT NULL,
    `time` int(11) NOT NULL,
    `topicname` varchar(100) NOT NULL,
    `forumname` varchar(150) NOT NULL,
    `user_id` int(11) NOT NULL,
    `user` varchar(40) NOT NULL,
    `lastpost` varchar(250) NOT NULL,
    `count` int(11) NOT NULL,
    `close` tinyint(1) NOT NULL,
    `sticky` tinyint(1) NOT NULL,
    `clip` tinyint(1) NOT NULL,
    `poll_name` varchar(250) NOT NULL,
    `poll_set` text NOT NULL,
    `curator` int(11) NOT NULL,
    PRIMARY KEY (`topic`),
    KEY `topic` (`topic`),
    KEY `time` (`time`),
    KEY `user_id` (`user_id`),
    KEY `stycky` (`sticky`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
  
    echo '<div class="phdr">Установка таблиц</div><div class="gmenu">Таблицы установлены</div>'.
   '<div class="menu">Выберите ссылку для продолжения процесса переноса данных или перехода на форум:<br /><a href="foruminstall.php?step=transfer">Перенос данных старого форума</a> | <a href="forum/index.php">Форум</a></div>';
  break;
  
  case 'transfer':
    echo '<div class="phdr">Перенос данных со старого форума на новый</div><div class="rmenu">Процедура переноса может занимать много времени (зависит от размера таблиц форума), так что запаситесь терпением!<br /><br />'.
   '1) Новый форум не должен содержать данных (быть чистым)<br />'.
   '2) Перед переходом к первому шагу, обязательно сделайте дамп следующих таблиц: <strong>cms_forum_files</strong>, <strong>cms_forum_vote</strong>, <strong>cms_forum_vote_users</strong>, <strong>forum</strong><br />'.
   '2) Перед процедурой переноса, пожалуйста, пройдите по <a href="'.$set['admp'].'/index.php?act=forum">ссылке</a> и удалите все скрытые темы и скрытые сообщения старого форума, поскольку новый форум не поддерживает систему скрытия'.
   '</div><div class="menu"><a href="foruminstall.php?step=structure">Перейти к первому шагу</a></div>';
  break;
  
  case 'structure':
    echo '<div class="phdr">Шаг 1: Перенос структуры</div>';
    
    mysql_query("TRUNCATE `forum_favourites`;");
    mysql_query("TRUNCATE `forum_files`;");
    mysql_query("TRUNCATE `forum_forums`;");
    mysql_query("TRUNCATE `forum_journal`;");
    mysql_query("TRUNCATE `forum_polled`;");
    mysql_query("TRUNCATE `forum_polls`;");
    mysql_query("TRUNCATE `forum_posts`;");
    mysql_query("TRUNCATE `forum_posts_rating`;");
    mysql_query("TRUNCATE `forum_readed`;");
    mysql_query("TRUNCATE `forum_topics`;");
        
    mysql_query("ALTER TABLE `forum_forums` ADD `oldid` INT( 11 ) NOT NULL , ADD KEY ( `oldid` )");
    
    $forumReq = mysql_query("SELECT * FROM `forum` WHERE `type` = 'f' OR `type` = 'r' ");
    if (mysql_num_rows($forumReq)){
      
      while ($forumRes = mysql_fetch_assoc($forumReq)){
        
        $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '".$forumRes['id']."' AND `close` = '0' "), 0);  
                
        $sql = "INSERT INTO `forum_forums` SET
        `sort` = '".$forumRes['realid']."',
        `parent` = '".$forumRes['refid']."',
        `type` = '".($forumRes['type'] == 'r' ? 1 : 0)."',
        `forumname` = '".$forumRes['text']."',
        `count` = '$count',
        `oldid` = '".$forumRes['id']."'
        ";
        
        mysql_query($sql);
      }
          
      echo '<div class="gmenu">Структура перенесена<br /><a href="foruminstall.php?step=topics">Перейти ко второму шагу</a></div>';
    }else{
      echo functions::display_error('Нет форумов для переноса!<br /><a href="forum/index.php">Форум</a>');
    }
  break;
  
  case 'topics':
    echo '<div class="phdr">Шаг 2: Перенос тем и голосований</div>';
    
    mysql_query("ALTER TABLE `forum_topics` ADD `oldid` INT( 11 ) NOT NULL , ADD KEY ( `oldid` )");
    
    $topicReq = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' AND `close` = '0' ");
    
    if (mysql_num_rows($topicReq)){
      
      while ($topicRes = mysql_fetch_assoc($topicReq)){
        
        $forumRes = mysql_fetch_assoc(mysql_query("SELECT `forum`, `forumname` FROM `forum_forums` WHERE `oldid` = '".$topicRes['refid']."' LIMIT 1 "));
        $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 'm' AND `refid` = '".$topicRes['id']."' AND `close` = '0' "), 0);
        
        $sql = "INSERT INTO `forum_topics` SET
        `forum` = '".$forumRes['forum']."',
        `time` = '".$topicRes['time']."',
        `topicname` = '".$topicRes['text']."',
        `forumname` = '".$forumRes['forumname']."',
        `user_id` = '".$topicRes['user_id']."',
        `user` = '".$topicRes['from']."',
        `count` = '$count',
        `close` = '".$topicRes['edit']."',
        `sticky` = '".$topicRes['vip']."',
        `curator` = '".$topicRes['curators']."',
        `oldid` = '".$topicRes['id']."'
        ";
        
         mysql_query($sql);
         $topic = mysql_insert_id();
         
         $pollReq = mysql_query("SELECT * FROM `cms_forum_vote` WHERE `topic` = '".$topicRes['id']."' ");
        if (mysql_num_rows($pollReq)){
          while ($pollRes = mysql_fetch_assoc($pollReq)){
            if ($pollRes['type'] == 1){
              $pollName = $pollRes['name'];
              $pollSet = serialize(array('poll_mod' => 0, 'total_polls' => $pollRes['count'], 'total_polled' => $pollRes['count'], 'poll_close' => 0));
            }else{
              $sql = "INSERT INTO `forum_polls` SET
              `topic` = '$topic',
              `variantname` = '".$pollRes['name']."',
              `count` = '".$pollRes['count']."'
              ";
              mysql_query($sql);
            
            }
          }
          
          $polledReq = mysql_query("SELECT * FROM `cms_forum_vote_users` WHERE `topic` = '".$topicRes['id']."' ");
          if (mysql_num_rows($polledReq)){
            while ($polledRes = mysql_fetch_assoc($polledReq)){
              $sql = "INSERT INTO `forum_polled` SET
              `topic` = '$topic',
              `poll` = '".$polledRes['vote']."',
              `user_id` = '".$polledRes['user']."'
              ";
              mysql_query($sql);
            }
          }
        }else{
          $pollName = '';
          $pollSet = '';
        }
        
        mysql_query("UPDATE `forum_topics` SET
        `poll_name` = '".$pollName."',
        `poll_set` = '".$pollSet."'
        WHERE `topic` = '$topic' LIMIT 1
        ");
         
      }
          
      echo '<div class="gmenu">Темы и голосования перенесены<br /><a href="foruminstall.php?step=posts">Перейти к третьему  шагу</a></div>';
    }else{
      echo functions::display_error('Нет тем для переноса!<br /><a href="forum/index.php">Форум</a>');
    }
  break;
  
  case 'posts':
    echo '<div class="phdr">Шаг 3: Перенос сообщений и файлов</div>';
    
    $postReq = mysql_query("SELECT `forum`.*, `forum_topics`.`topic` FROM `forum` LEFT JOIN `forum_topics` ON `forum`.`refid` = `forum_topics`.`oldid` WHERE `forum`.`close` = '0' AND `forum`.`type` = 'm' ");
    if (mysql_num_rows($postReq)){
      while ($postRes = mysql_fetch_assoc($postReq)){
        
        $fileReq = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '".$postRes['id']."' LIMIT 1 ");
        $file = mysql_num_rows($fileReq);
        
        $sql = "INSERT INTO `forum_posts` SET
        `topic` = '".$postRes['topic']."',
        `time` = '".$postRes['time']."',
        `user_id` = '".$postRes['user_id']."',
        `user` = '".$postRes['from']."',
        `text` = '".$postRes['text']."',
        `edit` = '".($postRes['edit'] ? $postRes['edit'].":|:".$postRes['tedit'] : "")."',
        `files` = '$file',
        `browser` = '".$postRes['soft']."',
        `ip` = '".$postRes['ip']."',
        `ip_via_proxy` = '".$postRes['ip_via_proxy']."'
        ";
        
         mysql_query($sql);
        $post = mysql_insert_id();
        
        if ($file){
          $fileRes = mysql_fetch_assoc($fileReq);
          $sql = "INSERT INTO `forum_files` SET
          `post` = '".$post."',
          `topic` = '".$postRes['topic']."',
          `time` = '".$fileRes['time']."',
          `user_id` = '".$postRes['user_id']."',
          `filename` = '".$fileRes['filename']."',
          `down` = '".$fileRes['dlcount']."'
          ";
           mysql_query($sql);
        }
      } 
           
      echo '<div class="gmenu">Темы и голосования перенесены<br /><a href="foruminstall.php?step=final">Перейти к последнему шагу</a></div>';
    }else{
      echo functions::display_error('Нет сообщений для переноса!<br /><a href="forum/index.php">Форум</a>');
    }
  break;
  
  case 'final':
    
    if (isset($_POST['yes'])){
      mysql_query("DROP TABLE `cms_forum_files` ");
      mysql_query("DROP TABLE `cms_forum_rdm` ");
      mysql_query("DROP TABLE `cms_forum_vote` ");
      mysql_query("DROP TABLE `cms_forum_vote_users` ");
      mysql_query("DROP TABLE `forum`;");
      
      echo '<div class="gmenu">Таблицы старого форума удалены.<br />Не забудьте перенести файлы форума из папки <strong>files/forum/attach</strong> в папку <strong>files/forum</strong> любым для вас удобным способом<br /><a href="forum/index.php">Форум</a></div>';
      require 'incfiles/end.php';
      exit;
    }
    
    echo '<div class="phdr">Шаг 4: Завершающая стадия</div>';
    
    mysql_query("ALTER TABLE `forum_forums` DROP `oldid` ");
    mysql_query("ALTER TABLE `forum_topics` DROP `oldid` ");
    
    mysql_query("UPDATE `users` SET `set_forum` = '' ");
    
    echo '<form action="foruminstall.php?step=final" method="post"><div class="gmenu">Дополнительные  поля в таблицах удалены, настройки форума пользователей сброшены, старый форум полностью перенессён, спасибо за терпение.<br />Желаете ли удалить таблицы старого форума?<br /><input type="submit" name="yes" value="Удалить" /> <a href="forum/index.php">Отмена</a></div></form>';
  break;
  
  default:
   echo '<div class="phdr">Форум by seg0ro</div><div class="gmenu">Добро пожаловать в мастер установки форума.</div>'.
   '<div class="menu">Выберите ссылку для продолжения процесса установки/переноса данных:<br /><a href="foruminstall.php?step=tables">Установка таблиц</a> | <a href="foruminstall.php?step=transfer">Перенос данных старого форума</a></div>';
  
}

$mtime = explode(' ', microtime());
$mtime = $mtime[1] + $mtime[0];
$endtime = $mtime;
$totaltime = round(($endtime - $starttime), 3);
echo '<div class="topmenu">Генерация: '.$totaltime.' сек.</div>';

require 'incfiles/end.php';