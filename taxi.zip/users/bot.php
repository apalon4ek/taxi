<?php

/**
* @package     JohnCMS
* @link        http://johncms.com
* @copyright   Copyright (C) 2008-2011 JohnCMS Community
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      http://johncms.com/about
*/

define('_IN_JOHNCMS', 1);

require('../incfiles/core.php');
require('../incfiles/head.php');

$user = functions::get_user($id);

if (!$user_id || $rights!=9 || !$user) {
    echo functions::display_error('Roxsat yo\'q!');
    require('../incfiles/end.php');
    exit;
}
echo'<div class="phdr">Onlayn qilish</div>';
if($user['bot']==1)
{
	mysql_query("update `users` set	`bot`='0' where `id`='$user[id]' limit 1");
	echo'<div class="menu">O\'chirib qo\'yildi!</div>';
}
else
{
	mysql_query("update `users` set	`bot`='1',`lastdate`='".time()."' where `id`='$user[id]' limit 1");
	echo'<div class="menu">Yoqib qo\'yildi!</div>';
}
	echo'<div class="menu"><a href="profile.php?user='.$user['id'].'">Orqaga</a></div>';
require_once('../incfiles/end.php');
?>