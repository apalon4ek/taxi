<?php
if ($user['id'] != $user_id){
  $g = mysql_result(mysql_query("SELECT * FROM `my_guests` WHERE `my_id` = '" . $user['id'] . "' AND `guest_id` = '" . $user_id . "' LIMIT 1;"), 0);
if (!empty($g)) {
  @mysql_query("UPDATE `my_guests` SET `time` = '" . time() . "', `type` = '0' WHERE `my_id` = '" . $user['id'] . "' AND `guest_id` = '" . $user_id . "';");
} else {
  @mysql_query("INSERT INTO `my_guests` SET
 `my_id` = '" . $user['id'] . "',
 `time` = '" . time() . "',
 `guest_id` = '" . $user_id . "',
 `type` = '0';");
 }
//Фиксация просмотра анкеты
  $p_ank = mysql_result(mysql_query("SELECT `prosm_ank` FROM `users` WHERE `id` = '" . $user['id'] . "';"), 0);
  $i_ank = (int) $p_ank;
  $r_ank = $i_ank + 1;
  @mysql_query("UPDATE `users` SET `prosm_ank` = '" . $r_ank . "' WHERE `id` = '" . $user['id'] . "';");
  echo '<div class="menu"><img src="../images/546.png" width="16" height="16"/>&#160;<span class="gray">Mexmonlari (' . $r_ank . ')</span></div>';
} else {
//Ссылка на страницу гостей для владельца анкеты
  $all_guests = @mysql_result(@mysql_query("SELECT COUNT(*) FROM `my_guests` WHERE `my_id` = '" . $user_id . "';"), 0);
  $new_guests = @mysql_result(@mysql_query("SELECT COUNT(*) FROM `my_guests` WHERE `my_id` = '" . $user_id . "' AND `type` = '0';"), 0);
  echo '<div class="menu"><img src="../images/546.png" width="16" height="16"/>&#160;<a href="' . $home . '/users/my_guests.php?">Mexmonlar</a>&nbsp;(' . $all_guests . ($new_guests > 0 ? '/<span class="red">' . $new_guests . '</span>' : '') . ')</div>';
}
?>
