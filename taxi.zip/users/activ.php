<?php
define('_IN_JOHNCMS', 1);
/*
Mod by DjHuSo 
*/


  $rootpath = '../';
  $textl = 'Faoligi';
  require_once ($rootpath . "incfiles/core.php");
  require_once ($rootpath . "incfiles/head.php");


if (!$user_id) {
  echo functions::display_error('Sahifa faqat userlarga xizmat ko\'rsatadi!<br />Buyoqqa kirish uchun <a href="/registration.php">ro\'yxatdan o\'ting</a> yoki <a href="/login.php">profilizga kiring</a>!');
  require_once ($rootpath . "incfiles/end.php");
  exit;
}

switch($_GET['act'])
{
case 'izoh':
$id = abs(intval($_GET['id']));



 echo'<div class="phdr">Izohlari</div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `news_comm` WHERE `user_id` = '".$id."' and `time` <= '" . time() . "'"), 0);
if ($total) {
$noimg = 'noimg.jpg';
$req = mysql_query("SELECT * FROM `news_comm` where `user_id` = '".$id."'  ORDER BY `time` DESC LIMIT  $start, $kmess;");
$i = 1;
 
 $news = mysql_result(mysql_query("SELECT COUNT(*) FROM `news` Where `mod` = '1'"), 0);

 while (($row = mysql_fetch_assoc($req)) !== false) {
 $user = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$row['user_id']."';"));
if ($user['sex']) {
$ico =   (time() > $user['lastdate'] + 2000 ? '<img src="'.$home.'/images/' . ($user['sex'] == 'm' ? 'man' : 'woman') . ($user['rights'] > 7 && $user['rights'] < 10 ? '_sv' : '') . ($user['rights'] > 6 && $user['rights'] < 9 ? '_adm' : '') . ($user['rights'] > 5 && $user['rights'] < 7 ? '_smod' : '') . ($user['rights'] > 4 && $user['rights'] < 6 ? '_lmod' : '') . ($user['rights'] > 3 && $user['rights'] < 5 ? '_dmod' : '') . ($user['rights'] > 2 && $user['rights'] < 4 ? '_fmod' : '') . '_off.gif" width="14" height="14" align="top" alt=""/>&#160;' : '<img src="/images/' . ($user['sex'] == 'm' ? 'man' : 'woman') . ($user['rights'] > 7 && $user['rights'] < 10 ? '_sv' : '') . ($user['rights'] > 6 && $user['rights'] < 9 ? '_adm' : '') . ($user['rights'] > 5 && $user['rights'] < 7 ? '_smod' : '') . ($user['rights'] > 4 && $user['rights'] < 6 ? '_lmod' : '') . ($user['rights'] > 3 && $user['rights'] < 5 ? '_dmod' : '') . ($user['rights'] > 2 && $user['rights'] < 4 ? '_fmod' : '') . '_on.gif" width="14" height="14" align="bootom" alt=""/>');
             
} else {
$ico = '<img src="'.$home.'/images/del.png" style="width: 14px;" alt="-">';
}
echo'<div class="menu">';

echo'<span class="soat"><b><a href="'.$home.'/users/profile.php?user='.$user['id'].'">'.$ico.' '.$user['imname'].'</a> </b></span>
'.$row['text'].' <a href="'.$home.'/news.php?act=info&id='.$row['rasm_id'].'">   <i class="fa fa-angle-double-right"></i></a></div>';
  $i;
}

echo'<div class="gmenu">Barchasi:'.$total.'</div>';
}else{
echo '<div class="menu">Ro`yxat bo`sh</div>';
}

if ($totls > $kmess){
echo '<div class="topmenu"><center>' . functions::display_pagination('index.php?', $start, $totls, $kmess) . '</center></div>';
}
break;
case 'news':
$id = abs(intval($_GET['id']));
echo'<div class="phdr">Yangiliklari</div>';
 $totls = mysql_result(mysql_query("SELECT COUNT(*) FROM `news_bolim` "), 0);
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `news` WHERE  `user_id` = '".$id."' and `mod` = '1' and`time` <= '" . time() . "'"), 0);
if ($total) {
$noimg = 'noimg.jpg';
$req = mysql_query("SELECT * FROM `news` WHERE `user_id` = '".$id."' and `mod` = '1' ORDER BY `time` DESC LIMIT 10");
$i = 1;
 
 $oy = array(
1 => 'Yanvar',
2 => 'Fevral',
3 => 'Mart',
4 => 'Aprel',
5 => 'May',
6 => 'Iyun',
7 => 'Iyul',
8 => 'Avgust',
9 => 'Sentyabr',
10 => 'Oktyabr',
11 => 'Noyabr',
12 => 'Dekabr',
);
 while (($row = mysql_fetch_assoc($req)) !== false) {
 
$comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `news_comm` WHERE `rasm_id` = '".$row['id']."';"), 0);

echo ' <div class="menu"><a href="'.$home.'/news.php?act=info&id='.$row['id'].'"> <span style="  float: left; color: red;"> 
<b> '.functions::display_soat($row['time']).' </b> </span>
<div style="margin-left: 40px;"> '.functions::checkout($row['nomi']).' <br> 

<span style="font-size: x-small;  color: gray;">Ko\'rildi: '.$row['kordi'].'&nbsp; Fikirlar: '.$comm.'  </span> </div> </div> </a>';

}

/*
<font style="color:#fff;"><b> 
'. date ('H:i', $row['time']+$sdvigclock*3600) .' 
</b></font></span> </b><a href="news.php?act=info&id='.$row['id'].'">
'. htmlentities($row['nomi'],ENT_QUOTES,'UTF-8').'</a><div align="right">
<font color="darkgray"><center>
O`qildi: '.$row['views'].' � Fikrlar: '. mysql_result( mysql_query("SELECT COUNT(*) FROM `news_comm` WHERE `bolim`='$row[id]'"),0).'</font>';

echo'</center></div></div>';
*/
echo'<div class="gmenu">Barchasi: '.$total.'</div>';
}else {

echo '<div class="menu">Ro`yxat bo`sh</div>';
}

break;
}

  require_once ($rootpath . "incfiles/end.php");
?>
