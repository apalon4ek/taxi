<?php


define('_IN_JOHNCMS', 1);

require('../incfiles/core.php');
$headmod = 's_fut';
$textl = 'Sotib olingan o\'yinchilar';
require('../incfiles/head.php');
 $id = abs(intval($_GET['id']));
 
 
echo'<div class="phdr">'.$textl.'</div>';


$net = mysql_fetch_assoc(mysql_query("SELECT * FROM `s_fut_users` WHERE `user_id` = '".$id."';"));


 $set = mysql_query("SELECT * FROM `s_fut` WHERE `id` = '".$net['s_fut_id']."'  ORDER BY `id` desc LIMIT ".$start.", ".$kmess.";");
if (mysql_num_rows($set)) {

while ($uz = mysql_fetch_assoc($set)) {
define (
'IMG',
'<img style="margin-bottom:-5px;" src="'.$home.'/images/label.png">'
);
$img = '';
$power = ''.$uz['gol'].'';
switch($power){
case($power >= 900 && $power< 1000):
$img.= IMG;
case($power >= 800 && $power< 900):
$img.= IMG;
case($power >= 600 && $power< 800):
$img.= IMG;
case($power >= 400 && $power< 600):
$img.= IMG;
case($power >= 200 && $power< 400):
$img.= IMG;
case($power >= 100 && $power< 200):
$img.= IMG;
case($power >= 50 && $power< 100):
$img.= IMG;
case($power >= 10 && $power< 50):
$img.= IMG;

}

echo'<div class="menu"><table><tr><td><img style="width:120px; height:120px; border-radius:4px;" src="'.$home.'/files/s_fut/fcb.su_'.$uz['id'].'.jpg"></td>
<td><b>Ismi:</b> '.$uz['ismi'].' <font color="red"><b>#'.$uz['raqam'].'</b></font><br />
<b>Jamoasi:</b> '.$uz['club'].'<br />
<b>Narxi:</b> '.$uz['narx'].' tanga<br />
<b>Ishlashi:</b> '.$uz['out_narx'].' tanga <br />
<b>Gollari:</b> '.$uz['gol'].'<br />'; 

echo (!empty($img) ? '<b>Reyting:</b> '.$img.'<br />':'');

echo'</td></tr></table></div>';

}} 

if ($total > $kmess) {
echo '<div class="menu">  <center>   '.functions::display_pagination('s_futbolchi.php?', $start, $total, $kmess).' </center> </div>';
}



require('../incfiles/end.php');