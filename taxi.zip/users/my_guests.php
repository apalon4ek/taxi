<?php
define('_IN_JOHNCMS', 1);
/**
- Автор скрипта BupTyo3
- http://johncms.com/users/profile.php?user=4269
- 
- Адаптировал Я…… GeGo
- Для JohnCMS 5.2.x
*/


  $rootpath = '../';
  $textl = 'Anketam Mehmonlari';
  require_once ($rootpath . "incfiles/core.php");
  require_once ($rootpath . "incfiles/head.php");

// Проверка юзера 
if (!$user_id) {
  echo functions::display_error('Sahifa faqat userlarga xizmat ko\'rsatadi!<br />Buyoqqa kirish uchun <a href="/registration.php">ro\'yxatdan o\'ting</a> yoki <a href="/login.php">profilizga kiring</a>!');
  require_once ($rootpath . "incfiles/end.php");
  exit;
}
  $act = isset($_GET['act']) ? $_GET['act'] : '';
   switch ($act) {
 default:
  echo '<div class="phdr"><b>Anketam mehmonlari ro\'yxati</b></div>';
  $g_count = mysql_result(mysql_query("SELECT COUNT(*) FROM `my_guests` WHERE `my_id` = '" . $user_id . "';"), 0);
if ($g_count > 0) {
  $p_ank = mysql_result(mysql_query("SELECT `prosm_ank` FROM `users` WHERE `id` = '" . $user_id . "';"), 0);
  $req = mysql_query("SELECT `my_guests`.*, `users`.`name`, `users`.`sex`, `users`.`datereg`, `users`.`lastdate` FROM `my_guests` LEFT JOIN `users` ON `my_guests`.`guest_id` = `users`.`id`  WHERE `my_guests`.`my_id` = '" . $user_id . "' ORDER BY `my_guests`.`time` DESC LIMIT " . $start . ", " . $kmess . ";");
 while ($res = mysql_fetch_assoc($req)) {
  echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
$guest = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '" . $res['guest_id'] . "'"));
//Аватар
                    if ($set_user['avatar']) 
                        echo '<table cellpadding="0" cellspacing="0"><tr><td>'; 
                        if (file_exists(('../files/users/avatar/' . $guest['id'] . '.png')))  
                            echo '<img src="../files/users/avatar/' . $guest['id'] . '.png" width="32" height="32" alt="' . $res['from'] . '" />&#160;';     
                    else
                          echo '<img src="../images/empty.png" width="32" height="32" alt="' . $res['from'] . '" />&#160;';
                        echo '</td><td>'; 
                    
// Значек пола
 if ($res['sex']) 
                        echo functions::image(($res['sex'] == 'm' ? 'm' : 'w') . ($res['datereg'] > time() - 86400 ? '_new' : '') . '.png', array('class' => 'icon-inline')); 
                    else 
                        echo functions::image('del.png'); 

// Ник юзера
echo '&#160;<a href="' . $home . '/users/profile.php?user=' . $res['guest_id'] . '"><b>' . $res['name'] . '</b></a>&#160;'; 

// Должности 
                    $user_rights = array( 
                        3 => '(FMod)', 
                        6 => '(Smd)', 
                        7 => '(Adm)', 
                        9 => '(SV!)' 
                    ); 
                    echo @$user_rights[$guest['rights']]; 

// Онлайн / Офлайн 
                    echo(time() > $res['lastdate'] + 300 ? '<span class="red"> [Off]</span> ' : '<span class="green"> [ON]</span> '); 

// Время
echo '<b>' . functions::display_date($res['time']) . '</b>' ;

//Новый гость или нет
 if ($res['type'] == '0') {
  echo '&#160;<span class="red"><b>new!</b></span>';
  @mysql_query("UPDATE `my_guests` SET `type` = '1' WHERE `id` = '" . $res['id'] . "';");
} 

                     if ($set_user['avatar']) 
                        echo '</td></tr></table>'; 
  echo '</div>';
  ++$i;
 }

//Постраничная навигация
if ($g_count > $kmess) {
  echo '<div class="topmenu">' . functions::display_pagination('my_guests.php?', $start, $g_count, $kmess) . '</div>';
}
echo '<div class="menu">';
echo '&raquo; <a href="my_guests.php?act=del">Ro\'yxatni tozalash</a><br />';
echo '&raquo; <a href="my_guests.php?act=sbros">Hisoblagichni yangilash</a></div>';

echo '<div class="phdr">Umumiy mehmonlar:&#160;' . $g_count . '&#160;|';
  echo '&#160;Anketa ko\'rishlar&#160;' . $p_ank . '</div>';
} else {
  echo '<div class="rmenu"><p>Anketangizga it ham kirmadi!</p></div>';
echo '<div class="phdr"><a href="profile.php?">Anketaga</a></div>';
}
   break;

   case 'del':
//Очистка списка гостей
if (isset($_GET['yes'])) {
  @mysql_query("DELETE FROM `my_guests` WHERE `my_id` = '" . $user_id . "';");
echo '<div class="phdr"><b>Mehmonlar ro\'yxatini tozalash</b></div>';
echo '<div class="gmenu"><b>Mehmonlar ro\'yxati tozalandi!</b></div>';
echo '<div class="phdr"><a href="profile.php?">Anketaga</a></div>';
} else {
echo '<div class="phdr"><b>Mehmonlar ro\'yxatini tozalash</b></div>';
echo '<div class="rmenu"><p>Rostdan ham tozalamoqchimisiz?<br/><a href="my_guests.php?act=del&amp;yes">Tozalash</a> | <a href="my_guests.php?">Bekor qilish</a></p></div>';
echo '<div class="phdr"><a href="profile.php?">Anketaga</a></div>';
}
   break;

   case 'sbros':
//Сброс счетчика просмотров анкеты
if (isset($_GET['yes'])) {
  @mysql_query("UPDATE `users` SET `prosm_ank` = '0' WHERE `id` = '" . $user_id . "';");
echo '<div class="phdr"><b>Hisoblagichni yangilash</b></div>';
echo '<div class="gmenu"><b>Hisoblagich yangilandi!</b></div>';
echo '<div class="phdr"><a href="profile.php?">Anketaga</a></div>';
} else {
echo '<div class="phdr"><b>Mehmonlar ro\'yxatini tozalash</b></div>';
echo '<div class="rmenu"><p>Rostdan ham hisoblagichni yangilamoqchimisiz?<br/><a href="my_guests.php?act=sbros&amp;yes">Yangilash</a> | <a href="my_guests.php?">Bekor qilish</a></p></div>';
echo '<div class="phdr"><a href="profile.php?">Anketaga</a></div>';
}
   break;
}
  require_once ($rootpath . "incfiles/end.php");

?>