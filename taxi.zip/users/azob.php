<?php

 
@ini_set("max_execution_time", "600");
define('_IN_JOHNCMS', 1);
define('_IN_JOHNADM', 1);

require('../incfiles/core.php');
$headmod = 'online';
$textl = 'Xabarlariga azo bo`lish';
require('../incfiles/head.php');


switch ($act) {
case 'list':
if($id){
	
echo '<div class="phdr"><b>Obunachilar</b></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `udesign_xabarga_azo_b` WHERE `kimga_id` = '$id'"), 0);
if ($total) {
$req = mysql_query("SELECT * FROM `udesign_xabarga_azo_b` WHERE `kimga_id` = '$id' order by `time` limit $start, $kmess");
    $i = 0;
    while (($res = mysql_fetch_assoc($req)) !== false) {
$azo2 = mysql_query("SELECT * FROM `users` WHERE `id` = '" . $res['kim_id'] . "'");
$azo = mysql_fetch_assoc($azo2);
        if ($azo['id'] == core::$user_id) echo '<div class="menu">';
        else echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
        $arg['stshide'] = 1;
        $arg['header'] = ' <span class="gray">('.functions::display_date($azo['lastdate']);
        $arg['header'] .= ')</span><br /><span style="color: #007FFF;"><b>Obuna bo\'lgan:</b></span> ' . functions::display_date($res['time']) . '';
        echo functions::display_user($azo, $arg);
        echo '</div>';
        ++$i;
    }
} else {
    echo '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
}
if ($total > $kmess) {
    echo '<div class="menu">' . functions::display_pagination('?act=list&amp;id=' . $user_id . '&amp;' . ($mod ? 'mod=' . $mod . '&amp;' : ''), $start, $total, $kmess) . '</div>';
}


}


break;
case 'exit':
$req1 = mysql_query("SELECT * FROM `udesign_xabarga_azo_b` WHERE `kim_id` = '$user_id' AND `kimga_id` = '$id'");
$res1 = mysql_fetch_assoc($req1);
if(!empty($res1['id'])){
mysql_query("DELETE FROM `udesign_xabarga_azo_b` WHERE `kimga_id` = '$id'");
mysql_query("OPTIMIZE TABLE `udesign_xabarga_azo_b`");
echo '<div class="phdr">Bildirishnomalar</div>';
echo '<div class="menu">Foydalanuvchining, xabarlari bildirishnomasini muvvafaqiyatli o\'chirdingiz!</div>';
}else{
header('Location: ?');
}
break;
case 'add':
if($id){
$req1 = mysql_query("SELECT * FROM `udesign_xabarga_azo_b` WHERE `kim_id` = '" . $user_id . "' AND `kimga_id` = '" . $id . "'");
$res1 = mysql_fetch_assoc($req1);

if(!empty($res1['id'])){
echo '<div class="rmenu">Kechirasiz, siz bu foydalanuvchi xabarlariga oldin a\'zo bo\'lib ulgurgansiz!</div>';
}else{
mysql_query("INSERT INTO `udesign_xabarga_azo_b` SET
            `kim_id` = '" . $user_id . "',
            `kimga_id` = '" . $id . "',
            `time` = '" . time() . "'
        ") or exit(__LINE__ . ': ' . mysql_error());
echo '<div class="phdr">Bildirishnomalar</div>';
echo '<div class="menu">Siz, foydalanuvchining forumda qoldiradigan xabarlariga a\'zo bo\'ldingiz, foydalanuvchi forumda xabar qoldirganidayoq sizga bu haqida bildirishnoma yetkaziladi!</div>';
		}
}
break;
}




require('../incfiles/end.php');