<?php
define('_IN_JOHNCMS', 1);
$textl = 'MP3 Qidiruv';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

$yoshka=mysql_fetch_assoc(mysql_query("SELECT `name` FROM `users` WHERE `id`='$user_id'"));
echo '<div class="phdr">Muhokama: <a href="../pages/about.php?id='.$user_id.'">'.$yoshka['name'].'</a></div>';

switch($_GET['act']){

default:

$new=mysql_result(mysql_query("SELECT COUNT(*) FROM `lenta` WHERE `id_kont` = '$user_id' AND `read`='0'"),0);

if($new!=0){
mysql_query("UPDATE `lenta` SET `read`='1' WHERE `id_kont`='$user_id' AND `read`='0' LIMIT $new");
}

$total=mysql_result(mysql_query("SELECT COUNT(*) FROM `lenta` WHERE `id_kont` = '$user_id'"),0);

 $page = abs((int)$_GET['page']);
 
 if($page < 0 || $page > $total) $page = 0;
 
 if ($total < $page + 10) $end = $total;
 else $end = $page + 10;
 

if ($total==0) {

echo '<div class="menu">Muhokamalar hozircha yo`q!</div>';

}







$q=mysql_query("SELECT * FROM `lenta` WHERE `id_kont` = '$user_id' ORDER BY id  DESC LIMIT ".$start.",".$kmess."");

while ($sts = mysql_fetch_array($q)){
$sts6=mysql_query("select * from yosh_status where id='".$sts['nimaga']."' limit 1");
$sts3=mysql_fetch_array($sts6);
if($sts['nima']=='status'){
$l='<img src="/images/yosh/1sts.png" width="20" height="20"/> Status';
}elseif($sts['nima']=='fikr'){
$l='<img src="/images/yosh/1fikir.png" width="20" height="20"/> Fikr';
}elseif($sts['nima']=='javob'){
$l='<img src="/images/yosh/1javob.png" width="20" height="20"/> Javob';
}if($sts['nima']=='zor'){
$l='<img src="/images/yosh/1klass.png" width="20" height="20"/> Zo`r';
}
if($sts['nima']=='status'){
$l2='Status qo`shdi';
}elseif($sts['nima']=='fikr'){
$l2='Fikir bildirdi';
}elseif($sts['nima']=='javob'){
$l2='Javob berdi';
}if($sts['nima']=='zor'){
$l2='Do`stngiz';
}
$status2=mysql_fetch_assoc(mysql_query("SELECT `name` FROM `yosh_status` WHERE `id`='".$sts['nimaga']."'"));
if($sts['nima']=='status'){
$l3='<a href="/status/?yosh=izoh&amp;id_kim='.$sts3['id_user'].'&amp;id_sts='.$sts['nimaga'].'">
<div class="status">'.$status2[name].'</div></a>';
}elseif($sts['nima']=='fikr'){
$l3='<a href="/status/?yosh=izoh&amp;id_kim='.$sts3['id_user'].'&amp;id_sts='.$sts['nimaga'].'">
<div class="status">'.$status2[name].'</div></a>';
}elseif($sts['nima']=='javob'){
$l3='<a href="/status/?yosh=izoh&amp;id_kim='.$sts3['id_user'].'&amp;id_sts='.$sts['nimaga'].'">
<div class="status">'.$status2[name].'</div></a>';
}if($sts['nima']=='zor'){
$l3='<a href="/status/?yosh=izoh&amp;id_kim='.$sts3['id_user'].'&amp;id_sts='.$sts['nimaga'].'">
<div class="status">'.$status2[name].'</div></a>';
}
echo '<div class="menu"><h3>'.$l.'</h3>';
$yosh=mysql_fetch_assoc(mysql_query("SELECT `name` FROM `users` WHERE `id`='".$sts['id_user']."'"));
echo ''.$l2.'';
$yosh_info = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '" .$sts['id_user']. "' "));
echo ' ' . functions::display_user_yosh($yosh_info) . '';
echo '</div>';
echo ''.$l3.'';



$id_sts=$sts3['id'];
$id_kim=$sts3['id_user'];

$sts_izoh=mysql_num_rows(mysql_query("select * from yosh_status_kom where type='status' and id_kogo='$id_sts'"));
echo '<div class="status_p">
<a href="/status/?yosh=izoh&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/fikr.png" /> '.$sts_izoh.'</a>';
$ajoyib_sts=mysql_query("SELECT * FROM `yosh_status_klass` WHERE `type`='status' AND `zakogo`='$id_sts' AND `kto`='$user_id' LIMIT 1");
$sts1=mysql_query("select * from yosh_status where id='$id_sts' limit 1");
$zor_sts=mysql_fetch_array($sts1);
if($id_kim != $user_id) {
if($user_id and mysql_num_rows($ajoyib_sts)==0 and $user_id!=$id_kim){
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].' </a> &bull; <a href="/status/?yosh=klass&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">Klass!</a>';
}else{
$minus='1';
$ok_status=$zor_sts[ajoyib]-$minus;
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/klass.png" />Siz va '.$ok_status.'</a>';
}
}else{
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].' ta!</a>';
}
echo '</div>';
}
echo '<div class="topmenu">' . functions::display_pagination('lenta.php?', $start, $total, $kmess) . '</div>';
echo '<div class="phdr">Umumiy: '.$total.'</div>';

break;
case msg:
break;
}
require_once ("../incfiles/end.php");


?>
