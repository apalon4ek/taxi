<?php
$suroq = mysql_result(mysql_query("SELECT `value` FROM `sitesets` WHERE `id` = '4'"), 0);
$javob = $suroq['value'];
 if($javob != 0) {
	 echo '<div class="phdr">Kutubxona bo\'limlari</div>';
	 $sql = mysql_query("SELECT `id`, `name`, `dir`, `description` FROM `library_cats` WHERE `parent`=0 ORDER BY `pos` ASC");
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `library_cats` WHERE `parent`=0"), 0);
        $y = 0;
        if ($total) {
            while ($row = mysql_fetch_assoc($sql)) {
                $y++;
                echo '<div class="list' . (++$i % 2 ? 2 : 1) . '">'
                    . '<a href="library/index.php?do=dir&amp;id=' . $row['id'] . '">' . functions::checkout($row['name']) . '</a> ('
                    . mysql_result(mysql_query("SELECT COUNT(*) FROM `" . ($row['dir'] ? 'library_cats' : 'library_texts') . "` WHERE " . ($row['dir'] ? '`parent`=' . $row['id'] : '`cat_id`=' . $row['id'])), 0) . ')';

                echo '</div>';
            }
        }
	 

	 

 }	
 ?>