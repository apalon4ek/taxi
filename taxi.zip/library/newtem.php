<?php
$suroq = mysql_result(mysql_query("SELECT `value` FROM `sitesets` WHERE `id` = '5'"), 0);
$javob = $suroq['value'];
 if($javob != 0) {
echo '<div class="phdr">So\'nggi maqolalar</div>';
 $sql = mysql_query("SELECT `id`, `name`, `time`, `uploader`, `uploader_id`, `count_views`, `comments`, `count_comments`, `cat_id`, `announce` FROM `library_texts` WHERE `premod`=1 ORDER BY `time` DESC LIMIT $javob");
    $i = 0;
    while ($row = mysql_fetch_assoc($sql)) {
        echo '<div class="list' . (++$i % 2 ? 2 : 1) . '">';
        echo '<a href="library/index.php?id=' . $row['id'] . '">' . functions::checkout($row['name']) . '</a><br />';
        echo '' . functions::checkout(bbcode::notags($row['announce'])) . '';
        echo '</div>';
    }
 }

?>