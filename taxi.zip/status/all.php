<?php
define('_IN_JOHNCMS', 1);
$headmod = 'status';

require('../incfiles/core.php');
require('../incfiles/head.php');
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `yosh_status`"), 0);
        echo '<div class="phdr"><b>Status</b> Umumiy '.$total.'</div>';
 if (!$user_id) {
    echo functions::display_error($lng['access_guest_forbidden']);
    } else {
echo '<div class="ystatus_t"><form action="'.$home.'/status/?yosh=status_save" method="post">
<input type="name" name="name"  maxlength="150" size="18" class="anput"/><input value="    +    " type="submit"/></form> </div>' ;
        if ($total > $kmess) echo '<div class="topmenu">' . functions::display_pagination('all.php?', $start, $total, $kmess) . '</div>';
                $req = mysql_query("SELECT `yosh_status`.*, `yosh_status`.`name` AS `sts`, `yosh_status`.`id` AS `sts_id`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`,`users`.`name`
                FROM `yosh_status` LEFT JOIN `users` ON `yosh_status`.`id_user` = `users`.`id`
              ORDER BY `time` DESC LIMIT " . $start . "," . $kmess);

            for ($i = 0; $res = mysql_fetch_assoc($req); ++$i) {
                $text = '';
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                $text = ' ';
                    $res['name'] = functions::checkout($res['name']);
if ($rights == 9) {
$deletion = '<a href="index.php?act=deleted&amp;statid='.$res['sts_id'].'">[x]</a>';
} else {
 $deletion = '';
}
                    $post = '<div class="ystatus">'.functions::checkout($res['sts'], 1, 1).'  <span class="gray">' . functions::display_date($res['time']) . '</span></div>';
                    if ($set_user['smileys'])
                        $post = functions::smileys($post, $res['rights'] >= 1 ? 1 : 0);
$sts_izoh=mysql_num_rows(mysql_query("select * from yosh_status_kom where type='status' and id_kogo='$res[sts_id]'"));
$ajoyib_sts=mysql_query("SELECT * FROM `yosh_status_klass` WHERE `type`='status' AND `zakogo`='$res[sts_id]' AND `kto`='$user_id' LIMIT 1");
$sts1=mysql_query("select * from yosh_status where id='res[sts_id]' limit 1");
$zor_sts=mysql_fetch_array($sts1);
if($res[id] != $user_id) {
if($user_id and mysql_num_rows($ajoyib_sts)==0 and $user_id!=$res[id]){
               $subtext = '<a href="/status/?yosh=izoh&amp;id_kim='.$res[id].'&amp;id_sts='.$res[sts_id].'"> <img src="/images/yosh/fikr.png" /> '.$sts_izoh.'</a> &bull; <a href="/status/?yosh=view&amp;id_kim='.$res[id].'&amp;id_sts='.$res[sts_id].'"> <img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].' </a> &bull; <a href="/status/?yosh=klass&amp;id_kim='.$res[id].'&amp;id_sts='.$res[sts_id].'">Klass</a>';
}else{
$minus='1';
$ok_status=$zor_sts[ajoyib]-$minus;
              $subtext = '<a href="/status/?yosh=izoh&amp;id_kim='.$res[id].'&amp;id_sts='.$res[sts_id].'"> <img src="/images/yosh/fikr.png" /> '.$sts_izoh.'</a> &bull; <a href="/status/?yosh=view&amp;id_kim='.$res[id].'&amp;id_sts='.$res[sts_id].'"> <img src="/images/yosh/klass.png" />Siz va '.$ok_status.'</a>';
}
}else{
               $subtext = '<a href="/status/?yosh=izoh&amp;id_kim='.$res[id].'&amp;id_sts='.$res[sts_id].'"><img src="/images/yosh/fikr.png" /> '.$sts_izoh.'</a> &bull; <a href="/status/?yosh=view&amp;id_kim='.$res[id].'&amp;id_sts='.$res[sts_id].'"> <img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].'</a>';
}
                $arg = array(
                    'header' => $text,
                    'body'   => $post,
                    'sub'   => $subtext,
                    'iphide' => 1
                );
                echo functions::display_user($res, $arg);
echo '</div>';
   }
        if ($total > $kmess) {
            echo '<div class="topmenu">' . functions::display_pagination('all.php?', $start, $total, $kmess) . '</div>' .
                '<p><form action="all.php" method="get"><input type="text" name="page" size="2"/>' .
                '<input type="submit" value="Sahifaga &gt;&gt;"/></form></p>';
  }
   }
require("../incfiles/end.php"); exit();
?>