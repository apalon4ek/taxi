<?

define('_IN_JOHNCMS', 1);
$headmod = 'status';
require_once ("../incfiles/core.php");
if(isset($_GET['id'])){$id=trim($_GET['id']);}else{$id=0;}
$yosh=mysql_fetch_assoc(mysql_query("SELECT `name` FROM `users` WHERE `id`='$id'"));
$textl = 'Statuslar: '.$yosh['name'].'';
require_once ("../incfiles/head.php");

$q=mysql_query("select `id`,`name`,`time` from `yosh_status` where `id_user`=".$id." LIMIT " . $start . "," . $kmess);

$total=mysql_result(mysql_query("SELECT COUNT(*) FROM `yosh_status` WHERE `id_user`='$id'"),0); 

echo '<div class="phdr">'.$yosh['name'].'ning statuslari</div>';
if (mysql_num_rows($q)==0) 
{
echo '<div class="menu">Hali status yozilmagan</div>';
}
while ($sts = mysql_fetch_assoc($q))
{

echo '<a href="/status/?yosh=izoh&amp;id_kim='.$id.'&amp;id_sts='.$sts['id'].'">';
echo '<div class="ystatus">'.$sts['name'].'</div></a>';

$sts_izoh=mysql_num_rows(mysql_query("select * from yosh_status_kom where type='status' and id_kogo='$sts[id]'"));

echo '<div class="kmenu">
<a href="/status/?yosh=izoh&amp;id_kim='.$id.'&amp;id_sts='.$sts[id].'">
<img src="/images/yosh/fikr.png" /> '.$sts_izoh.'</a>';


$ajoyib_sts=mysql_query("SELECT * FROM `yosh_status_klass` WHERE `type`='status' AND `zakogo`='$sts[id]' AND `kto`='$user_id' LIMIT 1");
$sts1=mysql_query("select * from yosh_status where id='$sts[id]' limit 1");
$zor_sts=mysql_fetch_array($sts1);
if($id != $user_id) {

if($user_id and mysql_num_rows($ajoyib_sts)==0 and $user_id!=$id){
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id.'&amp;id_sts='.$sts[id].'">
<img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].' </a> &bull; <a href="/status/?yosh=klass&amp;id_kim='.$id.'&amp;id_sts='.$sts[id].'">Klass</a>';
}else{
$minus='1';
$ok_status=$zor_sts[ajoyib]-$minus;
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id.'&amp;id_sts='.$sts[id].'">
<img src="/images/yosh/klass.png" />Siz va '.$ok_status.'</a>';
}
}else{
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id.'&amp;id_sts='.$sts[id].'">
<img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].'</a>';
}
echo '</div>';
}


echo '<div class="topmenu">' . functions::display_pagination('statuslar.php?id='.$id.'&amp;', $start, $total, $kmess) . '</div>';
echo '<div class="phdr">Umumiy '.$total.'</div>';

require_once ("../incfiles/end.php");
?>