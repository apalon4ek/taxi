<?
define('_IN_JOHNCMS', 1);
$headmod = 'status';
$textl = 'Status';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

if(isset($_GET['yosh'])){$yosh_master=trim($_GET['yosh']);}else{$yosh_master=0;}

switch($yosh_master){

case klass;
echo'<div class="phdr">Ruxsat yo\'q</div>';
if(isset($_GET['id_sts'])){$id_sts=trim($_GET['id_sts']);}else{$id_sts=0;}
if(isset($_GET['id_kim'])){$id_kim=trim($_GET['id_kim']);}else{$id_kim=0;}
if ($user_id) {
$infuz=mysql_query("select * from users where id='$id_kim' limit 1");
if(mysql_num_rows($infuz)==0){
echo '<div class="menu">Bunday User mavjud emas!</div>';
} else {
$uzin=mysql_fetch_array($infuz);
$sgol=mysql_query("select * from rating where type='status' and zakogo='".$uzin['id_user']."' and kto='$id_user' limit 1");
$quie=mysql_num_rows(mysql_query("select * from yosh_status_klass where type='status' and zakogo='".$id_sts."' and kto='$user_id' limit 1"));
if($quie==1){
echo '<div class="menu">Siz klass bosib bo\'ldiz!</div>';
}else{
mysql_query("update yosh_status set ajoyib=ajoyib+1 where id='$id_sts' limit 1");
mysql_query("insert into yosh_status_klass set type='status', zakogo='$id_sts', kto='$user_id', `time`='".time()."', `ocenka`='plus'");

$msg_lenta='Statusga klass';

mysql_query("INSERT INTO `lenta` (`id_user`, `id_kont`, `msg`, `nima`, `nimaga`) values('$user_id', '$id_kim', '$msg_lenta', 'zor', '$id_sts')");

header('Location:index.php?yosh=view&id_kim='.$id_kim.'&id_sts='.$id_sts.'');
}
}
}else{
echo '<div class="menu">Ruxsat yo\'q</div>';
}
break;


case view;
echo'<div class="phdr">Klass bosganlar</div>';
if(isset($_GET['id_sts'])){$id_sts=trim($_GET['id_sts']);}else{$id_sts=0;}
if(isset($_GET['id_kim'])){$id_kim=trim($_GET['id_kim']);}else{$id_kim=0;}
$sts1=mysql_query("select * from yosh_status where id='$id_sts' limit 1");
$sts=mysql_fetch_array($sts1);
if(mysql_num_rows($sts1)==0){
echo '<div class="menu">Bunday status mavjudmas!</div>';
} else {
echo '<div class="ystatus">'.functions::smileys(bbcode::tags($sts['name'])).'</div>';
}

$sts_izoh=mysql_num_rows(mysql_query("select * from yosh_status_kom where type='status' and id_kogo='$id_sts'"));

echo '<div class="ystatus_p">
<a href="/status/?yosh=izoh&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/fikr.png" /> '.$sts_izoh.'</a>';


$ajoyib_sts=mysql_query("SELECT * FROM `yosh_status_klass` WHERE `type`='status' AND `zakogo`='$id_sts' AND `kto`='$user_id' LIMIT 1");
$sts1=mysql_query("select * from yosh_status where id='$id_sts' limit 1");
$zor_sts=mysql_fetch_array($sts1);
if($id_kim != $user_id) {

if($user_id and mysql_num_rows($ajoyib_sts)==0 and $user_id!=$id_kim){
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].' </a> &bull; <a href="/status/?yosh=klass&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">Klass!</a>';
}else{
$minus='1';
$ok_status=$zor_sts[ajoyib]-$minus;
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/klass.png" />Siz va '.$ok_status.'</a>';
}
}else{
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].'</a>';
}
echo '</div>';



$total=mysql_result(mysql_query("SELECT COUNT(*) FROM `yosh_status_klass`
WHERE `zakogo`='$id_sts' AND `type`='status'"),0);
$sts2=mysql_query("SELECT * FROM `yosh_status_klass` WHERE `zakogo`='$id_sts' AND `type`='status' ORDER BY `id_rat` DESC LIMIT ".$start.",".$kmess."");
if($total==0){
echo '<div class="menu">Hozircha komment yo\'q =)</div>';
} else {
while($data=mysql_fetch_array($sts2)){
$yosh = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '" .$data['kto']. "' "));
echo '' . functions::display_user_yosh($yosh, array ('iphide' => 1,)) . '';
}
echo '<div class="topmenu">' . functions::display_pagination('index.php?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'&amp;', $start, $total, $kmess) . '</div>';
}
echo'<div class="phdr">Total: '.$sts['ajoyib'].'</div>';
break;

case izoh;
if(isset($_GET['id_sts'])){$id_sts=trim($_GET['id_sts']);}else{$id_sts=0;}
echo '<div class="phdr">Komment qoldirish</div>';

$sts1=mysql_query("select * from yosh_status where id='$id_sts' limit 1");
$sts=mysql_fetch_array($sts1);

if(mysql_num_rows($sts1)==0){
echo '<div class="menu">Bunday status mavjudmas!</div>';
} else {
echo '<div class="ystatus">'.functions::smileys(bbcode::tags($sts['name'])).'</div>';
}

$sts_izoh=mysql_num_rows(mysql_query("select * from yosh_status_kom where type='status' and id_kogo='$id_sts'"));

echo '<div class="ystatus_p">
<a href="/status/?yosh=izoh&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/fikr.png" /> '.$sts_izoh.'</a>';


$ajoyib_sts=mysql_query("SELECT * FROM `yosh_status_klass` WHERE `type`='status' AND `zakogo`='$id_sts' AND `kto`='$user_id' LIMIT 1");
$sts1=mysql_query("select * from yosh_status where id='$id_sts' limit 1");
$zor_sts=mysql_fetch_array($sts1);
if($id_kim != $user_id) {

if($user_id and mysql_num_rows($ajoyib_sts)==0 and $user_id!=$id_kim){
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].' </a> &bull; <a href="/status/?yosh=klass&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">Klass</a>';
}else{
$minus='1';
$ok_status=$zor_sts[ajoyib]-$minus;
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/klass.png" />Siz va '.$ok_status.'</a>';
}
}else{
echo ' &bull;
<a href="/status/?yosh=view&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/klass.png" />'.$zor_sts['ajoyib'].'</a>';
}
echo '</div>';



$sforum=mysql_query("SELECT COUNT(*) FROM `yosh_status_kom` WHERE `type`='status' AND `id_kogo`='$id_sts'");
$vforum=mysql_query("SELECT * FROM `yosh_status_kom` WHERE `type`='status' AND `id_kogo`='$id_sts' ORDER BY `id_kom` DESC LIMIT ".$start.",".$kmess."");
$total=mysql_result($sforum,0);

if($user_id){
echo'<div class="gmenu">
<form action="?yosh=izoh_2&amp;id_sts='.$id_sts.'&amp;id_kim='.$id_kim.'" method="post">
Matn:
<br /><textarea cols="20" rows="4" name="matn" class="form"></textarea>
<br /><input type="submit" name="submit" value="Yuborish" />
</form>
</div>';
}

if($total==0){
echo'<div class="menu">Hozircha komment yozilmadi</div>';
} else {
while($forum=mysql_fetch_array($vforum)){
$yosh = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '" .$forum['id_user']. "' "));
echo '<div class="list2">' .  functions::display_user($yosh, array ('iphide' => 1,)) . '';                echo ''.functions::smileys(bbcode::tags($forum['text'])).'';
   echo '<div class="sub">
<font color="green">'.functions::display_date($forum['dater']).'</font>';


if ($forum['id_user'] != $user_id) {
echo ' |  <a href="/status/?yosh=javob&amp;kim='.$forum['id_user'].'&amp;id_sts='.$id_sts.'">
<img src="/images/yosh/javob.png" />Javob</a>';
}

if ($user_id!=$id_kim) {
echo '  <b>[x]</b>';
}
echo '</div></div>';
}
echo '<div class="topmenu">' . functions::display_pagination('index.php?yosh=izoh&amp;id_kim='.$id_kim.'&amp;id_sts='.$id_sts.'&amp;', $start, $total, $kmess) . '</div>';

}

break;

case izoh_2;
if(isset($_GET['id_sts'])){$id_sts=trim($_GET['id_sts']);}else{$id_sts=0;}
if($user_id){
$sts1=mysql_query("select * from yosh_status where id='$id_sts' limit 1");
$sts=mysql_fetch_array($sts1);
if(mysql_num_rows($sts1)==0){
echo '<div class="menu">Bunday status mavjud emas</div>';
} else {
$matn  = isset($_POST['matn']) ? trim($_POST['matn']) : '';
$ttimer=time()+10;
mysql_query("INSERT INTO `yosh_status_kom` SET `id_user`='$user_id', `dater`='$ttimer', `text`='" .  mysql_real_escape_string($matn) . "', `id_kogo`='$id_sts', `type`='status'");

if ($sts['id_user'] != $user_id) {
mysql_query("INSERT INTO `lenta` (`id_user`, `id_kont`, `nima`, `nimaga`) values('$user_id', '".$sts['id_user']."', 'fikr', '$id_sts')");
}

mysql_query("UPDATE `users` SET `balans`=`balans`+1 WHERE `id`='$user_id' LIMIT 1");
header("Location: ?yosh=izoh&id_kim=".$sts['id_user']."&id_sts=$id_sts&isset=yesmess");
}
}else{
echo'<div class="p">Faqat ro\'yxatdan o\'tganlar uchun</div>';
}
break;


case javob;
if(isset($_GET['id_sts'])){$id_sts=trim($_GET['id_sts']);}else{$id_sts=0;}
if(isset($_GET['kim'])){$kim=trim($_GET['kim']);}else{$kim=0;}
$yosh=mysql_fetch_assoc(mysql_query("SELECT `name` FROM `users` WHERE `id`='$kim'"));
echo '<div class="phdr">Javob</div>';
$sts1=mysql_query("select * from yosh_status where id='$id_sts' limit 1");
$sts=mysql_fetch_array($sts1);
echo '<div class="ystatus">'.htmlspecialchars($sts['name']).'</div>';
$sforum=mysql_query("SELECT COUNT(*) FROM `yosh_status_kom` WHERE `type`='status' AND `id_kogo`='$id_sts'");
$vforum=mysql_query("SELECT * FROM `yosh_status_kom` WHERE `type`='status' AND `id_kogo`='$id_sts' ORDER BY `id_kom` DESC LIMIT ".$start.",".$kmess."");
$total=mysql_result($sforum,0);

if($user_id){
echo'<div class="menu">
<form action="?yosh=javob_2&amp;id_sts='.$id_sts.'&amp;kim='.$kim.'" method="post">
Matn:
<br /><textarea cols="20" rows="4" name="matn" class="form">'.$yosh['name'].', </textarea>
<br /><input type="submit" name="submit" value="Javob" />
</form>
</div>';
}


break;

case javob_2;
if(isset($_GET['id_sts'])){$id_sts=trim($_GET['id_sts']);}else{$id_sts=0;}
if(isset($_GET['id_kim'])){$id_kim=trim($_GET['id_kim']);}else{$id_kim=0;}
if(isset($_GET['kim'])){$kim=trim($_GET['kim']);}else{$kim=0;}
$sts1=mysql_query("select * from yosh_status where id='$id_sts' limit 1");
$sts=mysql_fetch_array($sts1);
$javob1=mysql_query("SELECT * FROM `yosh_status_kom` WHERE `type`='status' AND `id_kogo`='$id_sts' ORDER BY `id_kom` DESC LIMIT ".$start.",".$kmess."");


if($user_id){
$matn  = isset($_POST['matn']) ? trim($_POST['matn']) : '';

$ttimer=time()+10;
mysql_query("INSERT INTO `yosh_status_kom` SET `id_user`='$user_id', `dater`='$ttimer', `text`='" .  mysql_real_escape_string($matn) . "', `id_kogo`='$id_sts', `type`='status'");

if ($sts['id_user'] != $user_id) {
mysql_query("INSERT INTO `lenta` (`id_user`, `id_kont`, `nima`, `nimaga`) values('$user_id', '".$sts['id_user']."', 'fikr', '$id_sts')");
}

if ($kim != $user_id) {
mysql_query("INSERT INTO `lenta` (`id_user`, `id_kont`, `nima`, `nimaga`) values('$user_id', '".$kim."', 'javob', '$id_sts')");
}


mysql_query("UPDATE `users` SET `balans`=`balans`+1 WHERE `id`='$user_id' LIMIT 1");
header("Location: ?yosh=izoh&id_kim=$id_kim&id_sts=$id_sts&isset=yesmess");

}else{
echo'<div class="p">Faqat ro\'yxatdan o\'tganlar uchun!</div>';
}
break;




case izoh_del;

break;

case'status_saqlash':
$name  = isset($_POST['name']) ? trim($_POST['name']) : '';

if(mb_strlen($name)>3){
mysql_query("INSERT INTO `yosh_status` SET `name`='" .  mysql_real_escape_string($name) . "', `id_user`='$user_id', `time`='".time()."'");
$timer=time()+10;

$st_id=mysql_insert_id();

$q = mysql_query("SELECT * FROM `friend` WHERE `user` = '$user_id'");
while ($f = mysql_fetch_array($q))
{
$a = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '$f[friend]' LIMIT 1"));
$msg_lenta='Status qoshdi ';
mysql_query("INSERT INTO `lenta` (`id_user`, `id_kont`, `msg`, `nima`, `nimaga`) values('$user_id', '$f[friend]', '$msg_lenta', 'status', '$st_id')");
}


header("Location: /users/profile.php?user=user[id]/");
exit;

}else{
echo'<div class="p">Eng kamida 3ta belgi bo\'lishi kerak
<br /> <a href="/users/profile.php">Qaytish</a></div>';
}
break;
case'status_save':
$name  = isset($_POST['name']) ? trim($_POST['name']) : '';
if(mb_strlen($name)>3){
mysql_query("INSERT INTO `yosh_status` SET `name`='" .  mysql_real_escape_string($name) . "', `id_user`='$user_id', `time`='".time()."'");
$timer=time()+10;
$st_id=mysql_insert_id();
$q = mysql_query("SELECT * FROM `friend` WHERE `user` = '$user_id'");
while ($f = mysql_fetch_array($q))
{
$a = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '$f[friend]' LIMIT 1"));
$msg_lenta='Status qoshdi ';
mysql_query("INSERT INTO `lenta` (`id_user`, `id_kont`, `msg`, `nima`, `nimaga`) values('$user_id', '$f[friend]', '$msg_lenta', 'status', '$st_id')");
}
header("Location: /status/all.php");
exit;
}else{
echo'<div class="p">Kamida 3ta belgi bo\'lishi kerak!
<br /><a href="/status/all.php">Qaytish</a></div>';
}
break;
case'status_yozish':
echo '<div class="phdr">Mening statusim</div>';
echo '<div class="menu">
<form action="'.$home.'/status/?yosh=status_saqlash" method="post">';
echo '<textarea cols="20" rows="4" name="name" class="form"></textarea>';
echo '<br /><input type="submit" value=" Saqlash " />';
echo '</form></div>';
break;




}
require_once ("../incfiles/end.php");
?>
