<?php
$suroq = mysql_result(mysql_query("SELECT `value` FROM `sitesets` WHERE `id` = '3'"), 0);
$javob = $suroq['value'];
 if($javob != 0) {
$faollar = mysql_query("SELECT * FROM `chat_faoli` ORDER BY RAND() LIMIT $javob");
while ($faol = mysql_fetch_array($faollar)) {  
    $faolid = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '" .$faol['user_id']. "' "));
    $yoshi = (2000 + date("y")) - $faol['yili'];
    $info = '<span class="gray">Ismi: </span> '.$faol['ism'].', '.$yoshi.' <span class="gray">yoshda</span>, '.$faol['shaxar'].'<span class="gray">dan</span>.<br /><span class="gray">Harakteri: </span> '.$faol['xarakteri'].'.';
   $header = '';
                $arg = array(
                    'header' => $header,
                    'body'   => $info,
                    'iphide' => 1
                );
                echo '<div class="phdr" align="center"><a href="chat/bfaol.php"><b>Sayt liderlari</b></a></div> <div class="gmenu">'.functions::display_user($faolid, $arg).'</div>';
}
 if ($user_id) {
		$faolmi = mysql_result(mysql_query("select count(*) from `chat_faoli` where `user_id` = '".$user_id."'"),0);
   if ($faolmi == 0) {
		$postlari = $datauser['komm'] + $datauser['postforum'] + $datauser['postguest'];
   if ($postlari > 1000) {
  echo '<div class="rmenu"><a href="'.$home.'/choyxor/bfaol.php?act=be">Liderlar safiga qo\'shiling!</a></div>';
  } else {
 echo '<div class="menu">Yanada faolroq bo\'lib liderga aylaning!</a></div>';
    }
  }
 }
}
?>