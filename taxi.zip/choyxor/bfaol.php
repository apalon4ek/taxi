<?php

define('_IN_JOHNCMS', 1);
$headmod = 'chatfaol';
$textl = 'Sayt faollari';
require('../incfiles/core.php');
require('../incfiles/head.php');
if (!$user_id) {
    echo functions::display_error($lng['access_guest_forbidden']);
    require('../incfiles/end.php');
    exit;
}
switch ($act) {
    default:
 echo '<div class="phdr">Saytdagi faol userlar haqida qisqa ma\'lumot</div>';
if ( $user_id) {
$faolmi  = mysql_result(mysql_query("select count(*) from `chat_faoli` where `user_id` = '".$user_id."'"),0);
if ( $faolmi == 0) {
		$postlari = $datauser['komm'] + $datauser['postforum'] + $datauser['postguest'];
if ( $postlari > 1000) {
echo  '<div class="rmenu"><a href="'.$home.'/choyxor/bfaol.php?act=be">Faolligiz lider bo\'lishizga yetarli ekan. Liderlar safiga qo\'shiling!</a></div>';
} else {
echo  '<div class="menu">Agar sal faolroq bo\'lganizda, sizni nomiz ham shuyerda bo\'lardi!</a></div>';
}
}
}

$faollar = mysql_query("SELECT * FROM `chat_faoli` ORDER BY `id` DESC");
while ($faol = mysql_fetch_array($faollar)) {  
    $faolid = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '" .$faol['user_id']. "' "));
    $yoshi = (2000 + date("y")) - $faol['yili'];
  if ($rights > 6) {
 $delete = '<div class="sub"><a href="bfaol.php?act=edit&amp;id='.$faol['id'].'">Taxrir</a> | <a href="bfaol.php?act=del&amp;id='.$faol['id'].'">O\'chirish</a></div>';
 } else {
 $delete = '';
 }
    $info = '<span class="gray">Ismi: </span> '.$faol['ism'].', '.$yoshi.' <span class="gray">yoshda</span>, '.$faol['shaxar'].'<span class="gray">dan.</span>.<br /><span class="gray">Harakter:</span> '.$faol['xarakteri'].'.'.$delete.'';
   $header = '';
                $arg = array(
                    'header' => $header,
                    'body'   => $info,
                    'iphide' => 1
                );
                echo '<div class="list2">'.functions::display_user($faolid, $arg).'</div>';
}
    break;

 case 'be':
		$count = mysql_result(mysql_query("select `postchat` from `chat_users` where `id_u` = '".$user_id."'"),0);
   if ($count > 200) {
echo '<div class="phdr">Liderlikka yozilish</div><div class="menu"><form action="bfaol.php?act=do" method="post"><font color="red">Formani to\'ldirish:</font><br />Haqiqiy ismingiz:<br /><input type="text" name="realname" size="15"/><br />Tug\'ilgan yilingiz:<select name="age"><option value="1960">1960</option> <option value="1961">1961</option><option value="1962">1962</option><option value="1963">1963</option><option value="1964">1964</option><option value="1965">1965</option><option value="1966">1966</option><option value="1967">1967</option><option value="1968">1968</option><option value="1969">1969</option><option value="1970">1970</option> <option value="1971">1971</option><option value="1972">1972</option><option value="1973">1973</option><option value="1974">1974</option><option value="1975">1975</option><option value="1976">1976</option><option value="1977">1977</option><option value="1978">1978</option><option value="1979">1979</option><option value="1980">1980</option> <option value="1981">1981</option><option value="1982">1982</option><option value="1983">1983</option><option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option> <option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option> <option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option></select><br />Yashash joyingiz:<br /><input type="text" name="city" size="15"/><br />Harakteringiz (Max 70)<br /><textarea cols="30" rows="2" name="harakter" ></textarea><input type="submit" name="submit" value="OK" /></form></div>';
} else {
 echo '<div class="rmenu">Siz lider emassiz!</div>';
}
 break;

case 'do':
		$count = mysql_result(mysql_query("select count(*) from `chat_faoli` where `user_id` = '".$user_id."'"),0);
   if ($count != 0) {
    echo '<div class="rmenu">Siz liderlikka yozilgansiz!</div>';
    require('../incfiles/end.php');
    exit;
} else {
        $realname = isset($_POST['realname']) ? functions::checkin(mb_substr(trim($_POST['realname']), 0, 15)) : '';
        $age = isset($_POST['age']) ? functions::checkin(mb_substr(trim($_POST['age']), 0, 4)) : '';
        $city = isset($_POST['city']) ? functions::checkin(mb_substr(trim($_POST['city']), 0, 15)) : '';
        $harakter = isset($_POST['harakter']) ? functions::checkin(mb_substr(trim($_POST['harakter']), 0, 70)) : '';
//xato tekshiramiz
         $error = array();
        if (empty($realname))
      $error[] = 'Ismingizni kiriting!';
        if (empty($city))
     $error[] = 'Shaxringizni kiriting!';
        if (empty($harakter))
     $error[] = 'Harakteringizni kiriting!';
        if (!$error) {
   mysql_query("INSERT INTO `chat_faoli` SET `user_id` = '".$user_id."', `ism` = '" . mysql_real_escape_string($realname) . "', `yili` = '" . mysql_real_escape_string($age) . "', `shaxar` = '" . mysql_real_escape_string($city) . "', `xarakteri` = '" . mysql_real_escape_string($harakter) . "'");
            header('location: bfaol.php');
        } else {
            echo functions::display_error($error, '<a href="bfaol.php">' . $lng['back'] . '</a>');
        }
 }
break;

case 'del':
if ($rights > 6) {
$idfaol = isset($_GET['id']) ?  trim($_GET['id']) : '';
 mysql_query("DELETE FROM `chat_faoli` WHERE `id` = '".$idfaol."'");
header('location: bfaol.php');
 } else {
 header('location: bfaol.php');
 }
break;

case 'edit':
$idfaol = isset($_GET['id']) ?  trim($_GET['id']) : '';
$faol  = mysql_fetch_assoc(mysql_query("SELECT * FROM `chat_faoli` WHERE `id` = '" .$idfaol. "' "));
 if ($rights < 7) {
 echo '<div class="rmenu">Yo\'qol buyerdan!</div>';
require('../incfiles/end.php');
exit;
 } else {
echo '<div class="phdr">Taxrirlash</div><div class="list2"><form action="bfaol.php?act=saveit&amp;id='.$faol['id'].'" method="post">Ism: (max 15)<br /> <input type="text" name="realname" value="'.$faol['ism'].'" maxlength="15"/><br />Tug\'ilgan yil:<br /><input type="text" name="age" value="'.$faol['yili'].'" maxlength="4"/><br />Yashash joyi: (max 15)<br /><input type="text" name="city" value="'.$faol['shaxar'].'" maxlength="15"/><br />Xarakter: (Max 70)<br /><input type="text" name="harakter" value="'.$faol['xarakteri'].'" maxlength="70"/><br /><input type="submit" name="submit" value="OK" /></form></div>';
 }
break;

 case 'saveit':
 if ($rights > 6) {
$idfaol = isset($_GET['id']) ?  trim($_GET['id']) : '';
$realname  = isset($_POST['realname']) ? functions::checkin(mb_substr(trim($_POST['realname']), 0, 15)) : '';
$age  = isset($_POST['age']) ? functions::checkin(mb_substr(trim($_POST['age']), 0, 4)) : '';
$city  = isset($_POST['city']) ? functions::checkin(mb_substr(trim($_POST['city']), 0, 15)) : '';
$harakter  = isset($_POST['harakter']) ? functions::checkin(mb_substr(trim($_POST['harakter']), 0, 70)) : '';
//xato tekshiramiz
$error  = array();
if (empty( $realname))
$error [] = 'Ism kiritilmadi!';
if (empty( $city))
$error [] = 'Shaxar kiritilmadi!';
if (empty( $harakter))
$error [] = 'Harakter kiritilmadi!';
if (! $error) {
mysql_query ("UPDATE `chat_faoli` SET `ism` = '" . mysql_real_escape_string($realname) . "', `yili` = '" . mysql_real_escape_string($age) . "', `shaxar` = '" . mysql_real_escape_string($city) . "', `xarakteri` = '" . mysql_real_escape_string($harakter) . "' WHERE `id` = '".$idfaol."'");
header ('location: bfaol.php');
} else {
echo  functions::display_error($error, '<a href="bfaol.php">' . $lng['back'] . '</a>');
  }
 } else {
 header ('location: index.php');
}
 break;

}
require('../incfiles/end.php');
?>