﻿<?php

/**
Jane, icq: 355-350-450, http://4erti.ru
 */
 defined('_IN_JOHNCMS') or die('Error: restricted access');
$count_us = mysql_result(mysql_query("select count(`id`) from `lider` where `time` >= '".time()."' and `user_id` = '".$user_id."'"),0);
echo '<b><center><div class="phdr"><a href="lider/index.php"><font color=red>Kun lideri</font></a> <font color=blue>' .($count_us ? '' : '| </font><a href="lider/index.php?act=get"><small><font color=red>Lider bo`lish</font></small></a>' ) . '</font></div></center></b>';
echo '<div class="menu">';
$count = mysql_result(mysql_query("select count(*) from `lider` where `time` >= '".time()."'"),0);
			
if	($count	> 0) {
			$sets1 = explode('|', file_get_contents('lider/sets.dat'));
			$req = mysql_query("select * from `lider` where `time` >= '".time()."' order by rand() limit 1");
			$res = mysql_fetch_array($req);
			$us = mysql_fetch_array(mysql_query("SELECT `name`, `yearofbirth`, `dayb`, `monthb` FROM `users` WHERE `id` = '" . $res['user_id'] . "' LIMIT 1"));
			echo '<table><tr>';
			if ($sets1[1]) {
					if (file_exists('files/users/photo/' . $res['user_id'] . '_small.jpg')) 
echo '<td><img src="../files/users/photo/' . $res['user_id'] . '_small.jpg"  border="0" width="120"/></td>';
					else 
echo '<td><img src="lider/photo.jpg" border="10" width="60"/></td>';
					
				}
echo '<td>» <b>Nick: </b> <a href ="../users/profile.php?user='.$res['user_id'].'"><span class="red"><b> ' . functions::checkout($us['name']). '</b></span></a><hr>';
echo '»<b> Yoshi: </b>';
			if ($sets1[2]) {
if (!$us['yearofbirth'] or !$us['monthb'] or !$us['dayb'])
							$a = 0;
else {
							$r = mktime(0, 0, 0, $us['monthb'], $us['dayb'], $us['yearofbirth']);  
							$age = (time()-$r)/31536000; 
							list($a) = explode(".",$age);   
}
						echo ', '.$a;
			}
///echo'$club=mysql_fetch_array
///(mysql_query("SELECT `id`, `name` FROM `fman_clubs` WHERE `user_id` = ".$user['id'] .";"));
echo '<hr>» <b>Matn: </b>';
echo '<hr><i>' . functions::checkout($res['text']) .'</i><hr>' ;
			echo '</td></tr></table>';			
		} 
		else echo 'Liderlar yo`q';
echo '</div>';