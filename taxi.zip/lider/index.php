<?php

/**
Jane, icq: 355-350-450, http://4erti.ru
 */
define('_IN_JOHNCMS', 1);
$headmod = 'lider';
$textl = 'Kun lideri';
require('../incfiles/core.php');
require('../incfiles/head.php');

$error = '';
if (!$user_id)
    $error = 'Faqat <a href="../login.php">ro`yxatdan o`tgan</a> foydalanuvchilar uchun <a href="http://crickers.spaces.ru">&copy;Tarjimon crickers</a>';
if ($error) {
    require_once ("../incfiles/head.php");
    echo '<div class="rmenu"><p>' . $error . '</p></div>';
    require_once ("../incfiles/end.php");
    exit;
}
switch ($act) {
    default:
		$count_us = mysql_result(mysql_query("select count(`id`) from `lider` where `time` >= '".time()."' and `user_id` = '".$user_id."'"),0);
		echo '<div class="phdr">Kun liderlari ' .($count_us ? '' : '| <a href="index.php?act=get"><small>lider bo`lish</small></a>' ) . '</div>';
		echo '<div class="menu">';
		$count = mysql_result(mysql_query("select count(*) from `lider` where `time` >= '".time()."'"),0);
			
		if	($count	> 0) {
			$sets1 = explode('|', file_get_contents('sets.dat'));
			$req = mysql_query("select * from `lider` where `time` >= '".time()."'");
			while ($res = mysql_fetch_array($req)) {
				$us = mysql_fetch_array(mysql_query("SELECT `name`, `yearofbirth`, `dayb`, `monthb` FROM `users` WHERE `id` = '" . $res['user_id'] . "' LIMIT 1"));
				echo '<table><tr>';
				
				if ($sets1[1]) {
					if (file_exists('../files/users/photo/' . $res['user_id'] . '_small.jpg')) 
						echo '<td><img src="../files/users/photo/' . $res['user_id'] . '_small.jpg" border="0" /></td>';
					else 
						echo '<td><img src="no_photo.jpg" border="0" width="60"/></td>';
					
				}
				echo '<td><a href ="../users/profile.php?user='.$res['user_id'].'">' . functions::checkout($us['name']). '</a>';
				if ($sets1[2]) {
						if (!$us['yearofbirth'] or !$us['monthb'] or !$us['dayb']) 
							$a = 0;
						else {
							$r = mktime(0, 0, 0, $us['monthb'], $us['dayb'], $us['yearofbirth']);  
							$age = (time()-$r)/31536000; 
							list($a) = explode(".",$age);   
						}
						echo ', '.$a;
				}
				echo '<br /><i>' . functions::checkout($res['text']) .'</i>' ;
				if ($rights >=7) echo '<br /><a href="index.php?act=del&amp;id='.$res['id'].'">[o`chirish]</a>';
				echo '</td></tr></table>';
			}
		}
		else echo 'Kun lideri yo`q';
				
		echo '</div>';
		if ($rights == 9) echo '<div class="tmn"><a href = "index.php?act=panel">Sozlamalar</a></div>';
	break;
	
	case "get":
		echo '<div class="phdr">Lider bo`lish</div>';
		echo '<div class="menu">';
		$count = mysql_result(mysql_query("select count(*) from `lider` where `time` >= '".time()."' and `user_id` = '".$user_id."'"),0);
		if ($count)	{
			echo '<div class="rmenu">Xizmat oldin yoqilgan</div>';
		}
		else {
			$sets1 = explode('|', file_get_contents('sets.dat'));
			echo 'Sizning balans - <b>'.$datauser['balans'].'</b> ball. <br />Bir kun narxi <b>'.$sets1[0].'</b> ball. <br /> Necha kun lider bo`lishni xohlasangiz, shu raqamni kiriting (max 30):<br />';
			if ($_POST['submit']) {
				$days = abs(intval($_POST['days']));
				if ($days < 1 or $days  > 30) $days = 1;
				$text = functions::check($_POST['text']);
				$cost = $days*$sets1[0];
				if ($cost > $datauser['balans']) echo '<div class="rmenu">Sizda yetarli ball mavjud emas</div>';
				else {
					$t = time() + $days * 24 * 3600;
					mysql_query("update `users` SET `balans`=`balans` - $cost where `id` = '".$user_id."'");
					mysql_query("INSERT INTO `lider` SET
									`user_id`='" . $user_id . "',
									`text` ='".$text."',
									`time`='" . $t . "'		
									");
					echo '<div class="rmenu">Tabliklaymiz! Siz "Kun lideri" xizmatini '.$days.' kunga yoqdingiz.</div> ';
				}
			} 
		
			else {
					echo '<form action="" method="post">';
					echo '<input type="text" name="days" size="2"/>';
					echo '<br />Fikrni kiriting (max 255simv.)<textarea cols="30" rows="2" name="text" ></textarea>';
					echo '<input type="submit" name="submit" value="OK" />';
					echo '</form>';
				}
		}
		echo '</div>';
		echo '<div class="tmn"><a href = "index.php">Kun liderlari</a></div>';
	break;
	
	case "panel":
		if ($rights < 9) {
			header("location: index.php");
			exit;
		}
		if ($_POST['submit']) {

			$sets2 = array();
			if (($_POST['sets'][0]) == '') $sets2[0] = 0; else $sets2[0] = abs(intval($_POST['sets'][0]));
			if (!isset($_POST['sets'][1])) $sets2[1] = 0; else $sets2[1] = 1;
			if (!isset($_POST['sets'][2])) $sets2[2] = 0; else $sets2[2] = 1;
			if (file_put_contents('sets.dat', implode('|', $sets2))) echo '<div class="rmenu">Ma`lumotlar saqlandi</div>';
			
			} 
			
				$sets1 = explode('|', file_get_contents('sets.dat'));
				echo '<div class="phdr">Kun lideri sozlamalari</div><div class="menu"><form action="" method="post">';
				echo '1 kun ko`rsatish narxi<br/><input type="text" name="sets[0]" value="'.$sets1[0].'" size="5"/> ball<br/>';
				echo '<br/><input type="checkbox" name="sets[1]" value="1" ' . ($sets1[1] ? 'checked="checked"' : '') . '/>Rasmni ko`rsatish<br/>';
				echo '<br/><input type="checkbox" name="sets[2]" value="1" ' . ($sets1[2] ? 'checked="checked"' : '') . ' />Yoshini ko`rsatish<br/>';
				echo '<input type="submit" name="submit" value="Yangilash" />';
				echo '</form></div>';
			echo '<div class="tmn"><a href = "index.php">Kun liderlari</a></div>';
			
	break;
	
	case "del":
		if ($rights < 7) {
			header("location: index.php");
			exit;
		}
		if (isset($_GET['yes'])) {
				mysql_query("DELETE from `lider` where `id` = '".$id."'");
				header("location: index.php");
			}
			else {
			   echo '<p>Siz haqiqatdan ham ushbu userni "Kun liderlari" ro`yxatidan o`chirmoqchimisiz?<br/>';
			   echo '<a href="index.php?act=del&amp;id=' . $id . '&amp;yes">HA</a> | <a href="index.php">YO`Q</a></p>';
			}
		
	break;
	
}

require('../incfiles/end.php');
?>