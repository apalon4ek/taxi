<?php

defined('_IN_JOHNCMS') or die ('Error: restricted access');

$db_host = 'localhost';
$db_name = 'alijohncms';
$db_user = 'alijohncms';
$db_pass = '94101';