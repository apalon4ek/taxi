Uzbek language pack
============================================================
TRANSLATION AUTHORS:
Sard0r (go_sari@mail.ru)