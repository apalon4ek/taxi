<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Рекламный блок сайта
if (!empty($cms_ads[2])) {
    echo '<div class="gzetpro">' . $cms_ads[2] . '</div>';
}
$users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > '" . (time() - 600) . "'"), 0);
$guests = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '" . (time() - 600) . "'"), 0);
$all = $users+$guests;

echo '<div class="menu">';


echo 'Foydalanuvchilar: <a href="/users/index.php?act=online">'.$users.' kishi</a><br />
Mehmonlar: <a href="/users/index.php?act=online&mod=guest">'.$guests.' kishi </a><br>
<a href="/pages/aloqa.php">Biz bilan aloqa</a></br>
<a href="/">Bosh sahifa</a>



    </div></div></div>	';

echo '<center><div class="auth"><div class="tfoot"><table cellspacing="0" cellpadding="0"><tr><span class="auth"><a href="/mode.php?mode=web">WEB versiya</a></span></div></center>';


   echo '<div style="text-align:right">' ;
  


// Счетчики каталогов
functions::display_counters();

// Рекламный блок сайта
if (!empty($cms_ads[3])) {
    echo '<br />' . $cms_ads[3];
}

echo '<div class="footer">Powered by Apalon4ik</div>';



?>


