<?php

class blogs
{
    public static function fdn()
    {
      return mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` WHERE `dnid` = 'txt'"), 0);   
    }
   
    public static function dn_new($par=0)
    {
       $old = time() - (3 * 24 * 3600);
       $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` LEFT JOIN `dn_rdm` ON `dnevniki`.`id` = `dn_rdm`.`dnid` AND `dn_rdm`.`user_id` = '" . core::$user_id . "' WHERE `dn_rdm`.`user_id` IS NULL AND `dnevniki`.`dnid` = 'txt' AND `vr` > '".$old."' "), 0);
       return $total;
    }
   
    public static function dnevniki_com_new()
    {
      $old = time() - (3 * 24 * 3600);
      return mysql_result(mysql_query("SELECT COUNT(*) FROM `dnevniki` LEFT JOIN `dnevniki_com_rdm` ON `dnevniki`.`id` = `dnevniki_com_rdm`.`comid` AND `dnevniki_com_rdm`.`userid` = '" . core::$user_id . "' WHERE `dnevniki_com_rdm`.`userid` IS NULL AND `dnevniki`.`dnid` = 'com'  AND `dnevniki`.`time` > '".$old."' ORDER BY `dnevniki`.`time`;"), 0); 
    }
    
    public static function dnevniki_total()
    { 
      $newrec = self::dn_new();
      if(core::$user_id)
       $newcom =  self::dnevniki_com_new(); 
      return self::fdn().($newrec ? '/<span class="red"><a href="blogs/?act=new">+'.$newrec.'</a></span>' : '').($newcom ? '/<span style="text-color: blue"><a href="blogs/?act=newcm">+'.$newcom.'</a></span>' : '');
    }
}