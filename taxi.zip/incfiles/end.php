<?php

/**
 * @module      MiniWEB for JohnCMS 4.x.x
 * @author      Elena Libra
 * @copyright   EL Design
 * @link        http://creodiz.ru
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (isset($_COOKIE['theme']))
{ $cookie = $_COOKIE['theme']; }

if ($cookie == 'web')
{ require_once($rootpath . 'webstyle/end.php'); }
else
{ require_once($rootpath . 'incfiles/end_mobile.php'); }
?>